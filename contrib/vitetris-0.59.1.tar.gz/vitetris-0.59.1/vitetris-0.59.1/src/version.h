#define VERSION_NO "0.59.1"
#define VERSION_DATE "20201226"

#define VITETRIS_VER "vitetris "VERSION_NO
