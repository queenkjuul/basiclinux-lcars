extern char margin_x;
extern int win_x;
extern int win_y;

extern BITMAP *virt_screen;
extern int refresh_needed;
extern char blit_rect[4];

void toggle_fullscreen();
