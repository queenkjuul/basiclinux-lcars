Using this HTTP server is as easy as 1 - 2 - 3 :
(1) copy httpd to /usr/sbin
(2) cd to the directory you want to serve from
(3) type 'httpd' and press ENTER 

The server is now working.  You can check it by starting the 'links' browser, 
pressing G, and typing this:   http://localhost

Although it is very simple to set up this server, it is not a toy.  It has
several optional parameters, which enable quite sophisticated functionality.
A description of these parameters is contained in thttp.txt.gz.


Using the HTTP server for real-world applications
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Since BasicLinux is quite small, there is only limited room in the filesystem
to store HTML files (and other content).  700kb max.  Instead, I would expect
most applications to use content stored on a CDrom or hard drive.  BasicLinux 
would mount the drive and serve the content from there.
---------------------------------------------------------------------
mount /dev/hda1 /mnt     # 1st partition, master drive on primary IDE    
cd /mnt/www              # HTML content in www directory 
httpd                    # starts server (no logging)
---------------------------------------------------------------------

As a security measure, the HTTP server only allows access to files which 
are non-executable.  Therefore, if you are mounting a DOS or win9x partition 
to serve from, you must use the noexec parameter.
----------------------------------------------------------------------
mount -o noexec /dev/hda1 /mnt     # drive C: 
cd /mnt/www/html                   # content in C:\www\html directory  
httpd -l /mnt/www/log              # starts server (log in C:\www)
----------------------------------------------------------------------

If you wish to turn off the HTTP server, you can do a 'ps -ax' to find 
the process number and 'kill' that number.  Or, you can do this:
------------------
kill `pidof httpd`
------------------

