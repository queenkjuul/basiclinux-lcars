This is an experimental version of a dhcp client.  I do not have a dhcp 
connection myself, so I can not test it personally.  I would appreciate 
feedback from users, both positive and negative.

To use the dhcp client
~~~~~~~~~~~~~~~~~~~~~~
(1) put the following files in /usr/sbin:
      dhcp 
      lua 
      dhcp.lua 
      common.lua
(2) insmod your network card to establish eth0
(3) execute dhcp

For example, if you have an NE2000 card at address 0x320
------------------
insmod 8390
insmod ne io=0x320
dhcp
------------------

Good luck!  Let me know how it goes.  --->  ichi@ihug.co.nz
