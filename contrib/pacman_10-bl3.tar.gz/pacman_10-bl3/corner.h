#ifndef __corner_h_ 
#define __corner_h_
#include"gwalls.h"

class Corner : public G_Walls {
         
};

#endif   
