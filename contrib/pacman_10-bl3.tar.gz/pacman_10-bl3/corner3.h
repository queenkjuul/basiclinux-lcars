#ifndef __corner3_h_ 
#define __corner3_h_
#include"corner.h"

class Corner3 : public Corner {
         
public:         
         
Corner3();
           
};

#endif   
