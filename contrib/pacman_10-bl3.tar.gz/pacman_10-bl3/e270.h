#ifndef __e270_h_ 
#define __e270_h_
#include"endwall.h"

class E270 : public EndWall {
         
public:         
         
E270();

};

#endif   
