#include"t180.h"
  
T180::T180() {
 
consfn();
pix(&pixmap,t180_bits,Colour::WALLCOLOUR,Colour::MYBACKGROUND);
}

