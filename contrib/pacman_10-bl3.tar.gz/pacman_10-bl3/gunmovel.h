#ifndef __gunmovel_h_ 
#define __gunmovel_h_
 #include"gdynelem.h"

class G_UnmoveableElement : public DynamicGraphElement {
       
public:       
          

          
};

#endif
