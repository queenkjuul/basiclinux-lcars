#include"gsupfood.h"
  
G_SuperFood::G_SuperFood() {
 
consfn();
pix(&pixmap,superfood_bits,Colour::SUPERFOODCOLOUR,Colour::MYBACKGROUND);

};


