#ifndef __food_h_ 
 #define __food_h_
 #include"edible.h"

class Food : public Edible {
          
public:

typ is_a(void) {return classFood;}    
          
Food();
          
};

#endif 
