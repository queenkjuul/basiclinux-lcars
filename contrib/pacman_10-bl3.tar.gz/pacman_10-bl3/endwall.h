#ifndef __EndWall_h_ 
#define __EndWall_h_
#include"gwalls.h"

class EndWall : public G_Walls {
         
public:         
         
void draw(void);

};

#endif   
