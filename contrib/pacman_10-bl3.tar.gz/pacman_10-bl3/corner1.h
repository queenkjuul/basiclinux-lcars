#ifndef __corner1_h_ 
#define __corner1_h_
#include"corner.h"

class Corner1 : public Corner {
         
public:         
         
Corner1();
           
};

#endif   
