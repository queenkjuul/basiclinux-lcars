#ifndef __t180_h_ 
#define __t180_h_
#include"twall.h"

class T180 : public T_Wall {
         
public:         
         
T180();

};

#endif   
