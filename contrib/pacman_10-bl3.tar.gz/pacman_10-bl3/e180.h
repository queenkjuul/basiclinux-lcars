#ifndef __e180_h_ 
#define __e180_h_
#include"endwall.h"

class E180 : public EndWall {
         
public:         
         
E180();

};

#endif   
