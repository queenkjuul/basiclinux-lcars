#include"cross.h"
  
Cross::Cross() {
 
consfn();
pix(&pixmap,cross_bits,Colour::WALLCOLOUR,Colour::MYBACKGROUND);

};

