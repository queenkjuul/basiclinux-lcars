#ifndef __corner4_h_ 
#define __corner4_h_
#include"corner.h"

class Corner4 : public Corner {
         
public:         
         
Corner4();
           
};

#endif   
