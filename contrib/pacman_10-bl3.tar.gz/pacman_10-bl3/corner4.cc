#include"corner4.h"
  
Corner4::Corner4() {
 
consfn();
pix(&pixmap,corner4_bits,Colour::WALLCOLOUR,Colour::MYBACKGROUND);
};

