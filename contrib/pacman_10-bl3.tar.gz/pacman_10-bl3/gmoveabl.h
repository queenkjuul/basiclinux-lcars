#ifndef __gmoveabl_h_ 
#define __gmoveabl_h_
#include"gdynelem.h"

class G_Moveables : public DynamicGraphElement {

 public:
        
        
};

#endif
