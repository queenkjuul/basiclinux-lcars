#include"gdynelem.h"

GID_TYPE DynamicGraphElement::getgid() {return pixmap;}


