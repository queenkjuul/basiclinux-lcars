#include"t270.h"
  
T270::T270() {
 
consfn();
pix(&pixmap,t270_bits,Colour::WALLCOLOUR,Colour::MYBACKGROUND);
}

