#ifndef __walls_h_ 
#define __walls_h_
#include"staticel.h"

class Walls : public StaticElement {
         
public:         
         
Walls();
typ is_a(void) {return classWall;}
};

#endif   
