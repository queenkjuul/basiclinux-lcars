#include"supefood.h"

SuperFood::SuperFood() {
}

