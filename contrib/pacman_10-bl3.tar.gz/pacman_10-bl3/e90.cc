#include"e90.h"
  
E90::E90() {
 
consfn();
pix(&pixmap,e90_bits,Colour::WALLCOLOUR,Colour::MYBACKGROUND);
}
