#include"specwall.h"

SpecialWall::SpecialWall() {
}
  
