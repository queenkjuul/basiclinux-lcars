#ifndef __e0_h_ 
#define __e0_h_
#include"endwall.h"

class E0 : public EndWall {
         
public:         
         
E0();

};

#endif   
