#ifndef __gbonlife_h_ 
 #define __gbonlife_h_
 #include"gbonus.h"

class G_BonusLife : public G_Bonus {
   
public:

G_BonusLife();
  
};

#endif
