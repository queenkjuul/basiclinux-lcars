#include"corner3.h"
  
Corner3::Corner3() {
 
consfn();
pix(&pixmap,corner3_bits,Colour::WALLCOLOUR,Colour::MYBACKGROUND);
};

