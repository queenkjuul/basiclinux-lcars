#include"blank.h"
#include"gblank.h"

Blank::Blank() {

}

