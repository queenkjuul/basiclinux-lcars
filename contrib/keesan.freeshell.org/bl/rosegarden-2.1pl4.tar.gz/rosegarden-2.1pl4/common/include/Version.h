
#ifndef _ROSEGARDEN_VERSION_H_
#define _ROSEGARDEN_VERSION_H_

#define ROSEGARDEN_VERSION "Release 2.1pl3, April 2002"

#endif

