
#ifndef _TOPBOX_VISUALS_
#define _TOPBOX_VISUALS_

#include "General.h"


extern Result InitialiseVisuals(void);
extern void   CleanUpVisuals(void);


#endif /* _TOPBOX_VISUALS_ */

