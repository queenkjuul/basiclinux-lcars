
#ifndef _TOPBOX_FALLBACKS_
#define _TOPBOX_FALLBACKS_


static String fallbacks[] = {

"Interlock*Text*Translations:   #override <Key>Return: end-of-line()",

NULL,
};

#endif /* _TOPBOX_FALLBACKS_ */

