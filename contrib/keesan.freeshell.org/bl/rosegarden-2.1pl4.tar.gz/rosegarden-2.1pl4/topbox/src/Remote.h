
#ifndef _REMOTE_H_
#define _REMOTE_H_

extern Boolean OpenRemote(Widget, String, Window);

#endif

