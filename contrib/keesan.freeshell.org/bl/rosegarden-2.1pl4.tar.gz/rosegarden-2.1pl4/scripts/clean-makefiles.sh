#!/bin/sh
for x in `find . -name Makefile -print` ; do
    perl -i -e 'while (<>) { last if (/^..DO NOT/); print; }' $x
done
