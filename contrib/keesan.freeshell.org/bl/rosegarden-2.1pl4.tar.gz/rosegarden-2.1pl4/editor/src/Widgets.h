
#ifndef _MUSIC_WIDGETS_
#define _MUSIC_WIDGETS_


extern void   CreateApplicationWidgets(void);
extern Widget musicViewport;
extern Widget pageButton;
extern void   yHelpCallback(String);
extern void   yHelpCallbackCallback(Widget, XtPointer, XtPointer);


#endif /* _MUSIC_WIDGETS_ */

