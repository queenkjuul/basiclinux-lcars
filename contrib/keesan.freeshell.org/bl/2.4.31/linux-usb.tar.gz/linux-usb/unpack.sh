#!/bin/sh

mount -o loop -t msdos 1440.img /mnt
cp /mnt/linux bzImage
zcat /mnt/initrd.gz >tmpinitrd
umount /mnt
mount -o loop -t ext2 tmpinitrd /mnt
cp /mnt/lib/modules/2.4.31/*.o modules/
umount /mnt
rm -f tmpinitrd

echo -n "Do you want to unpack the 2.88MB disk image? (Y/N) "
read prompt_answer
case $prompt_answer in
	Y | y) tools/bspatch 1440.img 2880.img patches/2880.patch;;
	*) echo "Will not unpack the image.";;
esac
