This release of pilot-link is including support for Win32 right out of the
box. If you wish to recompile it you will need Watcom C/C++ 10.6 or later.
MSVC++ will currently not work. If you want ready to use binaries of the
pilot-xfer utility and of the KittyKiller utility, which allows you to disable
HotSyncManager from the command-line, please go to
http://linux.stud.fh-heilbronn.de/~christ/pilot-xfer and download from there.

Cheers,
Tilo Christ (christ@swl.fh-heilbronn.de)

