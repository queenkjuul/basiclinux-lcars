#ifndef _PILOT_VERSION_H_
#define _PILOT_VERSION_H_

#define PILOT_LINK_VERSION 0
#define PILOT_LINK_MAJOR 9
#define PILOT_LINK_MINOR 4

/*  If releasing a version without a patch number, make sure
 *  that this is *NOT* defined.
 */
/*#define PILOT_LINK_PATCH "something"*/

#endif /* _PILOT_VERSION_H_ */
