// Unix specific auto configuration preference defaults
platform.value = "unix";
