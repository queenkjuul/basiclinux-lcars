//@line 36 "/home/m-ito/tmp/mozilla/browser/locales/../../browser/locales/en-US/firefox-l10n.js"

//@line 38 "/home/m-ito/tmp/mozilla/browser/locales/../../browser/locales/en-US/firefox-l10n.js"

pref("general.useragent.locale", "en-US");
