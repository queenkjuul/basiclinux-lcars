//@line 2 "/home/m-ito/tmp/mozilla/browser/app/profile/channel-prefs.js"
pref("app.update.channel", "default");
