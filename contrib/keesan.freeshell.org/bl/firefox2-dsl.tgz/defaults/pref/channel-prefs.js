//@line 2 "/mnt/hda10/work/mozilla/browser/app/profile/channel-prefs.js"
pref("app.update.channel", "default");
