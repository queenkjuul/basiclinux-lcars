//@line 36 "/mnt/hda10/work/mozilla/browser/locales/../../browser/locales/en-US/firefox-l10n.js"

//@line 38 "/mnt/hda10/work/mozilla/browser/locales/../../browser/locales/en-US/firefox-l10n.js"

pref("general.useragent.locale", "en-US");
