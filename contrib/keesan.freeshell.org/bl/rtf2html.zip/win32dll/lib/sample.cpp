#include <stdio.h>
#include "r2h.h"

int main(int argc, char *argv[]){
  int code=0;
  printf("RTF 2 HTML Converter Sample Application\n"
         "DLL Info: %s\n", r2hAboutMessage());
  printf("\n");

  switch(argc){
    case 4:
      printf("Input file:  %s\n"
             "Output file: %s\n"
             "Images:      %s\n", argv[1], argv[2], argv[3]);
      code=Convert(argv[1], argv[2], r2hUseImageDirectory, argv[3]); 
      break;
    default:
      printf("USAGE: sample <input file> <output-file> <image directory>\n");
  }
  printf("Exiting with code %d.\n", code);
  return code;
}


