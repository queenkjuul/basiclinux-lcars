// This is a header file for RTF -> HTML conversion DLL.

#if !defined(R2H_H)
#define R2H_H

typedef unsigned long r2hFlags;
const r2hFlags            
  r2hUseImageSize=1,
  r2hUseImageDirectory=2,
  r2hPreferUnicode=4;

#if defined(_MSC_VER)
    #define IMPORTED_FN(typ) extern "C" _declspec(dllimport) typ pascal
#else
    #define IMPORTED_FN(typ) extern "C" __declspec(dllimport) typ 
#endif

IMPORTED_FN(int) Convert(const char *rtf, const char *html, r2hFlags Flags=0, const char *imgdir="");
IMPORTED_FN(char*) r2hErrorMessage(int code, char *result);
IMPORTED_FN(char*) r2hAboutMessage();

#endif
