;;; custom-load.el --- automatically extracted custom dependencies


;;; Code:

(custom-add-loads 'environment '("dired-faces"))
(custom-add-loads 'dired '("dired-faces"))

;;; custom-load.el ends here
