if fgrep "/usr/share/texmf/bin" etc/profile 1> /dev/null 2> /dev/null ; then
 echo good > /dev/null
else
 cat << EOF >> etc/profile
# Add PATH and MANPATH for teTeX:
PATH="\$PATH:/usr/share/texmf/bin"
MANPATH="\$MANPATH:/usr/share/texmf/man"
EOF
fi
if fgrep "/usr/share/texmf/bin" etc/csh.login 1> /dev/null 2> /dev/null ; then
 echo good > /dev/null
else
 cat << EOF >> etc/csh.login
# Add path and MANPATH for teTeX:
set path = ( \$path /usr/share/texmf/bin )
setenv MANPATH \${MANPATH}:/usr/share/texmf/man
EOF
fi
### links:
( cd usr/share/texmf/dvips/base ; rm -rf psfonts.map )
( cd usr/share/texmf/dvips/base ; ln -sf ../config/psfonts.map psfonts.map )
( cd usr/share/texmf/web2c ; rm -rf plain.fmt )
( cd usr/share/texmf/web2c ; ln -sf tex.fmt plain.fmt )
( cd usr/share/texmf/web2c ; rm -rf plain.base )
( cd usr/share/texmf/web2c ; ln -sf mf.base plain.base )
( cd usr/share/texmf/web2c ; rm -rf plain.mem )
( cd usr/share/texmf/web2c ; ln -sf mpost.mem plain.mem )
( cd usr/share/texmf/man/man1 ; rm -rf allec.1 )
( cd usr/share/texmf/man/man1 ; ln -sf allcm.1 allec.1 )
( cd usr/share/texmf/man/man1 ; rm -rf texhash.1 )
( cd usr/share/texmf/man/man1 ; ln -sf mktexlsr.1 texhash.1 )
( cd usr/share/texmf/man/man1 ; rm -rf initex.1 )
( cd usr/share/texmf/man/man1 ; ln -sf tex.1 initex.1 )
( cd usr/share/texmf/man/man1 ; rm -rf virtex.1 )
( cd usr/share/texmf/man/man1 ; ln -sf tex.1 virtex.1 )
( cd usr/share/texmf/man/man1 ; rm -rf einitex.1 )
( cd usr/share/texmf/man/man1 ; ln -sf etex.1 einitex.1 )
( cd usr/share/texmf/man/man1 ; rm -rf evirtex.1 )
( cd usr/share/texmf/man/man1 ; ln -sf etex.1 evirtex.1 )
( cd usr/share/texmf/man/man1 ; rm -rf elatex.1 )
( cd usr/share/texmf/man/man1 ; ln -sf etex.1 elatex.1 )
( cd usr/share/texmf/man/man1 ; rm -rf inimf.1 )
( cd usr/share/texmf/man/man1 ; ln -sf mf.1 inimf.1 )
( cd usr/share/texmf/man/man1 ; rm -rf virmf.1 )
( cd usr/share/texmf/man/man1 ; ln -sf mf.1 virmf.1 )
( cd usr/share/texmf/man/man1 ; rm -rf inimpost.1 )
( cd usr/share/texmf/man/man1 ; ln -sf mpost.1 inimpost.1 )
( cd usr/share/texmf/man/man1 ; rm -rf virmpost.1 )
( cd usr/share/texmf/man/man1 ; ln -sf mpost.1 virmpost.1 )
( cd usr/share/texmf/man/man1 ; rm -rf iniomega.1 )
( cd usr/share/texmf/man/man1 ; ln -sf omega.1 iniomega.1 )
( cd usr/share/texmf/man/man1 ; rm -rf viromega.1 )
( cd usr/share/texmf/man/man1 ; ln -sf omega.1 viromega.1 )
( cd usr/share/texmf/man/man1 ; rm -rf lambda.1 )
( cd usr/share/texmf/man/man1 ; ln -sf omega.1 lambda.1 )
( cd usr/share/texmf/man/man1 ; rm -rf pdfinitex.1 )
( cd usr/share/texmf/man/man1 ; ln -sf pdftex.1 pdfinitex.1 )
( cd usr/share/texmf/man/man1 ; rm -rf pdfvirtex.1 )
( cd usr/share/texmf/man/man1 ; ln -sf pdftex.1 pdfvirtex.1 )
( cd usr/share/texmf/man/man1 ; rm -rf pdflatex.1 )
( cd usr/share/texmf/man/man1 ; ln -sf pdftex.1 pdflatex.1 )
( cd usr/share/texmf/man/man1 ; rm -rf cont-de.1 )
( cd usr/share/texmf/man/man1 ; ln -sf pdftex.1 cont-de.1 )
( cd usr/share/texmf/man/man1 ; rm -rf cont-nl.1 )
( cd usr/share/texmf/man/man1 ; ln -sf pdftex.1 cont-nl.1 )
( cd usr/share/texmf/man/man1 ; rm -rf cont-en.1 )
( cd usr/share/texmf/man/man1 ; ln -sf pdftex.1 cont-en.1 )
( cd usr/share/texmf/man/man1 ; rm -rf MakeTeXPK.1 )
( cd usr/share/texmf/man/man1 ; ln -sf mktexpk.1 MakeTeXPK.1 )
