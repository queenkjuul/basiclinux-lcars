% This is the list of all french macros introduced/modified by the french style
%                                     Copyright Bernard Gaulle as in french.doc
%
% to be used only for testing/debugging purposes.
%
% All pseudo standard titles cs (like \slidename) are omitted. 
% Just specific french macros are there.
%                                                                 rev. 99/01/20
%%
%%      checksum        = "05567 63 169 3697"
%%
\dummydef[%test,%
          french,english,frenchtest,frenchdoc,NouveauLangage,%        % 5
beginlanguage,inferieura,superieura,lqq,rqq,originalinput,%           %10
nonfrench,endnonfrench,frenchtypography,noTeXdots,TeXdots,%           %15
ancientguillemets,todayguillemets,guillemetsinallfonts,%18
                                      guillemetsinroman,endguillemets,%20
noenglishquote,englishquote,noenglishdoublequotes,englishdoublequotes,%24
                                                        untypedspaces,%25
typedspaces,idotless,iwithdot,EBCDICbrackets,normalbrackets,%         %30
letpunctutionactivefor,wrongtypedspaces,nofrenchtypography,%33
                               frenchlayout,everyparguillemetsremoved,%35
everyparguillemets,noeveryparguillemets,overfullhboxmark,%38
                                    nooverfullhboxmark,labelsinmargin,%40
nolabelsinmargin,Numeros,nopagenumbers,order,nofrenchlayout,%         %45
frenchtranslation,resume,sommaire,annexe,annexes,%                    %50
glossaire,glossaires,printindex,see,seealso,%                         %55
nofrenchtranslation,frenchmacros,ier,iere,ieme,%                      %60
lettrinefont,keywords,endkeywords,motsclef,endmotsclef,%              %65
%No, % was it really defined in the past?
degre,degres,leftguillemets,rightguillemets,CheckSevenBits,%          %70
fup,primo,secundo,tertio,quarto,%                                     %75
quando,fsc,refmark,moretolerance,Sauter,%                             %80
minMAJ,abbreviations,noabbreviations,nofrenchmacros,frenchstyleid,%   %85
abstract,endabstract,mdseries,letpunctuationactivefor,%89
                                                   nowrongtypedspaces,%90
%oguill,fguill,% fully obsolate now 98/01
<,>,endorder,Ordinale,Ordinal,%                                       %95
lsc,allowuchyph,disallowuchyph,vers,versatim,%                       %100
endversatim,tthyphenation,notthyphenation,!,tabbingaccents,%         %105
notabbingaccents,usersfrenchoptions,PS,yourref,ourref,%              %110
object,AllTeX,formfoot,formhead,figurette,%                          %115
endfigurette,pointvirgule,deuxpoints,pointexclamation,%119
                                                  pointinterrogation,%120
guillemets,iers,ieres,iemes,numeros,%                                %125
dittomark,frenchname,frenchhyphenation,nofrenchhyphenation,hyphex,%  %130
frhyphex,%131
%GOfrench,% is not a user command
printglossary,lettrine,flettrine,ordinal,%                           %135
pmfrench,at,chap,email,endfrench,%                                   %140
lettrinehang,prefacename,vert,tilde,lettrinefontname,%               %145
automaticlettrine,noautomaticlettrine,noresetatpart,%148
                                          fguillemets,endfguillemets,%150
frenchguillemets,nofrenchguillemets,wideletter,%153
                                   originaloutput,unnumberedcaptions,%155
%languagename is also in Babel
%slidename and listslidename will be in seminar too
%notesname is already in endnotes
usualmessages,allowhyphens,nohyphenation,ordinale,guillemetsinarrays,%160
noguillemetsinarrays,captionfont,% %162
]}%
\endinput
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
