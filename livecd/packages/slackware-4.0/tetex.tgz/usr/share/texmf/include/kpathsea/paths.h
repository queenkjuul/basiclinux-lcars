/* paths.h: Generated from texmf.cnf. */
#ifndef DEFAULT_TEXMFMAIN
#define DEFAULT_TEXMFMAIN "/usr/share/texmf"
#endif
#ifndef DEFAULT_TEXMF
#define DEFAULT_TEXMF "/usr/share/texmf"
#endif
#ifndef DEFAULT_SYSTEXMF
#define DEFAULT_SYSTEXMF "/usr/share/texmf"
#endif
#ifndef DEFAULT_VARTEXFONTS
#define DEFAULT_VARTEXFONTS "/var/cache/fonts"
#endif
#ifndef DEFAULT_TEXMFDBS
#define DEFAULT_TEXMFDBS "/usr/share/texmf:/var/cache/fonts"
#endif
#ifndef DEFAULT_WEB2C
#define DEFAULT_WEB2C "/usr/share/texmf/web2c"
#endif
#ifndef DEFAULT_TEXINPUTS
#define DEFAULT_TEXINPUTS ".:/usr/share/texmf/tex/{generic,}//"
#endif
#ifndef DEFAULT_MFINPUTS
#define DEFAULT_MFINPUTS ".:/usr/share/texmf/metafont//:{/usr/share/texmf/fonts,/var/cache/fonts}/source//"
#endif
#ifndef DEFAULT_MPINPUTS
#define DEFAULT_MPINPUTS ".:/usr/share/texmf/metapost//"
#endif
#ifndef DEFAULT_TEXFORMATS
#define DEFAULT_TEXFORMATS ".:/usr/share/texmf/web2c"
#endif
#ifndef DEFAULT_MFBASES
#define DEFAULT_MFBASES ".:/usr/share/texmf/web2c"
#endif
#ifndef DEFAULT_MPMEMS
#define DEFAULT_MPMEMS ".:/usr/share/texmf/web2c"
#endif
#ifndef DEFAULT_TEXPOOL
#define DEFAULT_TEXPOOL ".:/usr/share/texmf/web2c"
#endif
#ifndef DEFAULT_MFPOOL
#define DEFAULT_MFPOOL ".:/usr/share/texmf/web2c"
#endif
#ifndef DEFAULT_MPPOOL
#define DEFAULT_MPPOOL ".:/usr/share/texmf/web2c"
#endif
#ifndef DEFAULT_VFFONTS
#define DEFAULT_VFFONTS ".:/usr/share/texmf/fonts/vf//"
#endif
#ifndef DEFAULT_TFMFONTS
#define DEFAULT_TFMFONTS ".:{/usr/share/texmf/fonts,/var/cache/fonts}/tfm//"
#endif
#ifndef DEFAULT_PKFONTS
#define DEFAULT_PKFONTS ".:{/usr/share/texmf/fonts,/var/cache/fonts}/pk/{$MAKETEX_MODE,modeless}//"
#endif
#ifndef DEFAULT_GFFONTS
#define DEFAULT_GFFONTS ".:/usr/share/texmf/fonts/gf/$MAKETEX_MODE//"
#endif
#ifndef DEFAULT_GLYPHFONTS
#define DEFAULT_GLYPHFONTS ".:/usr/share/texmf/fonts"
#endif
#ifndef DEFAULT_TEXFONTMAPS
#define DEFAULT_TEXFONTMAPS ".:/usr/share/texmf/fontname"
#endif
#ifndef DEFAULT_BIBINPUTS
#define DEFAULT_BIBINPUTS ".:/usr/share/texmf/bibtex/{bib,}//"
#endif
#ifndef DEFAULT_BSTINPUTS
#define DEFAULT_BSTINPUTS ".:/usr/share/texmf/bibtex/{bst,}//"
#endif
#ifndef DEFAULT_MFTINPUTS
#define DEFAULT_MFTINPUTS ".:/usr/share/texmf/mft//"
#endif
#ifndef DEFAULT_TEXPSHEADERS
#define DEFAULT_TEXPSHEADERS ".:/usr/share/texmf/{dvips,pdftex,tex,fonts/type1}//"
#endif
#ifndef DEFAULT_T1FONTS
#define DEFAULT_T1FONTS ".:/usr/share/texmf/fonts/type1//"
#endif
#ifndef DEFAULT_AFMFONTS
#define DEFAULT_AFMFONTS ".:/usr/share/texmf/fonts/afm//"
#endif
#ifndef DEFAULT_TTFONTS
#define DEFAULT_TTFONTS ".:/usr/share/texmf/fonts/truetype//"
#endif
#ifndef DEFAULT_T42FONTS
#define DEFAULT_T42FONTS ".:/usr/share/texmf/fonts/type42//"
#endif
#ifndef DEFAULT_TEXCONFIG
#define DEFAULT_TEXCONFIG ".:/usr/share/texmf/dvips//"
#endif
#ifndef DEFAULT_INDEXSTYLE
#define DEFAULT_INDEXSTYLE ".:/usr/share/texmf/makeindex//"
#endif
#ifndef DEFAULT_TRFONTS
#define DEFAULT_TRFONTS "/usr/lib/font/devpost"
#endif
#ifndef DEFAULT_MPSUPPORT
#define DEFAULT_MPSUPPORT ".:/usr/share/texmf/metapost/support"
#endif
#ifndef DEFAULT_MIMELIBDIR
#define DEFAULT_MIMELIBDIR "/usr/share/texmf/etc"
#endif
#ifndef DEFAULT_MAILCAPLIBDIR
#define DEFAULT_MAILCAPLIBDIR "/usr/share/texmf/etc"
#endif
#ifndef DEFAULT_TEXDOCS
#define DEFAULT_TEXDOCS ".:/usr/share/texmf/doc//"
#endif
#ifndef DEFAULT_TEXSOURCES
#define DEFAULT_TEXSOURCES ".:/usr/share/texmf/source//"
#endif
#ifndef DEFAULT_OFMFONTS
#define DEFAULT_OFMFONTS ".:{/usr/share/texmf/fonts,/var/cache/fonts}/{ofm,tfm}//:$TFMFONTS"
#endif
#ifndef DEFAULT_OPLFONTS
#define DEFAULT_OPLFONTS ".:{/usr/share/texmf/fonts,/var/cache/fonts}/opl//"
#endif
#ifndef DEFAULT_OVFFONTS
#define DEFAULT_OVFFONTS ".:{/usr/share/texmf/fonts,/var/cache/fonts}/ovf//"
#endif
#ifndef DEFAULT_OVPFONTS
#define DEFAULT_OVPFONTS ".:{/usr/share/texmf/fonts,/var/cache/fonts}/ovp//"
#endif
#ifndef DEFAULT_OTPINPUTS
#define DEFAULT_OTPINPUTS ".:/usr/share/texmf/omega/otp//"
#endif
#ifndef DEFAULT_OCPINPUTS
#define DEFAULT_OCPINPUTS ".:/usr/share/texmf/omega/ocp//"
#endif
#ifndef DEFAULT_T4HTINPUTS
#define DEFAULT_T4HTINPUTS ".:/usr/share/texmf/tex4ht//"
#endif
#ifndef DEFAULT_KPSE_DOT
#define DEFAULT_KPSE_DOT "."
#endif
#ifndef DEFAULT_TEXMFCNF
#define DEFAULT_TEXMFCNF "{$SELFAUTOLOC,$SELFAUTODIR,$SELFAUTOPARENT}{,{/share,}/texmf{.local,}/web2c}:$TETEXDIR:/usr/share/texmf/web2c:/usr/share/texmf/web2c"
#endif
#ifndef DEFAULT_MISSFONT_LOG
#define DEFAULT_MISSFONT_LOG "missfont.log"
#endif
#ifndef DEFAULT_TEX_HUSH
#define DEFAULT_TEX_HUSH "none"
#endif
#ifndef DEFAULT_MPXCOMMAND
#define DEFAULT_MPXCOMMAND "makempx"
#endif
