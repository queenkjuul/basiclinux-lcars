# Danish translation KDE Organizer
# Copyright (C) 1998 Free Software Foundation, Inc.
# Erik Kj�r Pedersen <erik@binghamton.edu>, 1999.
#
msgid ""
msgstr ""
"Project-Id-Version: KORGANIZER\n"
"POT-Creation-Date: 1999-04-20 03:16+0200\n"
"PO-Revision-Date: 1999-02-17 07:15-0500\n"
"Last-Translator: Erik Kj�r Pedersen\n"
"Language-Team: da <LL@li.org>\n"
"MIME-Version: 1.0\n"
"Content-Type: text/plain; charset=ISO_8859-1\n"
"Content-Transfer-Encoding: 8bit\n"

#: alarmdaemon.cpp:38 alarmdaemon.cpp:43 calobject.cpp:372 calobject.cpp:385
#: eventwindetails.cpp:341 eventwindetails.cpp:361 searchdialog.cpp:80
#: topwidget.cpp:959 topwidget.cpp:967 topwidget.cpp:1110 topwidget.cpp:1136
#: topwidget.cpp:1140
msgid "KOrganizer Error"
msgstr "KOrganizer-fejl"

#: calobject.cpp:373 calobject.cpp:386
msgid ""
"An error has occurred parsing the contents of the clipboard.\n"
"You can only paste a valid vCalendar into KOrganizer.\n"
msgstr ""
"Fejl ved fors�g p� at inds�tte fra klippebordet.\n"
"Kun gyldige vCalendar data kan inds�ttes i KOrganizer.\n"

#: calobject.cpp:434
msgid "found a VEvent with no DTSTART/DTEND! Skipping"
msgstr "fandt en VEvent uden DTSTART/DTEND! Springer over"

#: catdlg.cpp:19
msgid "KOrganizer Categories"
msgstr "KOrganizer-kategorier"

#: catdlg.cpp:30
msgid "Available Categories"
msgstr "Tilg�ngelige kategorier..."

#: catdlg.cpp:36 eventwin.cpp:297 optionsdlg.cpp:227 optionsdlg.cpp:233
#: optionsdlg.cpp:239
msgid "Appointment"
msgstr "Aftale"

#: catdlg.cpp:37
msgid "Business"
msgstr "Forretning"

#: catdlg.cpp:38
msgid "Meeting"
msgstr "M�de"

#: catdlg.cpp:39
msgid "Phone Call"
msgstr "Telefonopringing"

#: catdlg.cpp:40
msgid "Education"
msgstr "Uddannelse"

#: catdlg.cpp:41
msgid "Holiday"
msgstr "Fridag"

#: catdlg.cpp:42
msgid "Vacation"
msgstr "Ferie"

#: catdlg.cpp:43
msgid "Special Occasion"
msgstr "Speciel begivenhed"

#: catdlg.cpp:44 optionsdlg.cpp:34
msgid "Personal"
msgstr "Personlig"

#: catdlg.cpp:45
msgid "Travel"
msgstr "Rejse"

#: catdlg.cpp:55
msgid "&Add >>"
msgstr "&Tilf�j >>"

#: catdlg.cpp:57
msgid "<< &Remove"
msgstr "<< &Fjern"

#: catdlg.cpp:66
msgid "Selected Categories"
msgstr "Udvalgte kategorier..."

#: catdlg.cpp:78
msgid "New Category:"
msgstr "Ny kategori:"

#: editeventwin.cpp:116 todoeventwin.cpp:108
msgid "General"
msgstr "Generelt"

#: editeventwin.cpp:117 todoeventwin.cpp:109
msgid "Details"
msgstr "Detaljer"

#: editeventwin.cpp:119
msgid "Recurrence"
msgstr "Gentagelser"

#: editeventwin.cpp:195 editeventwin.cpp:406 todoeventwin.cpp:162
#: todoeventwin.cpp:182
#, c-format
msgid "Owner: %s"
msgstr "Ejer: %s"

#: editeventwin.cpp:810
msgid "Duration: all day"
msgstr "Varighed: hele dagen"

#: editeventwin.cpp:818
#, c-format
msgid "Duration: %i hour(s), %i minute(s)"
msgstr "Varighed: %i time(r), %i minutt(er)"

#: editeventwin.cpp:820
#, c-format
msgid "Duration: %i hour(s)"
msgstr "Varighed: %i time(r)"

#: editeventwin.cpp:822
#, c-format
msgid "Duration: %i minute(s)"
msgstr "Varighed: %i minutt(er)"

#: eventwidget.cpp:193
msgid "Toggle Alarm"
msgstr "Sl� Alarm til/fra"

#: eventwingeneral.cpp:42 eventwinrecur.cpp:28 wingeneral.cpp:34
msgid "Appointment Time"
msgstr "Aftaletidspunkt"

#: eventwingeneral.cpp:47 wingeneral.cpp:39
msgid "Start Time:"
msgstr "Starttid:"

#: eventwingeneral.cpp:58 wingeneral.cpp:48
msgid "End Time:"
msgstr "Sluttid:"

#: eventwingeneral.cpp:80 wingeneral.cpp:64
msgid "No time associated"
msgstr "Ingen tid fastsat"

#: eventwingeneral.cpp:91 wingeneral.cpp:75
msgid "Recurring event"
msgstr "Gentagende"

#: eventwingeneral.cpp:99 todowingeneral.cpp:77
msgid "Summary:"
msgstr "Kort beskrivelse:"

#: eventwingeneral.cpp:110
msgid "Show Time As:"
msgstr "Vis tid som:"

#: eventwingeneral.cpp:117
msgid "Busy"
msgstr "Optaget"

#: eventwingeneral.cpp:118
msgid "Free"
msgstr "Ledig"

#: eventwingeneral.cpp:133 todowingeneral.cpp:96
msgid "Owner:"
msgstr "Ejer:"

#: eventwingeneral.cpp:139 todowingeneral.cpp:102
msgid "Private"
msgstr "Privat"

#: eventwindetails.cpp:199 eventwingeneral.cpp:145 todowingeneral.cpp:108
msgid "Categories..."
msgstr "Kategorier..."

#: eventwingeneral.cpp:164
msgid "Reminder:"
msgstr "Alarm:"

#: eventwindetails.cpp:39
msgid "Attendee Information"
msgstr "Kontaktinformation"

#: eventwindetails.cpp:46
msgid "Name"
msgstr "Navn"

#: eventwindetails.cpp:47
msgid "Email"
msgstr "E-post"

#: eventwindetails.cpp:48
msgid "Role"
msgstr "Rolle"

#: eventwindetails.cpp:49
msgid "Status"
msgstr "Status"

#: eventwindetails.cpp:50
msgid "RSVP"
msgstr "Svar udbedes"

#: eventwindetails.cpp:65
msgid "Attendee Name:"
msgstr "Kontaktens navn:"

#: eventwindetails.cpp:77
msgid "Email Address:"
msgstr "E-postadresse:"

#: eventwindetails.cpp:92
msgid "Role:"
msgstr "Rolle:"

#: eventwindetails.cpp:98
msgid "Attendee"
msgstr "Kontakt"

#: eventwindetails.cpp:99
msgid "Organizer"
msgstr "Organisator"

#: eventwindetails.cpp:100
msgid "Owner"
msgstr "Ejer"

#: eventwindetails.cpp:101
msgid "Delegate"
msgstr "Deltager"

#: eventwindetails.cpp:106
msgid "Status:"
msgstr "Status:"

#: eventwindetails.cpp:112
msgid "Needs Action"
msgstr "M� kontaktes"

#: eventwindetails.cpp:113
msgid "Accepted"
msgstr "Accepteret"

#: eventwindetails.cpp:114
msgid "Sent"
msgstr "Sendt"

#: eventwindetails.cpp:115
msgid "Tentative"
msgstr "Forel�big"

#: eventwindetails.cpp:116
msgid "Confirmed"
msgstr "Bekr�ftet"

#: eventwindetails.cpp:117
msgid "Declined"
msgstr "Afsl�et"

#: eventwindetails.cpp:118 todowingeneral.cpp:35 todowingeneral.cpp:52
msgid "Completed"
msgstr "F�rdig"

#: eventwindetails.cpp:119
msgid "Delegated"
msgstr "Delegeret"

#: eventwindetails.cpp:126
msgid "Request Response"
msgstr "Bed om svar"

#: eventwindetails.cpp:132
msgid "&Add"
msgstr "&Tilf�j"

#: eventwindetails.cpp:136
msgid "Address &Book..."
msgstr "Adresse&bog..."

#: eventwindetails.cpp:163
msgid "Attach..."
msgstr "Vedh�ng..."

#: eventwindetails.cpp:183
msgid "Save As..."
msgstr "Gem som..."

#: eventwindetails.cpp:218
msgid "Priority:"
msgstr "Prioritet:"

#: eventwindetails.cpp:224
msgid "Low (1)"
msgstr "Lav (1)"

#: eventwindetails.cpp:225
msgid "Normal (2)"
msgstr "Normal (2)"

#: eventwindetails.cpp:226
msgid "High (3)"
msgstr "H�j (3)"

#: eventwindetails.cpp:227
msgid "Maximum (4)"
msgstr "Maksimal (4)"

#: eventwindetails.cpp:342
msgid "Unable to open address book."
msgstr "Kan ikke �bne addressebogen"

#: eventwindetails.cpp:362
msgid "Error getting entry from address book."
msgstr "Fejl ved at hente noget fra addressebogen"

#: eventwinrecur.cpp:30
msgid "Start:  "
msgstr "Start:  "

#: eventwinrecur.cpp:31
msgid "End:  "
msgstr "Slut:  "

#: eventwinrecur.cpp:61
msgid "Recurrence Rule"
msgstr "Gentagelsesregel"

#: eventwinrecur.cpp:67
msgid "Daily"
msgstr "Daglig"

#: eventwinrecur.cpp:68
msgid "Weekly"
msgstr "Ugentlig"

#: eventwinrecur.cpp:69
msgid "Monthly"
msgstr "M�nedlig"

#: eventwinrecur.cpp:70
msgid "Yearly"
msgstr "�rlig"

#: eventwinrecur.cpp:95
msgid "Enable Advanced Rule:"
msgstr "Aktiver avanceret regel:"

#: eventwinrecur.cpp:128
msgid "Recurrence Range"
msgstr "Gentagelses tidsrum"

#: eventwinrecur.cpp:132
msgid "Begin On:"
msgstr "Begynd den:"

#: eventwinrecur.cpp:134
msgid "No Ending Date"
msgstr "Ingen slutdato"

#: eventwinrecur.cpp:135
msgid "End after"
msgstr "Afslut efter"

#: eventwinrecur.cpp:137
msgid "occurrence(s)"
msgstr "forekomst(er)"

#: eventwinrecur.cpp:138
msgid "End by:"
msgstr "Afslut inden:"

#: eventwinrecur.cpp:181
msgid "Exceptions"
msgstr "Undtagelser"

#: eventwinrecur.cpp:267 eventwinrecur.cpp:297
msgid "Recur every"
msgstr "Gentag hver"

#: eventwinrecur.cpp:273
msgid "day(s)"
msgstr "dag(e)"

#: eventwinrecur.cpp:303
msgid "week(s) on:"
msgstr "uge(r) om:"

#: eventwinrecur.cpp:305 kagenda.cpp:106
msgid "Sun"
msgstr "S�n"

#: eventwinrecur.cpp:306 kagenda.cpp:105
msgid "Mon"
msgstr "Man"

#: eventwinrecur.cpp:307 kagenda.cpp:105
msgid "Tue"
msgstr "Tir"

#: eventwinrecur.cpp:308 kagenda.cpp:105
msgid "Wed"
msgstr "Ons"

#: eventwinrecur.cpp:309 kagenda.cpp:106
msgid "Thu"
msgstr "Tor"

#: eventwinrecur.cpp:310 kagenda.cpp:106
msgid "Fri"
msgstr "Fre"

#: eventwinrecur.cpp:311 kagenda.cpp:106
msgid "Sat"
msgstr "L�r"

#: eventwinrecur.cpp:361 eventwinrecur.cpp:365
msgid "Recur on the"
msgstr "Gentag den"

#: eventwinrecur.cpp:363
msgid "day"
msgstr "Dag"

#: eventwinrecur.cpp:369 eventwinrecur.cpp:481
msgid "every"
msgstr "hver"

#: eventwinrecur.cpp:371
msgid "month(s)"
msgstr "m�ned(er)"

#: eventwinrecur.cpp:383 eventwinrecur.cpp:424
msgid "1st"
msgstr "1."

#: eventwinrecur.cpp:384 eventwinrecur.cpp:425
msgid "2nd"
msgstr "2."

#: eventwinrecur.cpp:385 eventwinrecur.cpp:426
msgid "3rd"
msgstr "3."

#: eventwinrecur.cpp:386 eventwinrecur.cpp:427
msgid "4th"
msgstr "4."

#: eventwinrecur.cpp:387 eventwinrecur.cpp:428
msgid "5th"
msgstr "5."

#: eventwinrecur.cpp:388
msgid "6th"
msgstr "6."

#: eventwinrecur.cpp:389
msgid "7th"
msgstr "7."

#: eventwinrecur.cpp:390
msgid "8th"
msgstr "8."

#: eventwinrecur.cpp:391
msgid "9th"
msgstr "9."

#: eventwinrecur.cpp:392
msgid "10th"
msgstr "10."

#: eventwinrecur.cpp:393
msgid "11th"
msgstr "11."

#: eventwinrecur.cpp:394
msgid "12th"
msgstr "12."

#: eventwinrecur.cpp:395
msgid "13th"
msgstr "13."

#: eventwinrecur.cpp:396
msgid "14th"
msgstr "14."

#: eventwinrecur.cpp:397
msgid "15th"
msgstr "15."

#: eventwinrecur.cpp:398
msgid "16th"
msgstr "16."

#: eventwinrecur.cpp:399
msgid "17th"
msgstr "17."

#: eventwinrecur.cpp:400
msgid "18th"
msgstr "18."

#: eventwinrecur.cpp:401
msgid "19th"
msgstr "19."

#: eventwinrecur.cpp:402
msgid "20th"
msgstr "20."

#: eventwinrecur.cpp:403
msgid "21st"
msgstr "21."

#: eventwinrecur.cpp:404
msgid "22nd"
msgstr "22."

#: eventwinrecur.cpp:405
msgid "23rd"
msgstr "23."

#: eventwinrecur.cpp:406
msgid "24th"
msgstr "24."

#: eventwinrecur.cpp:407
msgid "25th"
msgstr "25."

#: eventwinrecur.cpp:408
msgid "26th"
msgstr "26."

#: eventwinrecur.cpp:409
msgid "27th"
msgstr "27."

#: eventwinrecur.cpp:410
msgid "28th"
msgstr "28."

#: eventwinrecur.cpp:411
msgid "29th"
msgstr "29."

#: eventwinrecur.cpp:412
msgid "30th"
msgstr "30."

#: eventwinrecur.cpp:413
msgid "31st"
msgstr "31."

#: eventwinrecur.cpp:466
msgid "Recur in the month of"
msgstr "Gentag i m�neden"

#: eventwinrecur.cpp:467
msgid "Recur on this day"
msgstr "Gentag denne dag"

#: calprinter.cpp:327 calprinter.cpp:429 calprinter.cpp:720
#: eventwinrecur.cpp:469 kdatenav.cpp:68 kdatenav.cpp:258
msgid "January"
msgstr "Januar"

#: calprinter.cpp:327 calprinter.cpp:429 calprinter.cpp:720
#: eventwinrecur.cpp:470 kdatenav.cpp:68 kdatenav.cpp:258
msgid "February"
msgstr "Februar"

#: calprinter.cpp:328 calprinter.cpp:430 calprinter.cpp:721
#: eventwinrecur.cpp:471 kdatenav.cpp:68 kdatenav.cpp:259
msgid "March"
msgstr "Marts"

#: calprinter.cpp:328 calprinter.cpp:430 calprinter.cpp:721
#: eventwinrecur.cpp:472 kdatenav.cpp:69 kdatenav.cpp:259
msgid "April"
msgstr "April"

#: calprinter.cpp:329 calprinter.cpp:431 calprinter.cpp:722
#: eventwinrecur.cpp:473 kdatenav.cpp:69 kdatenav.cpp:260
msgid "May"
msgstr "Maj"

#: calprinter.cpp:329 calprinter.cpp:431 calprinter.cpp:722
#: eventwinrecur.cpp:474 kdatenav.cpp:69 kdatenav.cpp:260
msgid "June"
msgstr "Juni"

#: calprinter.cpp:330 calprinter.cpp:432 calprinter.cpp:723
#: eventwinrecur.cpp:475 kdatenav.cpp:69 kdatenav.cpp:261
msgid "July"
msgstr "Juli"

#: calprinter.cpp:330 calprinter.cpp:432 calprinter.cpp:723
#: eventwinrecur.cpp:476 kdatenav.cpp:70 kdatenav.cpp:261
msgid "August"
msgstr "August"

#: calprinter.cpp:331 calprinter.cpp:433 calprinter.cpp:724
#: eventwinrecur.cpp:477 kdatenav.cpp:70 kdatenav.cpp:262
msgid "September"
msgstr "September"

#: calprinter.cpp:331 calprinter.cpp:433 calprinter.cpp:724
#: eventwinrecur.cpp:478 kdatenav.cpp:70 kdatenav.cpp:262
msgid "October"
msgstr "Oktober"

#: calprinter.cpp:332 calprinter.cpp:434 calprinter.cpp:725
#: eventwinrecur.cpp:479 kdatenav.cpp:71 kdatenav.cpp:263
msgid "November"
msgstr "November"

#: calprinter.cpp:332 calprinter.cpp:434 calprinter.cpp:725
#: eventwinrecur.cpp:480 kdatenav.cpp:71 kdatenav.cpp:263
msgid "December"
msgstr "December"

#: eventwinrecur.cpp:484
msgid "year(s)"
msgstr "�r"

#: kagenda.cpp:212
msgid "All Day Event"
msgstr "Hele dagen"

#: kagenda.cpp:829
msgid "New appointment"
msgstr "Ny Aftale"

#: kagenda.cpp:966 kagenda.cpp:974
msgid "am"
msgstr "am"

#: kagenda.cpp:970
msgid "pm"
msgstr "pm"

#: kdatenav.cpp:44
msgid "Previous Year"
msgstr "Forrige �r"

#: kdatenav.cpp:50
msgid "Previous Month"
msgstr "Forrige m�ned"

#: kdatenav.cpp:56
msgid "Next Month"
msgstr "N�ste m�ned"

#: kdatenav.cpp:62
msgid "Next Year"
msgstr "N�ste �r"

#: kmonthview.cpp:386
msgid "New Event"
msgstr "Ny begivenhed"

#: kpbutton.cpp:22 kpbutton.cpp:40 kpbutton.cpp:90
msgid "KPButton: pixmap is empty, perhaps some missing file"
msgstr "KPButton: billedet findes ikke, m�ske mangler en fil"

#: baselistview.cpp:28
msgid "Date"
msgstr "Dato"

#: baselistview.cpp:29
msgid "Time"
msgstr "Tid"

#: baselistview.cpp:30 calprinter.cpp:365
msgid "Summary"
msgstr "Kort beskrivelse"

#: baselistview.cpp:77
msgid "started "
msgstr "startet "

#: baselistview.cpp:80
msgid "ends "
msgstr "afslutter "

#: baselistview.cpp:85
#, c-format
msgid "repeats %d times"
msgstr "gentages %. gange"

#: baselistview.cpp:89
msgid "repeats forever"
msgstr "gentages evigt"

#: listview.cpp:14
msgid "Edit Event"
msgstr "�ndr begivenhed"

#: listview.cpp:17
msgid "Delete Event  "
msgstr "Slet Aftale"

#: listview.cpp:20
msgid "Show Dates"
msgstr "Vis dato"

#: listview.cpp:22
msgid "Hide Dates"
msgstr "Skjul Dato"

#: main.cpp:29
msgid "No default calendar, and none was specified on the command line.\n"
msgstr ""
"Der er ingen standardkalender, og der blev ikke angivet en i\n"
"kommandolinien\n"

#: main.cpp:33
msgid "Error reading from default calendar.\n"
msgstr "Fejl ved indl�sning fra standard kalender.\n"

#: searchdialog.cpp:22
msgid "Search For:"
msgstr "S�g efter:"

#: searchdialog.cpp:32 topwidget.cpp:494
msgid "&Search"
msgstr "&S�g"

#: searchdialog.cpp:81
msgid ""
"Invalid search expression, cannot perform\n"
"the search.  Please enter a search expression\n"
"using the wildcard characters '*' and '?'\n"
"where needed."
msgstr ""
"Ugyldigt s�geudtryk, kan ikke udf�re s�gningen\n"
"Indtast et s�geudtryk med '*' og '?' som vilde\n"
"tegn hvor det beh�ves."

#: topwidget.cpp:391
msgid "&Open"
msgstr "�&bn"

#: topwidget.cpp:394
msgid "Open &Recent"
msgstr "�bn &forrige"

#: topwidget.cpp:410
msgid "Save &As"
msgstr "Gem &som"

#: topwidget.cpp:415
msgid "&Import From Ical"
msgstr "&Importer fra Ical..."

#: topwidget.cpp:417
msgid "&Merge Calendar"
msgstr "&Kombiner Kalender..."

#: topwidget.cpp:420
msgid "Archive Old Entries"
msgstr "Arkiver �ldre data..."

#: topwidget.cpp:427
msgid "Print Setup"
msgstr "Skriver ops�tning.."

#: calprinter.cpp:844 topwidget.cpp:431
msgid "&Print"
msgstr "&Udskriv"

#: topwidget.cpp:433
msgid "Print Pre&view"
msgstr "Forh�ndsvisning"

#: topwidget.cpp:455
msgid "&List"
msgstr "&Liste"

#: topwidget.cpp:459
msgid "&Day"
msgstr "&Dag"

#: topwidget.cpp:462
msgid "W&ork Week"
msgstr "A&rbejdsuge"

#: topwidget.cpp:465
msgid "&Week"
msgstr "&Uge"

#: topwidget.cpp:468
msgid "&Month"
msgstr "&M�ned"

#: topwidget.cpp:471
msgid "&To-do list"
msgstr "&G�rem�lsliste"

#: topwidget.cpp:479
msgid "New &Appointment"
msgstr "Ny &Aftale"

#: topwidget.cpp:481
msgid "New E&vent"
msgstr "Ny &Begivenhed"

#: topwidget.cpp:483
msgid "&Edit Appointment"
msgstr "�&ndr aftale"

#: topwidget.cpp:486
msgid "&Delete Appointment"
msgstr "S&let aftale"

#: topwidget.cpp:488
msgid "Delete To-do"
msgstr "Slet g�rem�l"

#: topwidget.cpp:498
msgid "&Mail Appointment"
msgstr "E-&post aftale"

#: topwidget.cpp:504
msgid "Go to &Today"
msgstr "G� til i&dag"

#: topwidget.cpp:508
msgid "&Previous Day"
msgstr "I&g�r"

#: topwidget.cpp:512
msgid "&Next Day"
msgstr "I&morgen"

#: topwidget.cpp:516
msgid "Show &Tool Bar"
msgstr "Vis &v�rkt�sbj�lke"

#: topwidget.cpp:520
msgid "Show St&atus Bar"
msgstr "Vis &statusbj�lke"

#: topwidget.cpp:525
msgid "&Edit Options"
msgstr "Rediger &indstillinger"

#: topwidget.cpp:533
msgid "&About"
msgstr "&Om"

#: topwidget.cpp:535
msgid "Send &Bug Report"
msgstr "Send &fejlrapport"

#: topwidget.cpp:543
msgid "&Actions"
msgstr "H&andlinger"

#: topwidget.cpp:562
msgid "Open A Calendar"
msgstr "�bn en kalender"

#: topwidget.cpp:568
msgid "Save This Calendar"
msgstr "Gem denne kalender"

#: topwidget.cpp:585
msgid "New Appointment"
msgstr "Ny aftale"

#: topwidget.cpp:591
msgid "Delete Appointment"
msgstr "Slet aftale"

#: topwidget.cpp:597
msgid "Search For an Appointment"
msgstr "S�g efter aftale"

#: topwidget.cpp:603
msgid "Mail Appointment"
msgstr "E-post aftale"

#: topwidget.cpp:622
msgid "Go to Today"
msgstr "G� til idag"

#: topwidget.cpp:628
msgid "Previous Day"
msgstr "Ig�r"

#: topwidget.cpp:634
msgid "Next Day"
msgstr "Imorgen"

#: topwidget.cpp:650
msgid "List View"
msgstr "Vis liste"

#: topwidget.cpp:655
msgid "Schedule View"
msgstr "Vis plan"

#: topwidget.cpp:662
msgid "Month View"
msgstr "Vis m�ned"

#: topwidget.cpp:668
msgid "To-do list view"
msgstr "Vis g�rem�lsliste"

#: topwidget.cpp:750
msgid "we don't handle updates for that view, yet.\n"
msgstr "Kan ikke opdatere her endnu\n"

#: topwidget.cpp:842
msgid "we don't handle that view yet.\n"
msgstr "vi kan ikke h�ndtere dette endnu.\n"

#: topwidget.cpp:960
msgid "You did not specify a valid file name."
msgstr "Du angav ikke et gyldigt filnavn"

#: topwidget.cpp:968
msgid ""
"The file you specified is a directory,\n"
"and cannot be opened. Please try again,\n"
"this time selecting a valid calendar file."
msgstr ""
"Den fil du angav er en folder, og den\n"
"kan ikke �bnes. Pr�v bare igen men v�lg\n"
"en gyldig kalenderfil denne gnag."

#: topwidget.cpp:995
msgid "KOrganizer Warning"
msgstr "KOrganizer-advarsel"

#: topwidget.cpp:996
msgid ""
"This calendar has been modified.\n"
"Would you like to save it?"
msgstr ""
"Den kalender du er ved at lukke er blevet �ndret.\n"
"Vil du gemme �ndringerne?"

#: topwidget.cpp:998
msgid "&Yes"
msgstr "&Ja"

#: topwidget.cpp:998
msgid "&No"
msgstr "&Nej"

#: topwidget.cpp:1007 topwidget.cpp:1597
msgid "KOrganizer Confirmation"
msgstr "KOrganizer-bekr�ftelse"

#: topwidget.cpp:1008
msgid "This item will be permanently deleted."
msgstr "Dette emne bliver slettet permanent."

#: topwidget.cpp:1111
msgid ""
"You have no ical file in your home directory.\n"
"Import cannot proceed.\n"
msgstr ""
"Du har ingen ical-fil i din hjemmefolder.\n"
"\n"
"Import kan ikke forts�tte.\n"

#: topwidget.cpp:1124
msgid "KOrganizer Info"
msgstr "KOrganizer-info"

#: topwidget.cpp:1125
msgid ""
"KOrganizer succesfully imported and merged your\n"
".calendar file from ical into the currently\n"
"opened calendar.\n"
msgstr ""
"Det lykkedes for KOrganizer at importere og indflette\n"
"din .calendar-fil fra ical i den kalender\n"
"som nu er �bnet.\n"

#: topwidget.cpp:1130
msgid "ICal Import Successful With Warning"
msgstr "ICal-import lykkedes med advarsel"

#: topwidget.cpp:1131
msgid ""
"KOrganizer encountered some unknown fields while\n"
"parsing your .calendar ical file, and had to\n"
"discard them.  Please check to see that all\n"
"your relevant data was correctly imported.\n"
msgstr ""
"KOrganizer st�dte p� nogle ukendte felter ved\n"
"analyse af din .calendar-fil fra ical, og\n"
"m�tte derfor forkaste dem. Unders�g venliigst om\n"
"all relevante data blev korrekt importeret.\n"

#: topwidget.cpp:1137
msgid ""
"KOrganizer encountered some error parsing your\n"
".calendar file from ical.  Import has failed.\n"
msgstr ""
"KOrganizer st�dte p� en fejl ved analyse\n"
"af din .calendar-fil fra ical. Import mislykkedes.\n"

#: topwidget.cpp:1141
msgid ""
"KOrganizer doesn't think that your .calendar\n"
"file is a valid ical calendar. Import has failed.\n"
msgstr ""
"KOrganizer tror ikke at din .calendar\n"
"-fil er en\n"
"gyldig ical-kalender. Import mislykkedes.\n"

#: topwidget.cpp:1305 topwidget.cpp:1332 topwidget.cpp:1683 topwidget.cpp:1693
msgid "KOrganizer error"
msgstr "KOrganizer-fejl"

#: topwidget.cpp:1306 topwidget.cpp:1333
msgid ""
"Unfortunately, we don't handle cut/paste for\n"
"that view yet.\n"
msgstr ""
"Uheldigvis under st�tter vi forel�big ikke denne\n"
"klip/klistre her.\n"

#: topwidget.cpp:1549
msgid "don't handle deletes from that view, yet.\n"
msgstr "st�tter forel�big ikke sletning herfra.\n"

#: topwidget.cpp:1598
msgid ""
"This event recurs over multiple dates.\n"
"Are you sure you want to delete the\n"
"selected event, or just this instance?\n"
msgstr ""
"Denne h�ndelse gentages over flere datoer.\n"
"Er du sikker p� at du �nsker at slette valgte\n"
"h�ndeldelse, eller kun dette tilf�lde?\n"

#: topwidget.cpp:1601
msgid "&All"
msgstr "&Alle"

#: topwidget.cpp:1601
msgid "&This"
msgstr "&Denne"

#: topwidget.cpp:1616
msgid "no date selected, or invalid date\n"
msgstr "ingen dato valgt, eller ugyldig dato\n"

#: topwidget.cpp:1684
msgid "Can't generate mail from this view\n"
msgstr "Kan ikke lave e-post herfra\n"

#: topwidget.cpp:1694
msgid ""
"Can't generate mail:\n"
" No attendees defined!\n"
msgstr ""
"Kan ikke generere e-post:\n"
"Ingen kontakter definerede!\n"

#: topwidget.cpp:1833
msgid "New Calendar"
msgstr "Ny kalender"

#: eventwin.cpp:313 eventwin.cpp:319 topwidget.cpp:1839
msgid "modified"
msgstr "�ndret"

#: eventwin.cpp:325 topwidget.cpp:1844
msgid "KOrganizer"
msgstr "KOrganisator"

#: calprinter.cpp:47
msgid "Korganizer Configuration Options"
msgstr "KOrganizer-Indstillingsmuligheder"

#: calprinter.cpp:361 todowingeneral.cpp:60
msgid "Priority"
msgstr "Prioritet"

#: calprinter.cpp:369
msgid "Due"
msgstr "Inden"

#: calprinter.cpp:453
#, c-format
msgid "To-Do items: %s %.2d"
msgstr "G�rem�l: %s %.2d"

#: calprinter.cpp:791
msgid "Date Range"
msgstr "Dato omr�de"

#: calprinter.cpp:811
msgid "View Type"
msgstr "Fremvisningstype"

#: calprinter.cpp:816
msgid "Day"
msgstr "Dag"

#: calprinter.cpp:821
msgid "Week"
msgstr "Uge"

#: calprinter.cpp:825
msgid "Month"
msgstr "M�ned"

#: calprinter.cpp:829
msgid "To-Do"
msgstr "G�rem�l"

#: calprinter.cpp:843
msgid "&Preview"
msgstr "&Fremvis"

#: koarchivedlg.cpp:19
msgid "Archive / Delete Past Appointments - KOrganizer"
msgstr "Arkiver / Slet gamle aftaler - KOrganizer"

#: optionsdlg.cpp:37
msgid "Time & Date"
msgstr "Tid og dato"

#: optionsdlg.cpp:43
msgid "Colors"
msgstr "Farver"

#: optionsdlg.cpp:46
msgid "Views"
msgstr "Visninger"

#: optionsdlg.cpp:52
msgid "Printing"
msgstr "Udskriver"

#: optionsdlg.cpp:65
msgid "KOrganizer Configuration"
msgstr "KOrganizerindstilling"

#: optionsdlg.cpp:92
msgid "Your name:"
msgstr "Dit navn:"

#: optionsdlg.cpp:96
msgid "Email address:"
msgstr "E-postadresse:"

#: optionsdlg.cpp:100
msgid "Additional:"
msgstr "Ekstra:"

#: optionsdlg.cpp:104
msgid "Auto-save Calendar"
msgstr "Autogem kalender"

#: optionsdlg.cpp:108
msgid "Confirm Appointment/To-Do Deletes"
msgstr "Bekr�ft aftale/g�rem�l sletning"

#: optionsdlg.cpp:112
msgid "Holidays:"
msgstr "Helligdage:"

#: optionsdlg.cpp:138
msgid "1 minute"
msgstr "1 minut"

#: optionsdlg.cpp:138
msgid "5 minutes"
msgstr "5 minutter"

#: optionsdlg.cpp:139
msgid "10 minutes"
msgstr "10 minutter"

#: optionsdlg.cpp:139
msgid "15 minutes"
msgstr "15 minutter"

#: optionsdlg.cpp:140
msgid "30 minutes"
msgstr "30 minutter"

#: optionsdlg.cpp:147
msgid "Time Format:"
msgstr "Tidsformat:"

#: optionsdlg.cpp:148
msgid "24 hour"
msgstr "24 timer"

#: optionsdlg.cpp:149
msgid "AM / PM"
msgstr "12 timer"

#: optionsdlg.cpp:153
msgid "Date Format:"
msgstr "Datoformat:"

#: optionsdlg.cpp:154
msgid "Day.Month.Year (31.01.2000)"
msgstr "Dag.M�ned.�r (31.01.2000)"

#: optionsdlg.cpp:155
msgid "Month/Day/Year (01/31/2000)"
msgstr "M�ned/Dag/�r (01/31/2000)"

#: optionsdlg.cpp:156
msgid "Month-Day-Year (01-31-2000)"
msgstr "M�ned-Dag-�r (01-31-2000)"

#: optionsdlg.cpp:160
msgid "Time Zone:"
msgstr "Tidszone:"

#: optionsdlg.cpp:167
msgid "Default Appointment Time:"
msgstr "Standard aftaletid:"

#: optionsdlg.cpp:177
msgid "Default Alarm Time:"
msgstr "Standard alarmtid:"

#: optionsdlg.cpp:185
msgid "Week Starts on Monday"
msgstr "Uge starter om mandagen"

#: optionsdlg.cpp:202
msgid "Day Begins At:"
msgstr "Dag begynder kl:"

#: optionsdlg.cpp:212
msgid "Hour size in schedule view"
msgstr "Timest�rrelse i skemavisning"

#: optionsdlg.cpp:216
msgid "Show events that recur daily in Date Navigator"
msgstr "Vis dagligt gentagne begivenheder i Dato navigat�r"

#: optionsdlg.cpp:228
msgid "List view font"
msgstr "Vis visningsskrift"

#: optionsdlg.cpp:234
msgid "Schedule view font"
msgstr "Skemavisningsskrift"

#: optionsdlg.cpp:240
msgid "Month view font"
msgstr "M�nedvisningsskrift"

#: optionsdlg.cpp:245
msgid "12345"
msgstr "12345"

#: optionsdlg.cpp:245
msgid "Time bar font"
msgstr "Tidsbj�lke font"

#: optionsdlg.cpp:250
msgid "Things to do"
msgstr "Ting som skal g�res"

#: optionsdlg.cpp:251
msgid "To-Do list font"
msgstr "G�rem�lslisteskrift"

#: optionsdlg.cpp:272
msgid "Use system default colors"
msgstr "Brug farverne fra systemstandarden"

#: optionsdlg.cpp:277
msgid "Appointment & Checklist items"
msgstr "Aftale 0g checklisteemner"

#: optionsdlg.cpp:278
msgid "Background"
msgstr "Baggrund"

#: optionsdlg.cpp:281
msgid "Text"
msgstr "Tekst"

#: optionsdlg.cpp:284
msgid "Handle Selected"
msgstr "H�ndter valgte"

#: optionsdlg.cpp:287
msgid "Handle Unselected"
msgstr "H�ndter ikkevalgte"

#: optionsdlg.cpp:290
msgid "Handle Active Apt."
msgstr "H�ndter g�ldende aftale"

#: optionsdlg.cpp:295
msgid "Sheet background"
msgstr "Ark-baggrund"

#: optionsdlg.cpp:298
msgid "Calendar Background"
msgstr "Baggrund i kalender"

#: optionsdlg.cpp:301
msgid "Calendar Date Text"
msgstr "Datotekst i kalender"

#: optionsdlg.cpp:304
msgid "Calendar Date Selected"
msgstr "Datovalg i kalender"

#: optionsdlg.cpp:343
msgid "Printer Name"
msgstr "Skrivernavn"

#: optionsdlg.cpp:373
msgid "Paper Size"
msgstr "Papirst�rrelse"

#: optionsdlg.cpp:375
msgid "A4"
msgstr "A4"

#: optionsdlg.cpp:376
msgid "B5"
msgstr "B5"

#: optionsdlg.cpp:377
msgid "Letter"
msgstr "Letter"

#: optionsdlg.cpp:378
msgid "Legal"
msgstr "Legal"

#: optionsdlg.cpp:379
msgid "Executive"
msgstr "Executive"

#: optionsdlg.cpp:383
msgid "Paper Orientation"
msgstr "Papirorientering"

#: optionsdlg.cpp:385
msgid "Portrait"
msgstr "St�ende"

#: optionsdlg.cpp:387
msgid "Landscape"
msgstr "Liggende"

#: optionsdlg.cpp:394
msgid "Preview Program"
msgstr "Forh�ndsvisningsprogram"

#: kpropdlg.cpp:124
msgid "Prev"
msgstr "Forrige"

#: kpropdlg.cpp:125
msgid "Next"
msgstr "N�ste"

#: aboutdlg.cpp:20
msgid "KOrganizer Virtual Postcard"
msgstr "KOrganizer virtuelt postkort"

#: aboutdlg.cpp:24
msgid ""
"Please send a postcard to me, so I can see who is\n"
"using KOrganizer! Tell me how great the program is,\n"
"and how you just can't live without it.  Or, report\n"
"a bug which is stopping you from doing useful work.\n"
"The postcard will simply include anything you wish to\n"
"type in the comment area below.\n"
msgstr ""
"Send venligst et postkort til mig s� jeg kan se hvem\n"
"der bruger KOrganizer! Fort�l mig hvor flot programmet\n"
"er, og hvorfor du ikke kan leve uden det. Du kan ogs�\n"
"rapportere fejl som forhindrer dig i at g�re nyttigt\n"
"arbejde. Postkortet kan simpelthen indeholde alt du\n"
"�nsker at skrive i kommentaromr�det nedenunder.\n"

#: aboutdlg.cpp:104
msgid "About KOrganizer"
msgstr "Om KOrganisator"

#: aboutdlg.cpp:137
msgid "by Preston Brown and"
msgstr "af Preston Brown og"

#: aboutdlg.cpp:156
msgid "License Agreement:"
msgstr "Licens aftale"

#: aboutdlg.cpp:162
msgid ""
"\n"
"\n"
"This program is free software; you can redistribute it and/or modify\n"
"it under the terms of the GNU General Public License as published by\n"
"the Free Software Foundation; either version 2 of the License, or\n"
"(at your option) any later version.\n"
"\n"
"This program is distributed in the hope that it will be useful,\n"
"but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
"GNU General Public License for more details.\n"
"\n"
"You should have received a copy of the GNU General Public License\n"
"along with this program; if not, write to the Free Software\n"
"Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.\n"
msgstr ""
"\n"
"\n"
"Dette program er fri programvare; du kan distribuere det videre og/eller "
"�ndre\n"
"det under betingelserne i GNU-licensen som er publiceret af \n"
"Free Software Foundation; enten version 2 af licensen, eller\n"
"(dit valg) hvilken som helst senere version.\n"
"\n"
"Dette program er udgivet i det h�b at det vil v�re nyttigt,\n"
"men UDEN NOGEN GARANTI, til og med uden en underforst�et garanti om\n"
"SALGBARHED eller EGNETHED TIL ET SPECIELT FORM�L.  Se \n"
"GNU-licensen for flere detaljer.\n"
"\n"
"Du b�r have modtaget en kopi af GNU-licensen\n"
"sammen med dette program; hvis ikke, skriv til Free Software\n"
"Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.\n"

#: aboutdlg.cpp:197
msgid "&Send Postcard"
msgstr "&Send postkort"

#: aboutdlg.cpp:233
msgid "many more, thank you!"
msgstr "mange flere, tak!"

#: aboutdlg.cpp:255
msgid "Could not load movie"
msgstr "Kunne ikke indl�se film"

#: kotodoview.cpp:27
msgid "To-Do Items"
msgstr "G�rem�l"

#: kotodoview.cpp:91 kotodoview.cpp:99
msgid "New To-Do"
msgstr "Nyt g�rem�l"

#: kotodoview.cpp:94
msgid "Purge Completed "
msgstr "Rydning Fuldf�rt"

#: kotodoview.cpp:101
msgid "Edit To-Do"
msgstr "Rediger g�rem�l"

#: kotodoview.cpp:104
msgid "Delete To-Do"
msgstr "Slet g�rem�l"

#: kotodoview.cpp:106
msgid "Purge Completed"
msgstr "Rydning Fuldf�rt"

#: kotodoview.cpp:108
msgid "Sort by Priority"
msgstr "Sorter efter prioritet"

#: eventwin.cpp:91
msgid "Save and Close"
msgstr "Gem og afslut"

#: eventwin.cpp:111
msgid "Previous Event"
msgstr "Forrige h�ndelse"

#: eventwin.cpp:117
msgid "Next Event"
msgstr "N�ste h�ndelse"

#: eventwin.cpp:128
msgid "Delete Event"
msgstr "Slet h�ndelse"

#: eventwin.cpp:286
msgid "New"
msgstr "Ny"

#: eventwin.cpp:293
msgid "Todo"
msgstr "G�rem�l"

#: eventwin.cpp:309
msgid "readonly"
msgstr "skrivebeskyttet"

#: todowingeneral.cpp:41
msgid "% Completed"
msgstr "% F�rdig"

#: todowingeneral.cpp:48
#, c-format
msgid "0 %"
msgstr "0 %"

#: todowingeneral.cpp:49
#, c-format
msgid "25 %"
msgstr "25 %"

#: todowingeneral.cpp:50
#, c-format
msgid "50 %"
msgstr "50 %"

#: todowingeneral.cpp:51
#, c-format
msgid "75 %"
msgstr "75 %"

#: todowingeneral.cpp:67
msgid "1 (Highest)"
msgstr "1 (H�jeste)"

#: todowingeneral.cpp:68
msgid "2"
msgstr "2"

#: todowingeneral.cpp:69
msgid "3"
msgstr "3"

#: todowingeneral.cpp:70
msgid "4"
msgstr "4"

#: todowingeneral.cpp:71
msgid "5 (lowest)"
msgstr "5 (Laveste)"

#: alarmdaemon.cpp:39 alarmdaemon.cpp:44
msgid "Can't load docking tray icon!"
msgstr "Kan ikke indl�se dykningsikonen"

#: alarmdaemon.cpp:48
msgid "Alarms Enabled"
msgstr "Alarm sl�et til"

#: alarmdaemon.cpp:51
msgid "Exit Applet"
msgstr "Afslut lille program"

#: alarmdaemon.cpp:54
msgid "KOrganizer Control Applet"
msgstr "KOrganizer kontrolprogram"

#: alarmdaemon.cpp:156
#, c-format
msgid "KOrganizer Alarm: %s\n"
msgstr "KOrganizer alarm: %s\n"

#: alarmdaemon.cpp:157
msgid ""
"The following events triggered alarms:\n"
"\n"
msgstr ""
"F�lgende begivenheder udl�ste alarmer:\n"
"\n"
