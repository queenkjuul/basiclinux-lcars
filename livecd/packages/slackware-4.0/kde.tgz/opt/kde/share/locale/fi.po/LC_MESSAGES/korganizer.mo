# SOME DESCRIPTIVE TITLE.
# Copyright (C) YEAR Free Software Foundation, Inc.
# Kim Enkovaara <kim.enkovaara@iki.fi>, 1998.
#
#, fuzzy
msgid ""
msgstr ""
"Project-Id-Version: KORGANIZER\n"
"POT-Creation-Date: 1999-04-20 03:16+0200\n"
"PO-Revision-Date: YEAR-MO-DA HO:MI+ZONE\n"
"Last-Translator: Kim Enkovaara <kim.enkovaara@iki.fi>\n"
"Language-Team: LANGUAGE <LL@li.org>\n"
"MIME-Version: 1.0\n"
"Content-Type: text/plain; charset=iso-8859-1\n"
"Content-Transfer-Encoding: ENCODING\n"

#: alarmdaemon.cpp:38 alarmdaemon.cpp:43 calobject.cpp:372 calobject.cpp:385
#: eventwindetails.cpp:341 eventwindetails.cpp:361 searchdialog.cpp:80
#: topwidget.cpp:959 topwidget.cpp:967 topwidget.cpp:1110 topwidget.cpp:1136
#: topwidget.cpp:1140
msgid "KOrganizer Error"
msgstr "KOrganizer virhe"

#: calobject.cpp:373 calobject.cpp:386
msgid ""
"An error has occurred parsing the contents of the clipboard.\n"
"You can only paste a valid vCalendar into KOrganizer.\n"
msgstr ""
"Leikep�yd�n sis�lt�� k�sitelt�ess� tapahtui virhe.\n"
"Voi liitt�� vain toimivan VCalenradin KOrganizeriin.\n"

#: calobject.cpp:434
#, fuzzy
msgid "found a VEvent with no DTSTART/DTEND! Skipping"
msgstr "l�ysin VEventin ilman DTSTART/DTEND:a! Ohitan...\n"

#: catdlg.cpp:19
msgid "KOrganizer Categories"
msgstr "KOrganizer kategoriat"

#: catdlg.cpp:30
msgid "Available Categories"
msgstr "Olemassaolevat kategoriat"

#: catdlg.cpp:36 eventwin.cpp:297 optionsdlg.cpp:227 optionsdlg.cpp:233
#: optionsdlg.cpp:239
msgid "Appointment"
msgstr "Tapaaminen"

#: catdlg.cpp:37
msgid "Business"
msgstr "Liiketoimi"

#: catdlg.cpp:38
msgid "Meeting"
msgstr "Tapaaminen"

#: catdlg.cpp:39
msgid "Phone Call"
msgstr "Puhelinsoitto"

#: catdlg.cpp:40
msgid "Education"
msgstr "Koulutus"

#: catdlg.cpp:41
msgid "Holiday"
msgstr "Lomap�iv�"

#: catdlg.cpp:42
msgid "Vacation"
msgstr "Loma"

#: catdlg.cpp:43
msgid "Special Occasion"
msgstr "Erikoistapahtuma"

#: catdlg.cpp:44 optionsdlg.cpp:34
msgid "Personal"
msgstr "Henkil�kohtainen"

#: catdlg.cpp:45
msgid "Travel"
msgstr "Matka"

#: catdlg.cpp:55
msgid "&Add >>"
msgstr "&Lis�� >>"

#: catdlg.cpp:57
msgid "<< &Remove"
msgstr "<< &Poista"

#: catdlg.cpp:66
msgid "Selected Categories"
msgstr "Valitut kategoriat"

#: catdlg.cpp:78
msgid "New Category:"
msgstr ""

#: editeventwin.cpp:116 todoeventwin.cpp:108
msgid "General"
msgstr "Yleist�"

#: editeventwin.cpp:117 todoeventwin.cpp:109
msgid "Details"
msgstr "Yksityiskohdat"

#: editeventwin.cpp:119
msgid "Recurrence"
msgstr "Uusiutuminen"

#: editeventwin.cpp:195 editeventwin.cpp:406 todoeventwin.cpp:162
#: todoeventwin.cpp:182
#, c-format
msgid "Owner: %s"
msgstr "Omistaja: %s"

#: editeventwin.cpp:810
msgid "Duration: all day"
msgstr "Kesto: koko p�iv�n"

#: editeventwin.cpp:818
#, c-format
msgid "Duration: %i hour(s), %i minute(s)"
msgstr "Kesto: %i tunti(a), %i minuutti(a)"

#: editeventwin.cpp:820
#, c-format
msgid "Duration: %i hour(s)"
msgstr "Kesto: %i tunti(a)"

#: editeventwin.cpp:822
#, c-format
msgid "Duration: %i minute(s)"
msgstr "Kesto: %i minuutti(a)"

#: eventwidget.cpp:193
msgid "Toggle Alarm"
msgstr "Vaihda h�lytys"

#: eventwingeneral.cpp:42 eventwinrecur.cpp:28 wingeneral.cpp:34
msgid "Appointment Time"
msgstr "Tapaamisen aika"

#: eventwingeneral.cpp:47 wingeneral.cpp:39
msgid "Start Time:"
msgstr "Alkuaika:"

#: eventwingeneral.cpp:58 wingeneral.cpp:48
msgid "End Time:"
msgstr "Loppuaika:"

#: eventwingeneral.cpp:80 wingeneral.cpp:64
msgid "No time associated"
msgstr "Aikaa ei annettu"

#: eventwingeneral.cpp:91 wingeneral.cpp:75
msgid "Recurring event"
msgstr "Uusiutuva tapahtuma"

#: eventwingeneral.cpp:99 todowingeneral.cpp:77
msgid "Summary:"
msgstr "Yhteenveto:"

#: eventwingeneral.cpp:110
msgid "Show Time As:"
msgstr "N�yt� aika:"

#: eventwingeneral.cpp:117
msgid "Busy"
msgstr "Varattu"

#: eventwingeneral.cpp:118
msgid "Free"
msgstr "Vapaa"

#: eventwingeneral.cpp:133 todowingeneral.cpp:96
msgid "Owner:"
msgstr "Omistaja:"

#: eventwingeneral.cpp:139 todowingeneral.cpp:102
msgid "Private"
msgstr "Yksityinen"

#: eventwindetails.cpp:199 eventwingeneral.cpp:145 todowingeneral.cpp:108
msgid "Categories..."
msgstr "Kategoriat..."

#: eventwingeneral.cpp:164
msgid "Reminder:"
msgstr "Muistutus:"

#: eventwindetails.cpp:39
msgid "Attendee Information"
msgstr "Osallistujatiedot"

#: eventwindetails.cpp:46
msgid "Name"
msgstr "Nimi"

#: eventwindetails.cpp:47
msgid "Email"
msgstr "S�hk�posti"

#: eventwindetails.cpp:48
msgid "Role"
msgstr "Rooli"

#: eventwindetails.cpp:49
msgid "Status"
msgstr "Tila"

#: eventwindetails.cpp:50
msgid "RSVP"
msgstr "RSVP"

#: eventwindetails.cpp:65
msgid "Attendee Name:"
msgstr "Osallistujan nimi:"

#: eventwindetails.cpp:77
msgid "Email Address:"
msgstr "S�hk�postiosoite:"

#: eventwindetails.cpp:92
msgid "Role:"
msgstr "Rooli:"

#: eventwindetails.cpp:98
msgid "Attendee"
msgstr "Osallistuja"

#: eventwindetails.cpp:99
msgid "Organizer"
msgstr "Organisoija"

#: eventwindetails.cpp:100
msgid "Owner"
msgstr "Omistaja"

#: eventwindetails.cpp:101
msgid "Delegate"
msgstr "Delegaatti"

#: eventwindetails.cpp:106
msgid "Status:"
msgstr "Tila:"

#: eventwindetails.cpp:112
msgid "Needs Action"
msgstr "Vaatii toimenpiteit�"

#: eventwindetails.cpp:113
msgid "Accepted"
msgstr "Hyv�ksytty"

#: eventwindetails.cpp:114
msgid "Sent"
msgstr "L�hetetty"

#: eventwindetails.cpp:115
msgid "Tentative"
msgstr "Alustava"

#: eventwindetails.cpp:116
msgid "Confirmed"
msgstr "Vahvistettu"

#: eventwindetails.cpp:117
msgid "Declined"
msgstr "Kielt�ydytty"

#: eventwindetails.cpp:118 todowingeneral.cpp:35 todowingeneral.cpp:52
msgid "Completed"
msgstr "Valmis"

#: eventwindetails.cpp:119
msgid "Delegated"
msgstr "Delegoitu"

#: eventwindetails.cpp:126
msgid "Request Response"
msgstr "Pyyd� vastaus"

#: eventwindetails.cpp:132
msgid "&Add"
msgstr "&Lis��"

#: eventwindetails.cpp:136
msgid "Address &Book..."
msgstr "&Osoitekirja..."

#: eventwindetails.cpp:163
msgid "Attach..."
msgstr "Liit�..."

#: eventwindetails.cpp:183
msgid "Save As..."
msgstr "Tallenna nimell�..."

#: eventwindetails.cpp:218
msgid "Priority:"
msgstr "Prioriteetti:"

#: eventwindetails.cpp:224
msgid "Low (1)"
msgstr "Matala (1)"

#: eventwindetails.cpp:225
msgid "Normal (2)"
msgstr "Normaali (2)"

#: eventwindetails.cpp:226
msgid "High (3)"
msgstr "Korkea (3)"

#: eventwindetails.cpp:227
msgid "Maximum (4)"
msgstr "Maksimaalinen (4)"

#: eventwindetails.cpp:342
msgid "Unable to open address book."
msgstr "En pysty avaamaan osoitekirjaa."

#: eventwindetails.cpp:362
msgid "Error getting entry from address book."
msgstr "Virhe haettaessa osoitekirjatietuetta."

#: eventwinrecur.cpp:30
msgid "Start:  "
msgstr "Aloita:  "

#: eventwinrecur.cpp:31
msgid "End:  "
msgstr "Lopeta:  "

#: eventwinrecur.cpp:61
msgid "Recurrence Rule"
msgstr "Uusiutuvuuss��nt�"

#: eventwinrecur.cpp:67
msgid "Daily"
msgstr "P�ivitt�in"

#: eventwinrecur.cpp:68
msgid "Weekly"
msgstr "Viikoittain"

#: eventwinrecur.cpp:69
msgid "Monthly"
msgstr "Kuukausittain"

#: eventwinrecur.cpp:70
msgid "Yearly"
msgstr "Vuosittain"

#: eventwinrecur.cpp:95
msgid "Enable Advanced Rule:"
msgstr "K�yt� edistynytt� s��nt��:"

#: eventwinrecur.cpp:128
msgid "Recurrence Range"
msgstr "Uusiutumisv�li"

#: eventwinrecur.cpp:132
msgid "Begin On:"
msgstr "Aloita:"

#: eventwinrecur.cpp:134
msgid "No Ending Date"
msgstr "Ei loppup�iv��"

#: eventwinrecur.cpp:135
msgid "End after"
msgstr "Lopeta j�lkeen"

#: eventwinrecur.cpp:137
msgid "occurrence(s)"
msgstr "esiintymi�"

#: eventwinrecur.cpp:138
msgid "End by:"
msgstr "Lopeta:"

#: eventwinrecur.cpp:181
msgid "Exceptions"
msgstr "Poikkeukset"

#: eventwinrecur.cpp:267 eventwinrecur.cpp:297
msgid "Recur every"
msgstr "Uusi joka"

#: eventwinrecur.cpp:273
msgid "day(s)"
msgstr "p�iv�"

#: eventwinrecur.cpp:303
msgid "week(s) on:"
msgstr "viikko:"

#: eventwinrecur.cpp:305 kagenda.cpp:106
msgid "Sun"
msgstr "Su"

#: eventwinrecur.cpp:306 kagenda.cpp:105
msgid "Mon"
msgstr "Ma"

#: eventwinrecur.cpp:307 kagenda.cpp:105
msgid "Tue"
msgstr "Ti"

#: eventwinrecur.cpp:308 kagenda.cpp:105
msgid "Wed"
msgstr "Ke"

#: eventwinrecur.cpp:309 kagenda.cpp:106
msgid "Thu"
msgstr "To"

#: eventwinrecur.cpp:310 kagenda.cpp:106
msgid "Fri"
msgstr "Pe"

#: eventwinrecur.cpp:311 kagenda.cpp:106
msgid "Sat"
msgstr "La"

#: eventwinrecur.cpp:361 eventwinrecur.cpp:365
msgid "Recur on the"
msgstr "Uusiutuu"

#: eventwinrecur.cpp:363
msgid "day"
msgstr "p�iv�"

#: eventwinrecur.cpp:369 eventwinrecur.cpp:481
msgid "every"
msgstr "joka"

#: eventwinrecur.cpp:371
msgid "month(s)"
msgstr "kuukausi"

#: eventwinrecur.cpp:383 eventwinrecur.cpp:424
msgid "1st"
msgstr "1."

#: eventwinrecur.cpp:384 eventwinrecur.cpp:425
msgid "2nd"
msgstr "2."

#: eventwinrecur.cpp:385 eventwinrecur.cpp:426
msgid "3rd"
msgstr "3."

#: eventwinrecur.cpp:386 eventwinrecur.cpp:427
msgid "4th"
msgstr "4."

#: eventwinrecur.cpp:387 eventwinrecur.cpp:428
msgid "5th"
msgstr "5."

#: eventwinrecur.cpp:388
msgid "6th"
msgstr "6."

#: eventwinrecur.cpp:389
msgid "7th"
msgstr "7."

#: eventwinrecur.cpp:390
msgid "8th"
msgstr "8."

#: eventwinrecur.cpp:391
msgid "9th"
msgstr "9."

#: eventwinrecur.cpp:392
msgid "10th"
msgstr "10."

#: eventwinrecur.cpp:393
msgid "11th"
msgstr "11."

#: eventwinrecur.cpp:394
msgid "12th"
msgstr "12."

#: eventwinrecur.cpp:395
msgid "13th"
msgstr "13."

#: eventwinrecur.cpp:396
msgid "14th"
msgstr "14."

#: eventwinrecur.cpp:397
msgid "15th"
msgstr "15."

#: eventwinrecur.cpp:398
msgid "16th"
msgstr "16."

#: eventwinrecur.cpp:399
msgid "17th"
msgstr "17."

#: eventwinrecur.cpp:400
msgid "18th"
msgstr "18."

#: eventwinrecur.cpp:401
msgid "19th"
msgstr "19."

#: eventwinrecur.cpp:402
msgid "20th"
msgstr "20."

#: eventwinrecur.cpp:403
msgid "21st"
msgstr "21."

#: eventwinrecur.cpp:404
msgid "22nd"
msgstr "22."

#: eventwinrecur.cpp:405
msgid "23rd"
msgstr "23."

#: eventwinrecur.cpp:406
msgid "24th"
msgstr "24."

#: eventwinrecur.cpp:407
msgid "25th"
msgstr "25."

#: eventwinrecur.cpp:408
msgid "26th"
msgstr "26."

#: eventwinrecur.cpp:409
msgid "27th"
msgstr "27."

#: eventwinrecur.cpp:410
msgid "28th"
msgstr "28."

#: eventwinrecur.cpp:411
msgid "29th"
msgstr "29."

#: eventwinrecur.cpp:412
msgid "30th"
msgstr "30."

#: eventwinrecur.cpp:413
msgid "31st"
msgstr "31."

#: eventwinrecur.cpp:466
msgid "Recur in the month of"
msgstr "Uusintakuukausi"

#: eventwinrecur.cpp:467
msgid "Recur on this day"
msgstr "Uusi t�n� p�iv�n�"

#: calprinter.cpp:327 calprinter.cpp:429 calprinter.cpp:720
#: eventwinrecur.cpp:469 kdatenav.cpp:68 kdatenav.cpp:258
msgid "January"
msgstr "Tammikuu"

#: calprinter.cpp:327 calprinter.cpp:429 calprinter.cpp:720
#: eventwinrecur.cpp:470 kdatenav.cpp:68 kdatenav.cpp:258
msgid "February"
msgstr "Helmikuu"

#: calprinter.cpp:328 calprinter.cpp:430 calprinter.cpp:721
#: eventwinrecur.cpp:471 kdatenav.cpp:68 kdatenav.cpp:259
msgid "March"
msgstr "Maaliskuu"

#: calprinter.cpp:328 calprinter.cpp:430 calprinter.cpp:721
#: eventwinrecur.cpp:472 kdatenav.cpp:69 kdatenav.cpp:259
msgid "April"
msgstr "Huhtikuu"

#: calprinter.cpp:329 calprinter.cpp:431 calprinter.cpp:722
#: eventwinrecur.cpp:473 kdatenav.cpp:69 kdatenav.cpp:260
msgid "May"
msgstr "Toukokuu"

#: calprinter.cpp:329 calprinter.cpp:431 calprinter.cpp:722
#: eventwinrecur.cpp:474 kdatenav.cpp:69 kdatenav.cpp:260
msgid "June"
msgstr "Kes�kuu"

#: calprinter.cpp:330 calprinter.cpp:432 calprinter.cpp:723
#: eventwinrecur.cpp:475 kdatenav.cpp:69 kdatenav.cpp:261
msgid "July"
msgstr "Hein�kuu"

#: calprinter.cpp:330 calprinter.cpp:432 calprinter.cpp:723
#: eventwinrecur.cpp:476 kdatenav.cpp:70 kdatenav.cpp:261
msgid "August"
msgstr "Elokuu"

#: calprinter.cpp:331 calprinter.cpp:433 calprinter.cpp:724
#: eventwinrecur.cpp:477 kdatenav.cpp:70 kdatenav.cpp:262
msgid "September"
msgstr "Syyskuu"

#: calprinter.cpp:331 calprinter.cpp:433 calprinter.cpp:724
#: eventwinrecur.cpp:478 kdatenav.cpp:70 kdatenav.cpp:262
msgid "October"
msgstr "Lokakuu"

#: calprinter.cpp:332 calprinter.cpp:434 calprinter.cpp:725
#: eventwinrecur.cpp:479 kdatenav.cpp:71 kdatenav.cpp:263
msgid "November"
msgstr "Marraskuu"

#: calprinter.cpp:332 calprinter.cpp:434 calprinter.cpp:725
#: eventwinrecur.cpp:480 kdatenav.cpp:71 kdatenav.cpp:263
msgid "December"
msgstr "Joulukuu"

#: eventwinrecur.cpp:484
msgid "year(s)"
msgstr "vuosi"

#: kagenda.cpp:212
msgid "All Day Event"
msgstr "Koko p�iv�"

#: kagenda.cpp:829
msgid "New appointment"
msgstr "Uusi tapaaminen"

#: kagenda.cpp:966 kagenda.cpp:974
msgid "am"
msgstr "am"

#: kagenda.cpp:970
msgid "pm"
msgstr "pm"

#: kdatenav.cpp:44
msgid "Previous Year"
msgstr "Edellinen Vuosi"

#: kdatenav.cpp:50
msgid "Previous Month"
msgstr "Edellinen Kuukausi"

#: kdatenav.cpp:56
msgid "Next Month"
msgstr "Seuraava Kuukausi"

#: kdatenav.cpp:62
msgid "Next Year"
msgstr "Seuraava Vuosi"

#: kmonthview.cpp:386
msgid "New Event"
msgstr "Uusi tapahtuma"

#: kpbutton.cpp:22 kpbutton.cpp:40 kpbutton.cpp:90
msgid "KPButton: pixmap is empty, perhaps some missing file"
msgstr "KPButton: kuva on tyhj�, mahdollisesti tiedostoja puuttuu"

#: baselistview.cpp:28
msgid "Date"
msgstr "P�iv�"

#: baselistview.cpp:29
msgid "Time"
msgstr "Aika"

#: baselistview.cpp:30 calprinter.cpp:365
msgid "Summary"
msgstr "Yhteenveto"

#: baselistview.cpp:77
msgid "started "
msgstr "aloitettu "

#: baselistview.cpp:80
msgid "ends "
msgstr "loppuu "

#: baselistview.cpp:85
#, c-format
msgid "repeats %d times"
msgstr "toista %d kertaa"

#: baselistview.cpp:89
msgid "repeats forever"
msgstr "toista loputtomiin"

#: listview.cpp:14
msgid "Edit Event"
msgstr "Muokkaa tapahtumaa"

#: listview.cpp:17
msgid "Delete Event  "
msgstr "Poista tapahtuma   "

#: listview.cpp:20
msgid "Show Dates"
msgstr "N�yt� p�iv�t"

#: listview.cpp:22
msgid "Hide Dates"
msgstr "Piilota p�iv�t"

#: main.cpp:29
msgid "No default calendar, and none was specified on the command line.\n"
msgstr "Ei oletuskalenteria, eik� mit��n m��ritelty komentorivill�.\n"

#: main.cpp:33
msgid "Error reading from default calendar.\n"
msgstr "virhe luettaessa oletuskalenteria.\n"

#: searchdialog.cpp:22
msgid "Search For:"
msgstr ""

#: searchdialog.cpp:32 topwidget.cpp:494
#, fuzzy
msgid "&Search"
msgstr "&Etsi..."

#: searchdialog.cpp:81
msgid ""
"Invalid search expression, cannot perform\n"
"the search.  Please enter a search expression\n"
"using the wildcard characters '*' and '?'\n"
"where needed."
msgstr ""

#: topwidget.cpp:391
msgid "&Open"
msgstr ""

#: topwidget.cpp:394
msgid "Open &Recent"
msgstr "&Avaa edellinen"

#: topwidget.cpp:410
#, fuzzy
msgid "Save &As"
msgstr "Tallenna &nimell�..."

#: topwidget.cpp:415
#, fuzzy
msgid "&Import From Ical"
msgstr "&Tuo Ical:ta..."

#: topwidget.cpp:417
#, fuzzy
msgid "&Merge Calendar"
msgstr "&Liit� kalenteri..."

#: topwidget.cpp:420
#, fuzzy
msgid "Archive Old Entries"
msgstr "Talleta vanhat tapahtumat..."

#: topwidget.cpp:427
#, fuzzy
msgid "Print Setup"
msgstr "Tulostimen asetukset..."

#: calprinter.cpp:844 topwidget.cpp:431
msgid "&Print"
msgstr "&Tulosta"

#: topwidget.cpp:433
#, fuzzy
msgid "Print Pre&view"
msgstr "Esikatselu..."

#: topwidget.cpp:455
msgid "&List"
msgstr "&Lista"

#: topwidget.cpp:459
msgid "&Day"
msgstr "&P�iv�"

#: topwidget.cpp:462
msgid "W&ork Week"
msgstr "&Ty�viikkon�kym�"

#: topwidget.cpp:465
msgid "&Week"
msgstr "&Viikko"

#: topwidget.cpp:468
msgid "&Month"
msgstr "&Kuukausi"

#: topwidget.cpp:471
#, fuzzy
msgid "&To-do list"
msgstr "&Teht�v��"

#: topwidget.cpp:479
msgid "New &Appointment"
msgstr "&Uusi tapaaminen"

#: topwidget.cpp:481
msgid "New E&vent"
msgstr "Uusi &tapahtuma"

#: topwidget.cpp:483
msgid "&Edit Appointment"
msgstr "&Muokkaa tapaamista"

#: topwidget.cpp:486
msgid "&Delete Appointment"
msgstr "&Poista tapaaminen"

#: topwidget.cpp:488
#, fuzzy
msgid "Delete To-do"
msgstr "Poista teht�v�"

#: topwidget.cpp:498
#, fuzzy
msgid "&Mail Appointment"
msgstr "Postita tapaaminen"

#: topwidget.cpp:504
#, fuzzy
msgid "Go to &Today"
msgstr "Siirry t�h�n p�iv��n"

#: topwidget.cpp:508
#, fuzzy
msgid "&Previous Day"
msgstr "Edellinen Vuosi"

#: topwidget.cpp:512
#, fuzzy
msgid "&Next Day"
msgstr "Seuraava Vuosi"

#: topwidget.cpp:516
msgid "Show &Tool Bar"
msgstr "N�yt� t&y�kalurivi"

#: topwidget.cpp:520
msgid "Show St&atus Bar"
msgstr "N�yt� &tilarivi"

#: topwidget.cpp:525
msgid "&Edit Options"
msgstr "&Muokkausasetukset"

#: topwidget.cpp:533
msgid "&About"
msgstr "&Tietoja"

#: topwidget.cpp:535
msgid "Send &Bug Report"
msgstr "L�het� &virheraportti"

#: topwidget.cpp:543
msgid "&Actions"
msgstr "&Toimenpiteet"

#: topwidget.cpp:562
msgid "Open A Calendar"
msgstr "Avaa kalenteri"

#: topwidget.cpp:568
msgid "Save This Calendar"
msgstr "Tallenna kalenteri"

#: topwidget.cpp:585
msgid "New Appointment"
msgstr "Uusi tapaaminen"

#: topwidget.cpp:591
msgid "Delete Appointment"
msgstr "Poista tapaaminen"

#: topwidget.cpp:597
msgid "Search For an Appointment"
msgstr "Etsi tapaamista"

#: topwidget.cpp:603
msgid "Mail Appointment"
msgstr "Postita tapaaminen"

#: topwidget.cpp:622
msgid "Go to Today"
msgstr "Siirry t�h�n p�iv��n"

#: topwidget.cpp:628
#, fuzzy
msgid "Previous Day"
msgstr "Edellinen Vuosi"

#: topwidget.cpp:634
#, fuzzy
msgid "Next Day"
msgstr "Seuraava Vuosi"

#: topwidget.cpp:650
msgid "List View"
msgstr "Listan�kym�"

#: topwidget.cpp:655
msgid "Schedule View"
msgstr "Aikataulun�kym�"

#: topwidget.cpp:662
msgid "Month View"
msgstr "Kuukausin�kym�"

#: topwidget.cpp:668
#, fuzzy
msgid "To-do list view"
msgstr "Teht�v�n�kym�"

#: topwidget.cpp:750
msgid "we don't handle updates for that view, yet.\n"
msgstr "emme tue viel� p�ivityksi� t�ss� n�kym�ss�.\n"

#: topwidget.cpp:842
msgid "we don't handle that view yet.\n"
msgstr "emme tue viel� n�kym��.\n"

#: topwidget.cpp:960
msgid "You did not specify a valid file name."
msgstr ""

#: topwidget.cpp:968
msgid ""
"The file you specified is a directory,\n"
"and cannot be opened. Please try again,\n"
"this time selecting a valid calendar file."
msgstr ""

#: topwidget.cpp:995
msgid "KOrganizer Warning"
msgstr "KOrganzer varoitus"

#: topwidget.cpp:996
#, fuzzy
msgid ""
"This calendar has been modified.\n"
"Would you like to save it?"
msgstr ""
"Kalenteri jota olet sulkemassa on muuttunut.\n"
"Halutako tallentaa muutoksesi?"

#: topwidget.cpp:998
msgid "&Yes"
msgstr ""

#: topwidget.cpp:998
msgid "&No"
msgstr ""

#: topwidget.cpp:1007 topwidget.cpp:1597
msgid "KOrganizer Confirmation"
msgstr "KOrganizer varmistus"

#: topwidget.cpp:1008
msgid "This item will be permanently deleted."
msgstr ""

#: topwidget.cpp:1111
msgid ""
"You have no ical file in your home directory.\n"
"Import cannot proceed.\n"
msgstr ""
"sinulle ole ical tiedostoa kotihakemistossasi.\n"
"Tuontia ei voida jatkaa.\n"

#: topwidget.cpp:1124
msgid "KOrganizer Info"
msgstr "KOrganizer tietoja"

#: topwidget.cpp:1125
msgid ""
"KOrganizer succesfully imported and merged your\n"
".calendar file from ical into the currently\n"
"opened calendar.\n"
msgstr ""
"KOrganizer onnistuneesti toi ja liitti kalenteri-\n"
"tiedostoosi ical kalenterin\n"

#: topwidget.cpp:1130
msgid "ICal Import Successful With Warning"
msgstr "ICal tuonti onnistui varoituksella"

#: topwidget.cpp:1131
msgid ""
"KOrganizer encountered some unknown fields while\n"
"parsing your .calendar ical file, and had to\n"
"discard them.  Please check to see that all\n"
"your relevant data was correctly imported.\n"
msgstr ""
"Korganizer tapasi tuntemattomia kentti� tulkitessaan\n"
"sinun .calendar ical tiedostoa ja hylk�si ne.\n"
"Tarkista ett� kaikki t�rke� tieto tuotiin kalenteriin.\n"

#: topwidget.cpp:1137
msgid ""
"KOrganizer encountered some error parsing your\n"
".calendar file from ical.  Import has failed.\n"
msgstr ""
"KOrganizer t�rm�si virheeseen tulkitessaan .calendar\n"
"ical tiedostoasi. Tuonti ep�onnistui.\n"

#: topwidget.cpp:1141
msgid ""
"KOrganizer doesn't think that your .calendar\n"
"file is a valid ical calendar. Import has failed.\n"
msgstr ""
"KOrganizerin mielest� .calendar ical tiedostosi ei\n"
"ole ical tiedosto. Tuonti ep�onnistui.\n"

#: topwidget.cpp:1305 topwidget.cpp:1332 topwidget.cpp:1683 topwidget.cpp:1693
msgid "KOrganizer error"
msgstr "KOrganizer virhe"

#: topwidget.cpp:1306 topwidget.cpp:1333
msgid ""
"Unfortunately, we don't handle cut/paste for\n"
"that view yet.\n"
msgstr ""
"Valitettavasti emme viel� tue leikkaa/liimaa\n"
"toimintoa t�ss�kohdin.\n"

#: topwidget.cpp:1549
msgid "don't handle deletes from that view, yet.\n"
msgstr "tuhoamisia ei tueta t�ss� n�kym�ss� viel�.\n"

#: topwidget.cpp:1598
#, fuzzy
msgid ""
"This event recurs over multiple dates.\n"
"Are you sure you want to delete the\n"
"selected event, or just this instance?\n"
msgstr ""
"T�m� tapahtuma on jaettu monelle p�iv�lle.\n"
"Oletko varma ett� haluat tuhota tapahtuman\n"
"vai vain t�m�n instanssin?\n"

#: topwidget.cpp:1601
msgid "&All"
msgstr "&Kaikki"

#: topwidget.cpp:1601
msgid "&This"
msgstr "&T�m�"

#: topwidget.cpp:1616
msgid "no date selected, or invalid date\n"
msgstr "p�iv�m��r�� ei ole valittu tai viallinen p�iv�\n"

#: topwidget.cpp:1684
msgid "Can't generate mail from this view\n"
msgstr "En voi luoda s�hk�postia t�st� n�kym�st�\n"

#: topwidget.cpp:1694
msgid ""
"Can't generate mail:\n"
" No attendees defined!\n"
msgstr ""
"En voi luoda postia:\n"
" Ei osallistujia m��ritelty!\n"

#: topwidget.cpp:1833
#, fuzzy
msgid "New Calendar"
msgstr "Avaa kalenteri"

#: eventwin.cpp:313 eventwin.cpp:319 topwidget.cpp:1839
msgid "modified"
msgstr ""

#: eventwin.cpp:325 topwidget.cpp:1844
#, fuzzy
msgid "KOrganizer"
msgstr "Organisoija"

#: calprinter.cpp:47
msgid "Korganizer Configuration Options"
msgstr "KOrganizer Asetukset"

#: calprinter.cpp:361 todowingeneral.cpp:60
msgid "Priority"
msgstr "Prioriteetti"

#: calprinter.cpp:369
msgid "Due"
msgstr "Koska"

#: calprinter.cpp:453
#, c-format
msgid "To-Do items: %s %.2d"
msgstr "Teht�mi�: %s %.2d"

#: calprinter.cpp:791
msgid "Date Range"
msgstr "Tietoalue"

#: calprinter.cpp:811
msgid "View Type"
msgstr "N�ytt�tyyppi"

#: calprinter.cpp:816
msgid "Day"
msgstr "P�iv�"

#: calprinter.cpp:821
msgid "Week"
msgstr "Viikko"

#: calprinter.cpp:825
msgid "Month"
msgstr "Kuukausi"

#: calprinter.cpp:829
msgid "To-Do"
msgstr "Teht�v��"

#: calprinter.cpp:843
msgid "&Preview"
msgstr "&Esikatselu"

#: koarchivedlg.cpp:19
msgid "Archive / Delete Past Appointments - KOrganizer"
msgstr "Talleta / Poista menneit� tapaamista - KOrganizer"

#: optionsdlg.cpp:37
msgid "Time & Date"
msgstr "Aika & P�iv�"

#: optionsdlg.cpp:43
msgid "Colors"
msgstr "V�rit"

#: optionsdlg.cpp:46
msgid "Views"
msgstr "N�kym�t"

#: optionsdlg.cpp:52
msgid "Printing"
msgstr "Tulostus"

#: optionsdlg.cpp:65
#, fuzzy
msgid "KOrganizer Configuration"
msgstr "KOrganizer varmistus"

#: optionsdlg.cpp:92
msgid "Your name:"
msgstr "Nimesi:"

#: optionsdlg.cpp:96
msgid "Email address:"
msgstr "S�hk�postiosoite:"

#: optionsdlg.cpp:100
msgid "Additional:"
msgstr "Lis��:"

#: optionsdlg.cpp:104
msgid "Auto-save Calendar"
msgstr "Autotallenna kalenteri"

#: optionsdlg.cpp:108
msgid "Confirm Appointment/To-Do Deletes"
msgstr "varmista Tapaaminen/Teht�v�� tuhoamiset"

#: optionsdlg.cpp:112
msgid "Holidays:"
msgstr "Lomat:"

#: optionsdlg.cpp:138
msgid "1 minute"
msgstr ""

#: optionsdlg.cpp:138
msgid "5 minutes"
msgstr ""

#: optionsdlg.cpp:139
msgid "10 minutes"
msgstr ""

#: optionsdlg.cpp:139
msgid "15 minutes"
msgstr ""

#: optionsdlg.cpp:140
msgid "30 minutes"
msgstr ""

#: optionsdlg.cpp:147
msgid "Time Format:"
msgstr "Aikaformaatti:"

#: optionsdlg.cpp:148
msgid "24 hour"
msgstr ""

#: optionsdlg.cpp:149
msgid "AM / PM"
msgstr ""

#: optionsdlg.cpp:153
msgid "Date Format:"
msgstr "P�iv�formaatti:"

#: optionsdlg.cpp:154
msgid "Day.Month.Year (31.01.2000)"
msgstr "P�iv�.Kuukausi.Vuosi (31.01.2000)"

#: optionsdlg.cpp:155
msgid "Month/Day/Year (01/31/2000)"
msgstr "Kuukausi/P�iv�/Vuosi (01/31/2000)"

#: optionsdlg.cpp:156
msgid "Month-Day-Year (01-31-2000)"
msgstr "Kuukausi-P�iv�-Vuosi (01-31-2000)"

#: optionsdlg.cpp:160
msgid "Time Zone:"
msgstr "Aikavy�hyke:"

#: optionsdlg.cpp:167
msgid "Default Appointment Time:"
msgstr "Tapaamisen oletusaika:"

#: optionsdlg.cpp:177
msgid "Default Alarm Time:"
msgstr "H�lytyksen oletusaika:"

#: optionsdlg.cpp:185
msgid "Week Starts on Monday"
msgstr "Viikko alkaa maanantaina"

#: optionsdlg.cpp:202
msgid "Day Begins At:"
msgstr "P�iv� alkaa:"

#: optionsdlg.cpp:212
msgid "Hour size in schedule view"
msgstr ""

#: optionsdlg.cpp:216
msgid "Show events that recur daily in Date Navigator"
msgstr "N�yt� p�ivitt�iset tapahtumat P�iv�m��r�selaimessa"

#: optionsdlg.cpp:228
#, fuzzy
msgid "List view font"
msgstr "Listan�kym�"

#: optionsdlg.cpp:234
#, fuzzy
msgid "Schedule view font"
msgstr "Aikataulun�kym�"

#: optionsdlg.cpp:240
#, fuzzy
msgid "Month view font"
msgstr "Kuukausin�kym�"

#: optionsdlg.cpp:245
msgid "12345"
msgstr ""

#: optionsdlg.cpp:245
#, fuzzy
msgid "Time bar font"
msgstr "Aikavy�hyke:"

#: optionsdlg.cpp:250
msgid "Things to do"
msgstr "Teht�v��"

#: optionsdlg.cpp:251
#, fuzzy
msgid "To-Do list font"
msgstr "&Teht�v��"

#: optionsdlg.cpp:272
msgid "Use system default colors"
msgstr "K�yt� j�rjestelm�n oletusv�rej�"

#: optionsdlg.cpp:277
#, fuzzy
msgid "Appointment & Checklist items"
msgstr "Tapaamisen aika"

#: optionsdlg.cpp:278
msgid "Background"
msgstr "Tausta"

#: optionsdlg.cpp:281
msgid "Text"
msgstr "Teksti"

#: optionsdlg.cpp:284
msgid "Handle Selected"
msgstr "Hoida valitut"

#: optionsdlg.cpp:287
msgid "Handle Unselected"
msgstr "Hoida valitsemattomat"

#: optionsdlg.cpp:290
msgid "Handle Active Apt."
msgstr "Hoida aktiiviset tap."

#: optionsdlg.cpp:295
msgid "Sheet background"
msgstr "Lomakkeen tausta"

#: optionsdlg.cpp:298
msgid "Calendar Background"
msgstr "Kalenterin tausta"

#: optionsdlg.cpp:301
msgid "Calendar Date Text"
msgstr "Kalenterin p�iv�teksti"

#: optionsdlg.cpp:304
msgid "Calendar Date Selected"
msgstr "Kalenterin p�iv� valittu"

#: optionsdlg.cpp:343
msgid "Printer Name"
msgstr "Tulostimen nimi"

#: optionsdlg.cpp:373
msgid "Paper Size"
msgstr "Paperikoko"

#: optionsdlg.cpp:375
msgid "A4"
msgstr "A4"

#: optionsdlg.cpp:376
msgid "B5"
msgstr "B5"

#: optionsdlg.cpp:377
msgid "Letter"
msgstr "Letter"

#: optionsdlg.cpp:378
msgid "Legal"
msgstr "Leagal"

#: optionsdlg.cpp:379
msgid "Executive"
msgstr "Executive"

#: optionsdlg.cpp:383
msgid "Paper Orientation"
msgstr "Paperin suunta"

#: optionsdlg.cpp:385
msgid "Portrait"
msgstr "Pysty"

#: optionsdlg.cpp:387
msgid "Landscape"
msgstr "Vaaka"

#: optionsdlg.cpp:394
msgid "Preview Program"
msgstr "Esikatseluhjelma"

#: kpropdlg.cpp:124
msgid "Prev"
msgstr "Edellinen"

#: kpropdlg.cpp:125
msgid "Next"
msgstr "Seuraava"

#: aboutdlg.cpp:20
#, fuzzy
msgid "KOrganizer Virtual Postcard"
msgstr "KOrganizer virhe"

#: aboutdlg.cpp:24
msgid ""
"Please send a postcard to me, so I can see who is\n"
"using KOrganizer! Tell me how great the program is,\n"
"and how you just can't live without it.  Or, report\n"
"a bug which is stopping you from doing useful work.\n"
"The postcard will simply include anything you wish to\n"
"type in the comment area below.\n"
msgstr ""
"L�het� minulle postikortti, nini tied�n ketk� k�ytt�v�t\n"
"KOrganizeria! Kerro minulle kuinka hyv� ohjelma se on,\n"
"ja kuinka et voi el�� ilman sit�.  Tai ilmoita virheest�\n"
"joka est�� sinua tekem�st� ty�t�. Postikortti sis�lt��\n"
"sen mit� kirjoitat allaolevaan kommenttialueeseen.\n"

#: aboutdlg.cpp:104
#, fuzzy
msgid "About KOrganizer"
msgstr "Organisoija"

#: aboutdlg.cpp:137
msgid "by Preston Brown and"
msgstr ""

#: aboutdlg.cpp:156
msgid "License Agreement:"
msgstr ""

#: aboutdlg.cpp:162
msgid ""
"\n"
"\n"
"This program is free software; you can redistribute it and/or modify\n"
"it under the terms of the GNU General Public License as published by\n"
"the Free Software Foundation; either version 2 of the License, or\n"
"(at your option) any later version.\n"
"\n"
"This program is distributed in the hope that it will be useful,\n"
"but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
"GNU General Public License for more details.\n"
"\n"
"You should have received a copy of the GNU General Public License\n"
"along with this program; if not, write to the Free Software\n"
"Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.\n"
msgstr ""

#: aboutdlg.cpp:197
#, fuzzy
msgid "&Send Postcard"
msgstr "L�het� postikortti"

#: aboutdlg.cpp:233
msgid "many more, thank you!"
msgstr "monta muuta, kiitos!"

#: aboutdlg.cpp:255
msgid "Could not load movie"
msgstr ""

#: kotodoview.cpp:27
msgid "To-Do Items"
msgstr "Teht�v��"

#: kotodoview.cpp:91 kotodoview.cpp:99
msgid "New To-Do"
msgstr "Uusi teht�v�"

#: kotodoview.cpp:94
msgid "Purge Completed "
msgstr "Tyhjennys valmis"

#: kotodoview.cpp:101
msgid "Edit To-Do"
msgstr "Muokkaa teht�v��"

#: kotodoview.cpp:104
msgid "Delete To-Do"
msgstr "Poista teht�v�"

#: kotodoview.cpp:106
#, fuzzy
msgid "Purge Completed"
msgstr "Tyhjennys valmis"

#: kotodoview.cpp:108
#, fuzzy
msgid "Sort by Priority"
msgstr "Prioriteetti"

#: eventwin.cpp:91
msgid "Save and Close"
msgstr "Tallenna ja sulje"

#: eventwin.cpp:111
msgid "Previous Event"
msgstr "Edellinen tapahtuma"

#: eventwin.cpp:117
msgid "Next Event"
msgstr "Seuraava tapahtuma"

#: eventwin.cpp:128
msgid "Delete Event"
msgstr "Tuhoa tapahtuma"

#: eventwin.cpp:286
msgid "New"
msgstr ""

#: eventwin.cpp:293
#, fuzzy
msgid "Todo"
msgstr "Teht�v��"

#: eventwin.cpp:309
msgid "readonly"
msgstr ""

#: todowingeneral.cpp:41
msgid "% Completed"
msgstr "% Valmista"

#: todowingeneral.cpp:48
#, c-format
msgid "0 %"
msgstr "0 %"

#: todowingeneral.cpp:49
#, c-format
msgid "25 %"
msgstr "25 %"

#: todowingeneral.cpp:50
#, c-format
msgid "50 %"
msgstr "50 %"

#: todowingeneral.cpp:51
#, c-format
msgid "75 %"
msgstr "75 %"

#: todowingeneral.cpp:67
msgid "1 (Highest)"
msgstr "1 (Korkein)"

#: todowingeneral.cpp:68
msgid "2"
msgstr "2"

#: todowingeneral.cpp:69
msgid "3"
msgstr "3"

#: todowingeneral.cpp:70
msgid "4"
msgstr "4"

#: todowingeneral.cpp:71
msgid "5 (lowest)"
msgstr "5 (matalin)"

#: alarmdaemon.cpp:39 alarmdaemon.cpp:44
msgid "Can't load docking tray icon!"
msgstr ""

#: alarmdaemon.cpp:48
msgid "Alarms Enabled"
msgstr ""

#: alarmdaemon.cpp:51
#, fuzzy
msgid "Exit Applet"
msgstr "&Muokkaa tapaamista"

#: alarmdaemon.cpp:54
#, fuzzy
msgid "KOrganizer Control Applet"
msgstr "KOrganizer varmistus"

#: alarmdaemon.cpp:156
#, fuzzy, c-format
msgid "KOrganizer Alarm: %s\n"
msgstr "KOrganizer kategoriat"

#: alarmdaemon.cpp:157
msgid ""
"The following events triggered alarms:\n"
"\n"
msgstr ""

#~ msgid "New Appointment - KOrganizer"
#~ msgstr "Uusi tapaaminen - KOrganizer"

#~ msgid "Edit Todo - KOrganizer (Readonly)"
#~ msgstr "Muokkaa teht�v�listaa - KOrganizer (Vain luku)"

#~ msgid "Edit Appointment - KOrganizer (Readonly)"
#~ msgstr "Muokkaa tapaamista - Korganiser (Vain luku)"

#~ msgid "Edit Todo - KOrganizer"
#~ msgstr "Muokkaa teht�v�listaa - Korganizer"

#~ msgid "Edit Appointment - KOrganizer"
#~ msgstr "Muokkaa tapaamista - KOrganizer"

#~ msgid "&Mail Appointment..."
#~ msgstr "&Postita tapaaminen..."

#~ msgid "Previous"
#~ msgstr "Edellinen"

#~ msgid "Modified Calendar Warning"
#~ msgstr "Muokattu kalenterivaroitus"

#~ msgid ""
#~ "You are opening a new calendar, but the currentone has been modified.\n"
#~ "Are you sure you want todo this? All changes will be lost!\n"
#~ "\n"
#~ msgstr ""
#~ "Olet avaamassa uutta kalenteria, mutta nykyist� on jo muokattu.\n"
#~ "Oletko varma ett� haluat tehd� t�m�n? Kaikki muutokset h�vi�v�t!\n"
#~ "\n"

#~ msgid "KOrganizer had a problem opening your file:\n"
#~ msgstr "KOrganizer:lla oli ongelma avattaessa tiedostoa:\n"

#~ msgid ""
#~ "Please check that the directory and/or file exists,\n"
#~ "that you have permissions to read it, and try again."
#~ msgstr ""
#~ "Tarkista ett� hakemisto ja/tai tiedosto on olemassa,\n"
#~ "ja ett� sinulla on oikeudet luka sit� ja yrit� uudelleen."

#~ msgid "KOrganizer Modified Calendar Warning"
#~ msgstr "Muutettu Kalenterivaroitus"

#~ msgid ""
#~ "You are opening a new calendar, but the current one has been modified.\n"
#~ "Are you sure you want to do this? All changes will be lost!\n"
#~ "\n"
#~ msgstr ""
#~ "Olet avaamassa uutta kalenteria, mutta nykyist� on jo muutettu.\n"
#~ "Oletko varma, ett� haluat tehd� t�m�n? Kaikki muutokset h�vi�v�t!\n"
#~ "\n"

#~ msgid "KOrganizer had a problem saving your file:\n"
#~ msgstr "KOrganizer:lla oli ongelmia tallettaa tiedostoa:\n"

#~ msgid ""
#~ "Please check that the directory exists and you have\n"
#~ "permission to write to it, and try again."
#~ msgstr ""
#~ "Tarkista ett� hakemisto on olemassa ja ett� sinulla\n"
#~ "on oikeudet kirjoittaa sinne, ja yrit� uudelleen."

#~ msgid "&Don't Save"
#~ msgstr "�&l� tallenna"

#~ msgid ""
#~ "Are you sure you want to delete\n"
#~ "the selected to do item?\n"
#~ "\n"
#~ msgstr ""
#~ "Oletko varma ett� haluat tuhota\n"
#~ "valitun tapahtuman?\n"
#~ "\n"

#~ msgid ""
#~ "Are you sure you want to delete\n"
#~ "the selected event?\n"
#~ "\n"
#~ msgstr ""
#~ "Oletko varma ett� haluat tuhota valitun\n"
#~ "tapahtuman?\n"
#~ "\n"

#~ msgid "%s%s- KOrganizer"
#~ msgstr "%s%s - KOrganizer"

#~ msgid "New Calendar%s- KOrganizer"
#~ msgstr "Uusi kalenteri%s - KOrganizer"

#~ msgid "%s - KOrganizer"
#~ msgstr "%s - KOrganizer"

#~ msgid "New Calendar - KOrganizer"
#~ msgstr "Uusi kalenteri - KOrganizer"

#~ msgid "Test"
#~ msgstr "Kokeile"
