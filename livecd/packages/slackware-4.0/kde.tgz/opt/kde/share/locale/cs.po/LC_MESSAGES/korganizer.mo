msgid ""
msgstr ""
"Project-Id-Version: korganizer\n"
"POT-Creation-Date: 1999-04-20 03:16+0200\n"
"PO-Revision-Date: 1999-02-04 11:57+01:00\n"
"Last-Translator: Miroslav Fl�dr <flidr@kky.zcu.cz>\n"
"Language-Team: czech <flidr@kky.zcu.cz>\n"
"MIME-Version: 1.0\n"
"Content-Type: text/plain; charset=iso-8859-2\n"
"Content-Transfer-Encoding: 8bit\n"

#: alarmdaemon.cpp:38 alarmdaemon.cpp:43 calobject.cpp:372 calobject.cpp:385
#: eventwindetails.cpp:341 eventwindetails.cpp:361 searchdialog.cpp:80
#: topwidget.cpp:959 topwidget.cpp:967 topwidget.cpp:1110 topwidget.cpp:1136
#: topwidget.cpp:1140
msgid "KOrganizer Error"
msgstr "Chyba KOrganiz�ru"

#: calobject.cpp:373 calobject.cpp:386
msgid ""
"An error has occurred parsing the contents of the clipboard.\n"
"You can only paste a valid vCalendar into KOrganizer.\n"
msgstr ""
"Nastala chyba p�i zpracov�v�n� obsahu clipboardu.\n"
"Do FOrganizeru je mo�no vlo�it pouze platny vCalendar.\n"

#: calobject.cpp:434
#, fuzzy
msgid "found a VEvent with no DTSTART/DTEND! Skipping"
msgstr "nalezen VEvent bez DTSTART/DTEND! P�eskakuji...\n"

#: catdlg.cpp:19
msgid "KOrganizer Categories"
msgstr "Kategorie KOrganizeru"

#: catdlg.cpp:30
msgid "Available Categories"
msgstr "Dostupn� kategorie"

#: catdlg.cpp:36 eventwin.cpp:297 optionsdlg.cpp:227 optionsdlg.cpp:233
#: optionsdlg.cpp:239
msgid "Appointment"
msgstr "Sch�zka"

#: catdlg.cpp:37
msgid "Business"
msgstr "Obchod"

#: catdlg.cpp:38
msgid "Meeting"
msgstr "Sch�ze"

#: catdlg.cpp:39
msgid "Phone Call"
msgstr "Telefonn� hovor"

#: catdlg.cpp:40
msgid "Education"
msgstr "�kolen�"

#: catdlg.cpp:41
msgid "Holiday"
msgstr "Sv�tek"

#: catdlg.cpp:42
msgid "Vacation"
msgstr "Dovolen�"

#: catdlg.cpp:43
msgid "Special Occasion"
msgstr "Speci�ln� p��le�itost"

#: catdlg.cpp:44 optionsdlg.cpp:34
msgid "Personal"
msgstr "Osobn�"

#: catdlg.cpp:45
msgid "Travel"
msgstr "Cesta"

#: catdlg.cpp:55
msgid "&Add >>"
msgstr "&P�idat >>"

#: catdlg.cpp:57
msgid "<< &Remove"
msgstr "<< Odst&ranit"

#: catdlg.cpp:66
msgid "Selected Categories"
msgstr "Vybran� kategorie"

#: catdlg.cpp:78
msgid "New Category:"
msgstr ""

#: editeventwin.cpp:116 todoeventwin.cpp:108
msgid "General"
msgstr "V�eobecn�"

#: editeventwin.cpp:117 todoeventwin.cpp:109
msgid "Details"
msgstr "Detaily"

#: editeventwin.cpp:119
msgid "Recurrence"
msgstr "Opakov�n�"

#: editeventwin.cpp:195 editeventwin.cpp:406 todoeventwin.cpp:162
#: todoeventwin.cpp:182
#, c-format
msgid "Owner: %s"
msgstr "Vlastn�k: %s"

#: editeventwin.cpp:810
msgid "Duration: all day"
msgstr "Doba trv�n�: cel� den"

#: editeventwin.cpp:818
#, c-format
msgid "Duration: %i hour(s), %i minute(s)"
msgstr "Doba trv�n�: %i hodin(a/y), %i minut(a/y)"

#: editeventwin.cpp:820
#, c-format
msgid "Duration: %i hour(s)"
msgstr "Doba trv�n�: %i hodin(a/y)"

#: editeventwin.cpp:822
#, c-format
msgid "Duration: %i minute(s)"
msgstr "Doba trv�n�: %i minut(a/y)"

#: eventwidget.cpp:193
msgid "Toggle Alarm"
msgstr "Vypnout/zapnout signalizaci"

#: eventwingeneral.cpp:42 eventwinrecur.cpp:28 wingeneral.cpp:34
msgid "Appointment Time"
msgstr "�as ur�en�"

#: eventwingeneral.cpp:47 wingeneral.cpp:39
msgid "Start Time:"
msgstr "Za��tek:"

#: eventwingeneral.cpp:58 wingeneral.cpp:48
msgid "End Time:"
msgstr "Konec:"

#: eventwingeneral.cpp:80 wingeneral.cpp:64
msgid "No time associated"
msgstr "Bez p�i�azen� �asu"

#: eventwingeneral.cpp:91 wingeneral.cpp:75
msgid "Recurring event"
msgstr "Opakuj�c� se ud�lost"

#: eventwingeneral.cpp:99 todowingeneral.cpp:77
msgid "Summary:"
msgstr "Shrnut�:"

#: eventwingeneral.cpp:110
msgid "Show Time As:"
msgstr "Zobrazovat jako:"

#: eventwingeneral.cpp:117
msgid "Busy"
msgstr "Zanepr�zdn�n�"

#: eventwingeneral.cpp:118
msgid "Free"
msgstr "Voln�"

#: eventwingeneral.cpp:133 todowingeneral.cpp:96
msgid "Owner:"
msgstr "Vlastn�k:"

#: eventwingeneral.cpp:139 todowingeneral.cpp:102
msgid "Private"
msgstr "Soukrom�"

#: eventwindetails.cpp:199 eventwingeneral.cpp:145 todowingeneral.cpp:108
msgid "Categories..."
msgstr "Kategorie..."

#: eventwingeneral.cpp:164
msgid "Reminder:"
msgstr "P�ipomenout:"

#: eventwindetails.cpp:39
msgid "Attendee Information"
msgstr "Informace o ��astn�c�ch"

#: eventwindetails.cpp:46
msgid "Name"
msgstr "Jm�no"

#: eventwindetails.cpp:47
msgid "Email"
msgstr "E-mail"

#: eventwindetails.cpp:48
msgid "Role"
msgstr "Funkce"

#: eventwindetails.cpp:49
msgid "Status"
msgstr "Stav"

#: eventwindetails.cpp:50
msgid "RSVP"
msgstr ""

#: eventwindetails.cpp:65
msgid "Attendee Name:"
msgstr "Jm�no ��astn�ka:"

#: eventwindetails.cpp:77
msgid "Email Address:"
msgstr "E-mail adresa:"

#: eventwindetails.cpp:92
msgid "Role:"
msgstr "Funkce:"

#: eventwindetails.cpp:98
msgid "Attendee"
msgstr "��astn�k"

#: eventwindetails.cpp:99
msgid "Organizer"
msgstr "Organiz�tor"

#: eventwindetails.cpp:100
msgid "Owner"
msgstr "Vlastn�k"

#: eventwindetails.cpp:101
msgid "Delegate"
msgstr "Deleg�t"

#: eventwindetails.cpp:106
msgid "Status:"
msgstr "Stav:"

#: eventwindetails.cpp:112
msgid "Needs Action"
msgstr "Vy�aduje akci"

#: eventwindetails.cpp:113
msgid "Accepted"
msgstr "P�ijato"

#: eventwindetails.cpp:114
msgid "Sent"
msgstr "Poslat"

#: eventwindetails.cpp:115
msgid "Tentative"
msgstr "Zku�ebn�"

#: eventwindetails.cpp:116
msgid "Confirmed"
msgstr "Potvrzen�"

#: eventwindetails.cpp:117
msgid "Declined"
msgstr "Odm�tnuto"

#: eventwindetails.cpp:118 todowingeneral.cpp:35 todowingeneral.cpp:52
msgid "Completed"
msgstr "Ukon�en"

#: eventwindetails.cpp:119
msgid "Delegated"
msgstr "Delegov�no"

#: eventwindetails.cpp:126
msgid "Request Response"
msgstr "Vy�adovat odpov��"

#: eventwindetails.cpp:132
msgid "&Add"
msgstr "&P�idat"

#: eventwindetails.cpp:136
msgid "Address &Book..."
msgstr "Kniha &adres..."

#: eventwindetails.cpp:163
msgid "Attach..."
msgstr "P�ilo�it..."

#: eventwindetails.cpp:183
msgid "Save As..."
msgstr "Ulo�it jako..."

#: eventwindetails.cpp:218
msgid "Priority:"
msgstr "Priorita:"

#: eventwindetails.cpp:224
msgid "Low (1)"
msgstr "Mal� (1)"

#: eventwindetails.cpp:225
msgid "Normal (2)"
msgstr "Norm�ln� (2)"

#: eventwindetails.cpp:226
msgid "High (3)"
msgstr "Velk� (3)"

#: eventwindetails.cpp:227
msgid "Maximum (4)"
msgstr "Maxim�ln� (4)"

#: eventwindetails.cpp:342
msgid "Unable to open address book."
msgstr "Nen� mo�n� otev��t knihu adres."

#: eventwindetails.cpp:362
msgid "Error getting entry from address book."
msgstr "Chyba p�i z�sk�v�n� z�znamu z knihy adres."

#: eventwinrecur.cpp:30
msgid "Start:  "
msgstr "Za��tek:"

#: eventwinrecur.cpp:31
msgid "End:  "
msgstr "Konec:"

#: eventwinrecur.cpp:61
msgid "Recurrence Rule"
msgstr "Pravidla opkov�n�"

#: eventwinrecur.cpp:67
msgid "Daily"
msgstr "Denn�"

#: eventwinrecur.cpp:68
msgid "Weekly"
msgstr "T�denn�"

#: eventwinrecur.cpp:69
msgid "Monthly"
msgstr "M�s��n�"

#: eventwinrecur.cpp:70
msgid "Yearly"
msgstr "Ro�n�"

#: eventwinrecur.cpp:95
msgid "Enable Advanced Rule:"
msgstr "Povolit dokonalej�� pravidlo:"

#: eventwinrecur.cpp:128
msgid "Recurrence Range"
msgstr "Rozsah opakov�n�"

#: eventwinrecur.cpp:132
msgid "Begin On:"
msgstr "Za��t dne:"

#: eventwinrecur.cpp:134
msgid "No Ending Date"
msgstr "Bez koncov�ho data"

#: eventwinrecur.cpp:135
msgid "End after"
msgstr "Ukon�it po"

#: eventwinrecur.cpp:137
msgid "occurrence(s)"
msgstr "opakov�n�(ch)"

#: eventwinrecur.cpp:138
msgid "End by:"
msgstr "Ukon�it dnem:"

#: eventwinrecur.cpp:181
msgid "Exceptions"
msgstr "V�jimky"

#: eventwinrecur.cpp:267 eventwinrecur.cpp:297
msgid "Recur every"
msgstr "Opakovat ka�d�"

#: eventwinrecur.cpp:273
msgid "day(s)"
msgstr "den"

#: eventwinrecur.cpp:303
msgid "week(s) on:"
msgstr "t�den v:"

#: eventwinrecur.cpp:305 kagenda.cpp:106
msgid "Sun"
msgstr "Ne "

#: eventwinrecur.cpp:306 kagenda.cpp:105
msgid "Mon"
msgstr "Po "

#: eventwinrecur.cpp:307 kagenda.cpp:105
msgid "Tue"
msgstr "�t "

#: eventwinrecur.cpp:308 kagenda.cpp:105
msgid "Wed"
msgstr "St "

#: eventwinrecur.cpp:309 kagenda.cpp:106
msgid "Thu"
msgstr "�t "

#: eventwinrecur.cpp:310 kagenda.cpp:106
msgid "Fri"
msgstr "P� "

#: eventwinrecur.cpp:311 kagenda.cpp:106
msgid "Sat"
msgstr "So "

#: eventwinrecur.cpp:361 eventwinrecur.cpp:365
msgid "Recur on the"
msgstr "Opakovat"

#: eventwinrecur.cpp:363
msgid "day"
msgstr "den"

#: eventwinrecur.cpp:369 eventwinrecur.cpp:481
msgid "every"
msgstr "ka�d�"

#: eventwinrecur.cpp:371
msgid "month(s)"
msgstr "m�s�c"

#: eventwinrecur.cpp:383 eventwinrecur.cpp:424
msgid "1st"
msgstr "1"

#: eventwinrecur.cpp:384 eventwinrecur.cpp:425
msgid "2nd"
msgstr "2"

#: eventwinrecur.cpp:385 eventwinrecur.cpp:426
msgid "3rd"
msgstr "3"

#: eventwinrecur.cpp:386 eventwinrecur.cpp:427
msgid "4th"
msgstr "4"

#: eventwinrecur.cpp:387 eventwinrecur.cpp:428
msgid "5th"
msgstr "5"

#: eventwinrecur.cpp:388
msgid "6th"
msgstr "6"

#: eventwinrecur.cpp:389
msgid "7th"
msgstr "7"

#: eventwinrecur.cpp:390
msgid "8th"
msgstr "8"

#: eventwinrecur.cpp:391
msgid "9th"
msgstr "9"

#: eventwinrecur.cpp:392
msgid "10th"
msgstr "10"

#: eventwinrecur.cpp:393
msgid "11th"
msgstr "11"

#: eventwinrecur.cpp:394
msgid "12th"
msgstr "12"

#: eventwinrecur.cpp:395
msgid "13th"
msgstr "13"

#: eventwinrecur.cpp:396
msgid "14th"
msgstr "14"

#: eventwinrecur.cpp:397
msgid "15th"
msgstr "15"

#: eventwinrecur.cpp:398
msgid "16th"
msgstr "16"

#: eventwinrecur.cpp:399
msgid "17th"
msgstr "17"

#: eventwinrecur.cpp:400
msgid "18th"
msgstr "18"

#: eventwinrecur.cpp:401
msgid "19th"
msgstr "19"

#: eventwinrecur.cpp:402
msgid "20th"
msgstr "20"

#: eventwinrecur.cpp:403
msgid "21st"
msgstr "21"

#: eventwinrecur.cpp:404
msgid "22nd"
msgstr "22"

#: eventwinrecur.cpp:405
msgid "23rd"
msgstr "23"

#: eventwinrecur.cpp:406
msgid "24th"
msgstr "24"

#: eventwinrecur.cpp:407
msgid "25th"
msgstr "25"

#: eventwinrecur.cpp:408
msgid "26th"
msgstr "26"

#: eventwinrecur.cpp:409
msgid "27th"
msgstr "27"

#: eventwinrecur.cpp:410
msgid "28th"
msgstr "28"

#: eventwinrecur.cpp:411
msgid "29th"
msgstr "29"

#: eventwinrecur.cpp:412
msgid "30th"
msgstr "30"

#: eventwinrecur.cpp:413
msgid "31st"
msgstr "31"

#: eventwinrecur.cpp:466
msgid "Recur in the month of"
msgstr "Opakovat v m�s�ci"

#: eventwinrecur.cpp:467
msgid "Recur on this day"
msgstr "Opakovat v tento den"

#: calprinter.cpp:327 calprinter.cpp:429 calprinter.cpp:720
#: eventwinrecur.cpp:469 kdatenav.cpp:68 kdatenav.cpp:258
msgid "January"
msgstr "Leden"

#: calprinter.cpp:327 calprinter.cpp:429 calprinter.cpp:720
#: eventwinrecur.cpp:470 kdatenav.cpp:68 kdatenav.cpp:258
msgid "February"
msgstr "�nor"

#: calprinter.cpp:328 calprinter.cpp:430 calprinter.cpp:721
#: eventwinrecur.cpp:471 kdatenav.cpp:68 kdatenav.cpp:259
msgid "March"
msgstr "B�ezen"

#: calprinter.cpp:328 calprinter.cpp:430 calprinter.cpp:721
#: eventwinrecur.cpp:472 kdatenav.cpp:69 kdatenav.cpp:259
msgid "April"
msgstr "Duben"

#: calprinter.cpp:329 calprinter.cpp:431 calprinter.cpp:722
#: eventwinrecur.cpp:473 kdatenav.cpp:69 kdatenav.cpp:260
msgid "May"
msgstr "Kv�ten"

#: calprinter.cpp:329 calprinter.cpp:431 calprinter.cpp:722
#: eventwinrecur.cpp:474 kdatenav.cpp:69 kdatenav.cpp:260
msgid "June"
msgstr "�erven"

#: calprinter.cpp:330 calprinter.cpp:432 calprinter.cpp:723
#: eventwinrecur.cpp:475 kdatenav.cpp:69 kdatenav.cpp:261
msgid "July"
msgstr "�ervenec"

#: calprinter.cpp:330 calprinter.cpp:432 calprinter.cpp:723
#: eventwinrecur.cpp:476 kdatenav.cpp:70 kdatenav.cpp:261
msgid "August"
msgstr "Srpen"

#: calprinter.cpp:331 calprinter.cpp:433 calprinter.cpp:724
#: eventwinrecur.cpp:477 kdatenav.cpp:70 kdatenav.cpp:262
msgid "September"
msgstr "Z���"

#: calprinter.cpp:331 calprinter.cpp:433 calprinter.cpp:724
#: eventwinrecur.cpp:478 kdatenav.cpp:70 kdatenav.cpp:262
msgid "October"
msgstr "��jen"

#: calprinter.cpp:332 calprinter.cpp:434 calprinter.cpp:725
#: eventwinrecur.cpp:479 kdatenav.cpp:71 kdatenav.cpp:263
msgid "November"
msgstr "Listopad"

#: calprinter.cpp:332 calprinter.cpp:434 calprinter.cpp:725
#: eventwinrecur.cpp:480 kdatenav.cpp:71 kdatenav.cpp:263
msgid "December"
msgstr "Prosinec"

#: eventwinrecur.cpp:484
msgid "year(s)"
msgstr "rok"

#: kagenda.cpp:212
msgid "All Day Event"
msgstr "Celodenn� ud�lost"

#: kagenda.cpp:829
msgid "New appointment"
msgstr "Nov� ur�en�"

#: kagenda.cpp:966 kagenda.cpp:974
msgid "am"
msgstr "am"

#: kagenda.cpp:970
msgid "pm"
msgstr "pm"

#: kdatenav.cpp:44
msgid "Previous Year"
msgstr "P�edchoz� rok"

#: kdatenav.cpp:50
msgid "Previous Month"
msgstr "Predchoz� m�s�c"

#: kdatenav.cpp:56
msgid "Next Month"
msgstr "Nasleduj�c� m�s�c"

#: kdatenav.cpp:62
msgid "Next Year"
msgstr "N�sleduj�c� rok"

#: kmonthview.cpp:386
msgid "New Event"
msgstr "Nov� ud�lost"

#: kpbutton.cpp:22 kpbutton.cpp:40 kpbutton.cpp:90
msgid "KPButton: pixmap is empty, perhaps some missing file"
msgstr "KPButton: pixmapa je pr�zdn�, pravd�podovn� chyb� n�jak� soubor"

#: baselistview.cpp:28
msgid "Date"
msgstr "Datum"

#: baselistview.cpp:29
msgid "Time"
msgstr "�as"

#: baselistview.cpp:30 calprinter.cpp:365
msgid "Summary"
msgstr "Shrnut�"

#: baselistview.cpp:77
msgid "started "
msgstr "za�alo "

#: baselistview.cpp:80
msgid "ends "
msgstr "kon�� "

#: baselistview.cpp:85
#, c-format
msgid "repeats %d times"
msgstr "opakuje se %d kr�t"

#: baselistview.cpp:89
msgid "repeats forever"
msgstr "bude se st�le opakovat"

#: listview.cpp:14
msgid "Edit Event"
msgstr "Upravit ud�lost"

#: listview.cpp:17
msgid "Delete Event  "
msgstr "Smazat ud�lost"

#: listview.cpp:20
msgid "Show Dates"
msgstr "Zobrazit datumy"

#: listview.cpp:22
msgid "Hide Dates"
msgstr "Skr�t datumy"

#: main.cpp:29
msgid "No default calendar, and none was specified on the command line.\n"
msgstr "��dn� implicitn� kalend�� a ��dn� nebyl ud�n na p��kazov� ��dce.\n"

#: main.cpp:33
msgid "Error reading from default calendar.\n"
msgstr "Chyba p�i �ten� z implicitn�ho kalend��e.\n"

#: searchdialog.cpp:22
msgid "Search For:"
msgstr ""

#: searchdialog.cpp:32 topwidget.cpp:494
#, fuzzy
msgid "&Search"
msgstr "&Hledat..."

#: searchdialog.cpp:81
msgid ""
"Invalid search expression, cannot perform\n"
"the search.  Please enter a search expression\n"
"using the wildcard characters '*' and '?'\n"
"where needed."
msgstr ""

#: topwidget.cpp:391
msgid "&Open"
msgstr ""

#: topwidget.cpp:394
msgid "Open &Recent"
msgstr "Ote&v��t ned�vn�"

#: topwidget.cpp:410
#, fuzzy
msgid "Save &As"
msgstr "Ulo�it &jako ..."

#: topwidget.cpp:415
#, fuzzy
msgid "&Import From Ical"
msgstr "&Importovat z programu Icalu..."

#: topwidget.cpp:417
#, fuzzy
msgid "&Merge Calendar"
msgstr "&Slou�it kalend��..."

#: topwidget.cpp:420
#, fuzzy
msgid "Archive Old Entries"
msgstr "Archivovat star� z�znamy"

#: topwidget.cpp:427
#, fuzzy
msgid "Print Setup"
msgstr "Nastaven� tisku..."

#: calprinter.cpp:844 topwidget.cpp:431
msgid "&Print"
msgstr "&Tisknout"

#: topwidget.cpp:433
#, fuzzy
msgid "Print Pre&view"
msgstr "N�&hled tisku ..."

#: topwidget.cpp:455
msgid "&List"
msgstr "&Seznam"

#: topwidget.cpp:459
msgid "&Day"
msgstr "&Den"

#: topwidget.cpp:462
msgid "W&ork Week"
msgstr "Prac&ovn� t�den"

#: topwidget.cpp:465
msgid "&Week"
msgstr "&T�den"

#: topwidget.cpp:468
msgid "&Month"
msgstr "&M�s�c"

#: topwidget.cpp:471
#, fuzzy
msgid "&To-do list"
msgstr "S&eznam �kol�"

#: topwidget.cpp:479
msgid "New &Appointment"
msgstr "&Nov� ur�en�"

#: topwidget.cpp:481
msgid "New E&vent"
msgstr "No&v� ud�lost"

#: topwidget.cpp:483
msgid "&Edit Appointment"
msgstr "&Upravit ur�en�"

#: topwidget.cpp:486
msgid "&Delete Appointment"
msgstr "&Smazat ur�en�"

#: topwidget.cpp:488
#, fuzzy
msgid "Delete To-do"
msgstr "Smazat �kol"

#: topwidget.cpp:498
#, fuzzy
msgid "&Mail Appointment"
msgstr "Odeslat sch�zku"

#: topwidget.cpp:504
#, fuzzy
msgid "Go to &Today"
msgstr "Jdi na dne�n� den"

#: topwidget.cpp:508
#, fuzzy
msgid "&Previous Day"
msgstr "P�edchoz� rok"

#: topwidget.cpp:512
#, fuzzy
msgid "&Next Day"
msgstr "N�sleduj�c� rok"

#: topwidget.cpp:516
msgid "Show &Tool Bar"
msgstr "Zobrazovat n�s&trojovou li�tu"

#: topwidget.cpp:520
msgid "Show St&atus Bar"
msgstr "Zobrazovat &informa�n� li�tu"

#: topwidget.cpp:525
msgid "&Edit Options"
msgstr "Nastaven� editov�n�"

#: topwidget.cpp:533
msgid "&About"
msgstr "&Informace"

#: topwidget.cpp:535
msgid "Send &Bug Report"
msgstr "Poslat &hl�en� o chyb�"

#: topwidget.cpp:543
msgid "&Actions"
msgstr "�&innosti"

#: topwidget.cpp:562
msgid "Open A Calendar"
msgstr "Otev��t kalend��"

#: topwidget.cpp:568
msgid "Save This Calendar"
msgstr "Ulo�it tento kalend��"

#: topwidget.cpp:585
msgid "New Appointment"
msgstr "Nov� ur�en�"

#: topwidget.cpp:591
msgid "Delete Appointment"
msgstr "Smazat ur�en�"

#: topwidget.cpp:597
msgid "Search For an Appointment"
msgstr "Hledat ur�en�"

#: topwidget.cpp:603
msgid "Mail Appointment"
msgstr "Odeslat sch�zku"

#: topwidget.cpp:622
msgid "Go to Today"
msgstr "Jdi na dne�n� den"

#: topwidget.cpp:628
#, fuzzy
msgid "Previous Day"
msgstr "P�edchoz� rok"

#: topwidget.cpp:634
#, fuzzy
msgid "Next Day"
msgstr "N�sleduj�c� rok"

#: topwidget.cpp:650
msgid "List View"
msgstr "N�hled na seznam"

#: topwidget.cpp:655
msgid "Schedule View"
msgstr "Rozvrhov� n�hled"

#: topwidget.cpp:662
msgid "Month View"
msgstr "M�s��n� n�hled"

#: topwidget.cpp:668
#, fuzzy
msgid "To-do list view"
msgstr "N�hled na Seznam �kol�"

#: topwidget.cpp:750
msgid "we don't handle updates for that view, yet.\n"
msgstr "pro tento n�hled nen� je�t� podporov�na aktualizace.\n"

#: topwidget.cpp:842
msgid "we don't handle that view yet.\n"
msgstr "tento n�hled nen� je�t� podporov�n.\n"

#: topwidget.cpp:960
msgid "You did not specify a valid file name."
msgstr ""

#: topwidget.cpp:968
msgid ""
"The file you specified is a directory,\n"
"and cannot be opened. Please try again,\n"
"this time selecting a valid calendar file."
msgstr ""

#: topwidget.cpp:995
msgid "KOrganizer Warning"
msgstr "Varov�n� KOrganizeru"

#: topwidget.cpp:996
#, fuzzy
msgid ""
"This calendar has been modified.\n"
"Would you like to save it?"
msgstr ""
"Uzav�ran� kalend�� byl modifikov�n.\n"
"P�ejete si ulo�it Va�e zm�ny?"

#: topwidget.cpp:998
msgid "&Yes"
msgstr ""

#: topwidget.cpp:998
msgid "&No"
msgstr ""

#: topwidget.cpp:1007 topwidget.cpp:1597
msgid "KOrganizer Confirmation"
msgstr "Potvrzen� KOrganizeru"

#: topwidget.cpp:1008
msgid "This item will be permanently deleted."
msgstr ""

#: topwidget.cpp:1111
msgid ""
"You have no ical file in your home directory.\n"
"Import cannot proceed.\n"
msgstr ""
"Nem�te ��dn� soubor programu ical ve Va�em domovsk�m adres��i.\n"
"Importov�n� nem��e pokra�ovat.\n"

#: topwidget.cpp:1124
msgid "KOrganizer Info"
msgstr "Informace KOrganizeru"

#: topwidget.cpp:1125
msgid ""
"KOrganizer succesfully imported and merged your\n"
".calendar file from ical into the currently\n"
"opened calendar.\n"
msgstr ""
"KOrganizer �sp�n� importoval a slou�il V�\n"
"soubor .calendar programu ical do pr�v�\n"
"otev�en�ho kalend��e.\n"

#: topwidget.cpp:1130
msgid "ICal Import Successful With Warning"
msgstr "Importov�n� z programu ICal �sp�n� s varov�n�m"

#: topwidget.cpp:1131
msgid ""
"KOrganizer encountered some unknown fields while\n"
"parsing your .calendar ical file, and had to\n"
"discard them.  Please check to see that all\n"
"your relevant data was correctly imported.\n"
msgstr ""
"KOrganizer narazil na n�jak� nezn�m� polo�ky b�hem \n"
"zpracov�v�n� V�eho souboru .calendar z programu ical,\n"
"kter� mus� vy�adit. Pros�m zkontrolujte, zda v�echna \n"
"d�le�it� data byla spr�vn� importov�na.\n"

#: topwidget.cpp:1137
msgid ""
"KOrganizer encountered some error parsing your\n"
".calendar file from ical.  Import has failed.\n"
msgstr ""
"KOrganizer narazil na n�jak� chyby b�hem zpracov�v�n� Va�eho \n"
"souboru .calendar z programu ical. Importov�n� se nezda�ilo.\n"

#: topwidget.cpp:1141
msgid ""
"KOrganizer doesn't think that your .calendar\n"
"file is a valid ical calendar. Import has failed.\n"
msgstr ""
"KOrganizer si nemysl�, �e Va� soubor .calendar je platn�m\n"
"kalend��em programu ical. Importov�n� se nezda�ilo.\n"

#: topwidget.cpp:1305 topwidget.cpp:1332 topwidget.cpp:1683 topwidget.cpp:1693
msgid "KOrganizer error"
msgstr "Chyba KOrganizeru"

#: topwidget.cpp:1306 topwidget.cpp:1333
msgid ""
"Unfortunately, we don't handle cut/paste for\n"
"that view yet.\n"
msgstr ""
"Nane�t�st� nen� vyjmut�/vlo�en� je�t�\n"
"podlorov�no v tomto n�hledu.\n"

#: topwidget.cpp:1549
msgid "don't handle deletes from that view, yet.\n"
msgstr "je�t� nen� podporov�no maz�n� z tohoto n�hledu.\n"

#: topwidget.cpp:1598
#, fuzzy
msgid ""
"This event recurs over multiple dates.\n"
"Are you sure you want to delete the\n"
"selected event, or just this instance?\n"
msgstr ""
"Tato ud�lost se opakuje ve v�ce dnech.\n"
"Jste si jist(a), �e chcete smazat vybranou \n"
"ud�lost, nebo pouze tuto instanci?\n"

#: topwidget.cpp:1601
msgid "&All"
msgstr "&V�echny"

#: topwidget.cpp:1601
msgid "&This"
msgstr "&Tuto"

#: topwidget.cpp:1616
msgid "no date selected, or invalid date\n"
msgstr "nen� vybr�n ��dn� datum nebo je datum neplatn�\n"

#: topwidget.cpp:1684
msgid "Can't generate mail from this view\n"
msgstr "Nen� mo�n� vytvo�it po�tu z tohoto n�hledu\n"

#: topwidget.cpp:1694
msgid ""
"Can't generate mail:\n"
" No attendees defined!\n"
msgstr ""
"Nen� mo�n� vytvo�it po�tu:\n"
" Nejsou definov�ni ��astn�ci!\n"
" \n"

#: topwidget.cpp:1833
#, fuzzy
msgid "New Calendar"
msgstr "Otev��t kalend��"

#: eventwin.cpp:313 eventwin.cpp:319 topwidget.cpp:1839
msgid "modified"
msgstr ""

#: eventwin.cpp:325 topwidget.cpp:1844
#, fuzzy
msgid "KOrganizer"
msgstr "Organiz�tor"

#: calprinter.cpp:47
msgid "Korganizer Configuration Options"
msgstr "Mo�nosti nastaven� KOrganizeru"

#: calprinter.cpp:361 todowingeneral.cpp:60
msgid "Priority"
msgstr "Priorita"

#: calprinter.cpp:369
msgid "Due"
msgstr "Do"

#: calprinter.cpp:453
#, c-format
msgid "To-Do items: %s %.2d"
msgstr "�koly: %s %.2d"

#: calprinter.cpp:791
msgid "Date Range"
msgstr "Rozsah data"

#: calprinter.cpp:811
msgid "View Type"
msgstr "Typ n�hledu"

#: calprinter.cpp:816
msgid "Day"
msgstr "Den"

#: calprinter.cpp:821
msgid "Week"
msgstr "T�den"

#: calprinter.cpp:825
msgid "Month"
msgstr "M�s�c"

#: calprinter.cpp:829
msgid "To-Do"
msgstr "�koly"

#: calprinter.cpp:843
msgid "&Preview"
msgstr "&N�hled"

#: koarchivedlg.cpp:19
msgid "Archive / Delete Past Appointments - KOrganizer"
msgstr "Archivovat/smazat minul� ur�en� - KOrganizer"

#: optionsdlg.cpp:37
msgid "Time & Date"
msgstr "�as a datum"

#: optionsdlg.cpp:43
msgid "Colors"
msgstr "Barvy"

#: optionsdlg.cpp:46
msgid "Views"
msgstr "N�hledy"

#: optionsdlg.cpp:52
msgid "Printing"
msgstr "Tisk"

#: optionsdlg.cpp:65
#, fuzzy
msgid "KOrganizer Configuration"
msgstr "Potvrzen� KOrganizeru"

#: optionsdlg.cpp:92
msgid "Your name:"
msgstr "Va�e jm�no:"

#: optionsdlg.cpp:96
msgid "Email address:"
msgstr "E-mail adresa:"

#: optionsdlg.cpp:100
msgid "Additional:"
msgstr "Dal��:"

#: optionsdlg.cpp:104
msgid "Auto-save Calendar"
msgstr "Automatick� ukl�d�n� kalend��e"

#: optionsdlg.cpp:108
msgid "Confirm Appointment/To-Do Deletes"
msgstr "Potvrzovat maz�n� ur�en�/�kol�"

#: optionsdlg.cpp:112
msgid "Holidays:"
msgstr "Sv�tky:"

#: optionsdlg.cpp:138
msgid "1 minute"
msgstr ""

#: optionsdlg.cpp:138
msgid "5 minutes"
msgstr ""

#: optionsdlg.cpp:139
msgid "10 minutes"
msgstr ""

#: optionsdlg.cpp:139
msgid "15 minutes"
msgstr ""

#: optionsdlg.cpp:140
msgid "30 minutes"
msgstr ""

#: optionsdlg.cpp:147
msgid "Time Format:"
msgstr "Form�t �asu:"

#: optionsdlg.cpp:148
msgid "24 hour"
msgstr ""

#: optionsdlg.cpp:149
msgid "AM / PM"
msgstr ""

#: optionsdlg.cpp:153
msgid "Date Format:"
msgstr "Datov� form�t:"

#: optionsdlg.cpp:154
msgid "Day.Month.Year (31.01.2000)"
msgstr "Den.M�s�c.Rok (31.01.2000)"

#: optionsdlg.cpp:155
msgid "Month/Day/Year (01/31/2000)"
msgstr "M�s�c/Den/Rok (01/31/2000)"

#: optionsdlg.cpp:156
msgid "Month-Day-Year (01-31-2000)"
msgstr "M�s�c-Den-Rok (01-31-2000)"

#: optionsdlg.cpp:160
msgid "Time Zone:"
msgstr "�asov� z�na:"

#: optionsdlg.cpp:167
msgid "Default Appointment Time:"
msgstr "Implicitn� �as ur�en�"

#: optionsdlg.cpp:177
msgid "Default Alarm Time:"
msgstr "Implicitn� �as signalizace: "

#: optionsdlg.cpp:185
msgid "Week Starts on Monday"
msgstr "T�den za��n� v pond�l�"

#: optionsdlg.cpp:202
msgid "Day Begins At:"
msgstr "Den za��n� v:"

#: optionsdlg.cpp:212
msgid "Hour size in schedule view"
msgstr ""

#: optionsdlg.cpp:216
msgid "Show events that recur daily in Date Navigator"
msgstr "Zobrazit v navig�toru term�n� ud�losti, kter� se opakuj� denn�."

#: optionsdlg.cpp:228
#, fuzzy
msgid "List view font"
msgstr "N�hled na seznam"

#: optionsdlg.cpp:234
#, fuzzy
msgid "Schedule view font"
msgstr "Rozvrhov� n�hled"

#: optionsdlg.cpp:240
#, fuzzy
msgid "Month view font"
msgstr "M�s��n� n�hled"

#: optionsdlg.cpp:245
msgid "12345"
msgstr ""

#: optionsdlg.cpp:245
#, fuzzy
msgid "Time bar font"
msgstr "�asov� z�na:"

#: optionsdlg.cpp:250
msgid "Things to do"
msgstr "V�ci na pr�ci"

#: optionsdlg.cpp:251
#, fuzzy
msgid "To-Do list font"
msgstr "S&eznam �kol�"

#: optionsdlg.cpp:272
msgid "Use system default colors"
msgstr "Pou��vat implicitn� barvy syst�mu"

#: optionsdlg.cpp:277
#, fuzzy
msgid "Appointment & Checklist items"
msgstr "�as ur�en�"

#: optionsdlg.cpp:278
msgid "Background"
msgstr "Pozad�"

#: optionsdlg.cpp:281
msgid "Text"
msgstr "Text"

#: optionsdlg.cpp:284
msgid "Handle Selected"
msgstr "�chopka ozna�en�ch"

#: optionsdlg.cpp:287
msgid "Handle Unselected"
msgstr "�chopka neozna�en�ch"

#: optionsdlg.cpp:290
msgid "Handle Active Apt."
msgstr "�chopka aktivn�ch"

#: optionsdlg.cpp:295
msgid "Sheet background"
msgstr "Pozad� plochy"

#: optionsdlg.cpp:298
msgid "Calendar Background"
msgstr "Pozad� kalend��e"

#: optionsdlg.cpp:301
msgid "Calendar Date Text"
msgstr "Text datumu kalend��e"

#: optionsdlg.cpp:304
msgid "Calendar Date Selected"
msgstr "Vybran� datum kalend��e"

#: optionsdlg.cpp:343
msgid "Printer Name"
msgstr "Jm�no tisk�rny"

#: optionsdlg.cpp:373
msgid "Paper Size"
msgstr "Velikost pap�ru"

#: optionsdlg.cpp:375
msgid "A4"
msgstr "A4"

#: optionsdlg.cpp:376
msgid "B5"
msgstr "B5"

#: optionsdlg.cpp:377
msgid "Letter"
msgstr "Letter"

#: optionsdlg.cpp:378
msgid "Legal"
msgstr "Legal"

#: optionsdlg.cpp:379
msgid "Executive"
msgstr "Executive"

#: optionsdlg.cpp:383
msgid "Paper Orientation"
msgstr "Orientace pap�ru"

#: optionsdlg.cpp:385
msgid "Portrait"
msgstr "Na v��ku"

#: optionsdlg.cpp:387
msgid "Landscape"
msgstr "Na ���ku"

#: optionsdlg.cpp:394
msgid "Preview Program"
msgstr "Program pro n�hled"

#: kpropdlg.cpp:124
msgid "Prev"
msgstr "P�ed�zej�c�"

#: kpropdlg.cpp:125
msgid "Next"
msgstr "N�sleduj�c�"

#: aboutdlg.cpp:20
#, fuzzy
msgid "KOrganizer Virtual Postcard"
msgstr "Chyba KOrganiz�ru"

#: aboutdlg.cpp:24
msgid ""
"Please send a postcard to me, so I can see who is\n"
"using KOrganizer! Tell me how great the program is,\n"
"and how you just can't live without it.  Or, report\n"
"a bug which is stopping you from doing useful work.\n"
"The postcard will simply include anything you wish to\n"
"type in the comment area below.\n"
msgstr ""
"Pros�m za�lete mi pozdrav, abych vid�l, kdo pou��v�\n"
"KOrganizer! Pov�zte mi, jak skv�l� je to program\n"
"a jak bez n�j prost� nem��ete ��t. Nebo mi nahla�te\n"
"chybu, kter� V�m br�n� d�lat rozumnou pr�ci.\n"
"Do pozdravu bude jednodu�e vlo�eno v�e co si nap��ete\n"
"do oblasti pod t�mto textem.\n"

#: aboutdlg.cpp:104
#, fuzzy
msgid "About KOrganizer"
msgstr "Organiz�tor"

#: aboutdlg.cpp:137
msgid "by Preston Brown and"
msgstr ""

#: aboutdlg.cpp:156
msgid "License Agreement:"
msgstr ""

#: aboutdlg.cpp:162
msgid ""
"\n"
"\n"
"This program is free software; you can redistribute it and/or modify\n"
"it under the terms of the GNU General Public License as published by\n"
"the Free Software Foundation; either version 2 of the License, or\n"
"(at your option) any later version.\n"
"\n"
"This program is distributed in the hope that it will be useful,\n"
"but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
"GNU General Public License for more details.\n"
"\n"
"You should have received a copy of the GNU General Public License\n"
"along with this program; if not, write to the Free Software\n"
"Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.\n"
msgstr ""
"\n"
"Tento program je voln� software; je mo�n� jej redistribuovat nebo \n"
"modifikovat podle podm�nek GNU v�eobecn� ve�ejn� licence jak je \n"
"publikov�va Free Software Fondation; bu� verze 2 zm�n�n� licence \n"
"nebo (dle va�eho v�b�ru) n�kterou pozd�j�� verz�.\n"
"\n"
"Tento program je ���en s nad�j�, �e bude u�ite�n� ale BEZ JAK�KOLI \n"
"Z�RUKY; dokonce bez zahrnut� z�ruky PRODEJNOSTI nebo ZP�SOBILOSTI \n"
"K N�JAK�MU ��ELU. Pro bli��� detaily nahl�dn�te do GNU v�eobecn� \n"
"ve�ejn� licence.\n"
"\n"
"M�li by jste obdr�et kopii GNU v�eobecn� ve�ejn� licence s t�mto \n"
"programem; nen�-li tomu tak, napi�te na adresu Free Software \n"
"Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.\n"

#: aboutdlg.cpp:197
#, fuzzy
msgid "&Send Postcard"
msgstr "Poslat pozdrav"

#: aboutdlg.cpp:233
msgid "many more, thank you!"
msgstr "mnohaker� d�ky!"

#: aboutdlg.cpp:255
msgid "Could not load movie"
msgstr ""

#: kotodoview.cpp:27
msgid "To-Do Items"
msgstr "�koly"

#: kotodoview.cpp:91 kotodoview.cpp:99
msgid "New To-Do"
msgstr "Nov� �kol"

#: kotodoview.cpp:94
msgid "Purge Completed "
msgstr "Pro�i�t�n� ukon�eno"

#: kotodoview.cpp:101
msgid "Edit To-Do"
msgstr "Upravit �kol"

#: kotodoview.cpp:104
msgid "Delete To-Do"
msgstr "Smazat �kol"

#: kotodoview.cpp:106
#, fuzzy
msgid "Purge Completed"
msgstr "Pro�i�t�n� ukon�eno"

#: kotodoview.cpp:108
#, fuzzy
msgid "Sort by Priority"
msgstr "Priorita"

#: eventwin.cpp:91
msgid "Save and Close"
msgstr "Ulo�it a zav��t"

#: eventwin.cpp:111
msgid "Previous Event"
msgstr "P�edchoz� ud�lost"

#: eventwin.cpp:117
msgid "Next Event"
msgstr "N�sleduj�c� ud�lost"

#: eventwin.cpp:128
msgid "Delete Event"
msgstr "Zru�it ud�lost"

#: eventwin.cpp:286
msgid "New"
msgstr ""

#: eventwin.cpp:293
#, fuzzy
msgid "Todo"
msgstr "�koly"

#: eventwin.cpp:309
msgid "readonly"
msgstr ""

#: todowingeneral.cpp:41
msgid "% Completed"
msgstr "% ukon�eno"

#: todowingeneral.cpp:48
#, c-format
msgid "0 %"
msgstr "0 %"

#: todowingeneral.cpp:49
#, c-format
msgid "25 %"
msgstr "25 %"

#: todowingeneral.cpp:50
#, c-format
msgid "50 %"
msgstr "50 %"

#: todowingeneral.cpp:51
#, c-format
msgid "75 %"
msgstr "75 %"

#: todowingeneral.cpp:67
msgid "1 (Highest)"
msgstr "1 (nejvy���)"

#: todowingeneral.cpp:68
msgid "2"
msgstr "2"

#: todowingeneral.cpp:69
msgid "3"
msgstr "3"

#: todowingeneral.cpp:70
msgid "4"
msgstr "4"

#: todowingeneral.cpp:71
msgid "5 (lowest)"
msgstr "5 (nejni���)"

#: alarmdaemon.cpp:39 alarmdaemon.cpp:44
msgid "Can't load docking tray icon!"
msgstr ""

#: alarmdaemon.cpp:48
msgid "Alarms Enabled"
msgstr ""

#: alarmdaemon.cpp:51
#, fuzzy
msgid "Exit Applet"
msgstr "&Upravit ur�en�"

#: alarmdaemon.cpp:54
#, fuzzy
msgid "KOrganizer Control Applet"
msgstr "Potvrzen� KOrganizeru"

#: alarmdaemon.cpp:156
#, fuzzy, c-format
msgid "KOrganizer Alarm: %s\n"
msgstr "Kategorie KOrganizeru"

#: alarmdaemon.cpp:157
msgid ""
"The following events triggered alarms:\n"
"\n"
msgstr ""

#~ msgid "New Appointment - KOrganizer"
#~ msgstr "Nov� ur�en� - KOrganizer"

#~ msgid "Edit Todo - KOrganizer (Readonly)"
#~ msgstr "�prava �kolu - KOrganizer (pouze ke �ten�)"

#~ msgid "Edit Appointment - KOrganizer (Readonly)"
#~ msgstr "�prava ur�en� - KOrganizer (pouze ke �ten�)"

#~ msgid "Edit Todo - KOrganizer"
#~ msgstr "�prava �kolu - KOrganizer"

#~ msgid "Edit Appointment - KOrganizer"
#~ msgstr "�prava ur�en� - KOrganizer"

#~ msgid "&Mail Appointment..."
#~ msgstr "&Odeslat sch�zku..."

#~ msgid "Previous"
#~ msgstr "P�edchoz�"

#~ msgid "Modified Calendar Warning"
#~ msgstr "Varov�n� modifikovan�ho kalend��e"

#~ msgid ""
#~ "You are opening a new calendar, but the currentone has been modified.\n"
#~ "Are you sure you want todo this? All changes will be lost!\n"
#~ "\n"
#~ msgstr ""
#~ "Otev�r�te nov� kalend��, ale sou�asn� kalend�� byl modifikov�n.\n"
#~ "Jste si jisti, �e si p�ejete prov�st tuto operaci? V�echny zm�ny budou "
#~ "ztraceny!\n"
#~ "\n"

#~ msgid "KOrganizer had a problem opening your file:\n"
#~ msgstr "Korganizer m�l p�i otev�r�n� va�eho souboru:\n"

#~ msgid ""
#~ "Please check that the directory and/or file exists,\n"
#~ "that you have permissions to read it, and try again."
#~ msgstr ""
#~ "Zkontrolujte pros�m, �e adres�� nebo soubor existuj�,\n"
#~ "zda-li m�te pr�va ke �ten�, a pot� zkuste opakovat."

#~ msgid "KOrganizer Modified Calendar Warning"
#~ msgstr "KOrganizer - Varov�n� modifikovan�ho kalend��e"

#~ msgid ""
#~ "You are opening a new calendar, but the current one has been modified.\n"
#~ "Are you sure you want to do this? All changes will be lost!\n"
#~ "\n"
#~ msgstr ""
#~ "Otev�r�te nov� kalend��, ale sou�asn� kalend�� byl modifikov�n.\n"
#~ "Jste si jisti, �e si p�ejete prov�st tuto operaci? V�echny zm�ny budou "
#~ "ztraceny!\n"
#~ "\n"

#~ msgid "KOrganizer had a problem saving your file:\n"
#~ msgstr "KOrganizer m�l probl�my s ukl�d�n�m va�eho souboru:\n"

#~ msgid ""
#~ "Please check that the directory exists and you have\n"
#~ "permission to write to it, and try again."
#~ msgstr ""
#~ "Zkontrolujte pros�m, �e adres�� existuje, a �e\n"
#~ "m�te pr�va k z�pisu do n�j, a pak zkuste opakovat."

#~ msgid "&Don't Save"
#~ msgstr "&Neukl�dat"

#~ msgid ""
#~ "Are you sure you want to delete\n"
#~ "the selected to do item?\n"
#~ "\n"
#~ msgstr ""
#~ "Jste si jist(a), �e chcete\n"
#~ "zru�it tuto polo�ku?\n"
#~ "\n"

#~ msgid ""
#~ "Are you sure you want to delete\n"
#~ "the selected event?\n"
#~ "\n"
#~ msgstr ""
#~ "Jste si jist(a), �e chcete\n"
#~ "zru�it tuto ud�lost?\n"
#~ "\n"

#~ msgid "%s%s- KOrganizer"
#~ msgstr "%s%s- KOrganizer"

#~ msgid "New Calendar%s- KOrganizer"
#~ msgstr "Nov� kalend��%s- KOrganizer"

#~ msgid "%s - KOrganizer"
#~ msgstr "%s - KOrganizer"

#~ msgid "New Calendar - KOrganizer"
#~ msgstr "Nov� kalend�� - KOrganizer"

#~ msgid "Test"
#~ msgstr "Test"
