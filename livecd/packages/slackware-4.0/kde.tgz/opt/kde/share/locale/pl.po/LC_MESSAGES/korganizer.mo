# translated by Krzysztof Jasiutowicz <kpjas@priv.onet.pl>
# contains his updates from 26.01.1999
msgid ""
msgstr ""
"Project-Id-Version: korganizer 0.9.18\n"
"POT-Creation-Date: 1999-04-20 03:16+0200\n"
"PO-Revision-Date: 1998-01-31 16:58+0100\n"
"Last-Translator: Jacek Stolarczyk <jacek@mer.chemia.polsl.gliwce.pl>\n"
"Language-Team: Polish <pl@li.org>\n"
"MIME-Version: 1.0\n"
"Content-Type: text/plain; charset=iso-8859-2\n"
"Content-Transfer-Encoding: 8-bit\n"

#: alarmdaemon.cpp:38 alarmdaemon.cpp:43 calobject.cpp:372 calobject.cpp:385
#: eventwindetails.cpp:341 eventwindetails.cpp:361 searchdialog.cpp:80
#: topwidget.cpp:959 topwidget.cpp:967 topwidget.cpp:1110 topwidget.cpp:1136
#: topwidget.cpp:1140
msgid "KOrganizer Error"
msgstr "B��d KOrganizer-a"

#: calobject.cpp:373 calobject.cpp:386
msgid ""
"An error has occurred parsing the contents of the clipboard.\n"
"You can only paste a valid vCalendar into KOrganizer.\n"
msgstr ""
"Wyst�pi� b��d przy analizie zawarto�ci schowka.\n"
"Mo�na wkleja� tylko poprawne zapisy vCalendar do KOrganizer-a.\n"

#: calobject.cpp:434
#, fuzzy
msgid "found a VEvent with no DTSTART/DTEND! Skipping"
msgstr "znaleziono VEvent bez DTSART/DTEND! Pomijam...\n"

#: catdlg.cpp:19
msgid "KOrganizer Categories"
msgstr "Kategorie KOrganizer-a"

#: catdlg.cpp:30
msgid "Available Categories"
msgstr "Dost�pne kategorie"

#: catdlg.cpp:36 eventwin.cpp:297 optionsdlg.cpp:227 optionsdlg.cpp:233
#: optionsdlg.cpp:239
msgid "Appointment"
msgstr "Spotkanie"

#: catdlg.cpp:37
msgid "Business"
msgstr "Biznes"

#: catdlg.cpp:38
msgid "Meeting"
msgstr "Spotkanie"

#: catdlg.cpp:39
msgid "Phone Call"
msgstr "Telefon"

#: catdlg.cpp:40
msgid "Education"
msgstr "Kszta�cenie"

#: catdlg.cpp:41
msgid "Holiday"
msgstr "Wypoczynek"

#: catdlg.cpp:42
msgid "Vacation"
msgstr "Wakacje"

#: catdlg.cpp:43
msgid "Special Occasion"
msgstr "Specjalne wydarzenie"

#: catdlg.cpp:44 optionsdlg.cpp:34
msgid "Personal"
msgstr "Osobiste"

#: catdlg.cpp:45
msgid "Travel"
msgstr "Podr�"

#: catdlg.cpp:55
msgid "&Add >>"
msgstr "&Dodaj >>"

#: catdlg.cpp:57
msgid "<< &Remove"
msgstr "<< &Usu�"

#: catdlg.cpp:66
msgid "Selected Categories"
msgstr "Wybrane kategorie"

#: catdlg.cpp:78
msgid "New Category:"
msgstr ""

#: editeventwin.cpp:116 todoeventwin.cpp:108
msgid "General"
msgstr "Og�lne"

#: editeventwin.cpp:117 todoeventwin.cpp:109
msgid "Details"
msgstr "Szczeg�owe"

#: editeventwin.cpp:119
msgid "Recurrence"
msgstr "Powtarzaj�ce si�"

#: editeventwin.cpp:195 editeventwin.cpp:406 todoeventwin.cpp:162
#: todoeventwin.cpp:182
#, c-format
msgid "Owner: %s"
msgstr "Nale�y do: %s"

#: editeventwin.cpp:810
msgid "Duration: all day"
msgstr "Czas trwania: ca�y dzie�"

#: editeventwin.cpp:818
#, c-format
msgid "Duration: %i hour(s), %i minute(s)"
msgstr "Czas trwania: %i godzin(a), %i minut(a)"

#: editeventwin.cpp:820
#, c-format
msgid "Duration: %i hour(s)"
msgstr "Czas trwania: %i godzin(a)"

#: editeventwin.cpp:822
#, c-format
msgid "Duration: %i minute(s)"
msgstr "Czas trwania: %i minut(a)"

#: eventwidget.cpp:193
msgid "Toggle Alarm"
msgstr "W��cz/wy��cz alarm"

#: eventwingeneral.cpp:42 eventwinrecur.cpp:28 wingeneral.cpp:34
msgid "Appointment Time"
msgstr "Czas spotkania"

#: eventwingeneral.cpp:47 wingeneral.cpp:39
msgid "Start Time:"
msgstr "Czas rozpocz�cia:"

#: eventwingeneral.cpp:58 wingeneral.cpp:48
msgid "End Time:"
msgstr "Czas zako�czenia:"

#: eventwingeneral.cpp:80 wingeneral.cpp:64
msgid "No time associated"
msgstr "Nie zwi�zane z czasem"

#: eventwingeneral.cpp:91 wingeneral.cpp:75
msgid "Recurring event"
msgstr "Powtarzaj�ce si� zdarzenie"

#: eventwingeneral.cpp:99 todowingeneral.cpp:77
msgid "Summary:"
msgstr "Podsumowanie:"

#: eventwingeneral.cpp:110
msgid "Show Time As:"
msgstr "Poka� czas jako:"

#: eventwingeneral.cpp:117
msgid "Busy"
msgstr "Zaj�ty"

#: eventwingeneral.cpp:118
msgid "Free"
msgstr "Wolny"

#: eventwingeneral.cpp:133 todowingeneral.cpp:96
msgid "Owner:"
msgstr "W�a�ciciel"

#: eventwingeneral.cpp:139 todowingeneral.cpp:102
msgid "Private"
msgstr "Prywatne"

#: eventwindetails.cpp:199 eventwingeneral.cpp:145 todowingeneral.cpp:108
msgid "Categories..."
msgstr "Kategorie..."

#: eventwingeneral.cpp:164
msgid "Reminder:"
msgstr "Przypomnienie:"

#: eventwindetails.cpp:39
msgid "Attendee Information"
msgstr "Informacje o uczestniku"

#: eventwindetails.cpp:46
msgid "Name"
msgstr "Nazwisko"

#: eventwindetails.cpp:47
msgid "Email"
msgstr "E-mail"

#: eventwindetails.cpp:48
msgid "Role"
msgstr "Rola"

#: eventwindetails.cpp:49
msgid "Status"
msgstr "Stan"

#: eventwindetails.cpp:50
msgid "RSVP"
msgstr "RSVP"

#: eventwindetails.cpp:65
msgid "Attendee Name:"
msgstr "Imi� i Nazwisko uczestnika:"

#: eventwindetails.cpp:77
msgid "Email Address:"
msgstr "Adres e-mail:"

#: eventwindetails.cpp:92
msgid "Role:"
msgstr "Rola:"

#: eventwindetails.cpp:98
msgid "Attendee"
msgstr "Uczestnik"

#: eventwindetails.cpp:99
msgid "Organizer"
msgstr "Organizator"

#: eventwindetails.cpp:100
msgid "Owner"
msgstr "W�a�ciciel"

#: eventwindetails.cpp:101
msgid "Delegate"
msgstr "Delegat"

#: eventwindetails.cpp:106
msgid "Status:"
msgstr "Stan:"

#: eventwindetails.cpp:112
msgid "Needs Action"
msgstr "Wymaga dzia�ania"

#: eventwindetails.cpp:113
msgid "Accepted"
msgstr "Zaakceptowane"

#: eventwindetails.cpp:114
msgid "Sent"
msgstr "Wys�ane"

#: eventwindetails.cpp:115
msgid "Tentative"
msgstr "Tymczasowe"

#: eventwindetails.cpp:116
msgid "Confirmed"
msgstr "Potwierdzone"

#: eventwindetails.cpp:117
msgid "Declined"
msgstr "Odm�wione"

#: eventwindetails.cpp:118 todowingeneral.cpp:35 todowingeneral.cpp:52
msgid "Completed"
msgstr "Zako�czone"

#: eventwindetails.cpp:119
msgid "Delegated"
msgstr "Oddelegowane"

#: eventwindetails.cpp:126
msgid "Request Response"
msgstr "Wymagaj odpowiedzi"

#: eventwindetails.cpp:132
msgid "&Add"
msgstr "&Dodaj"

#: eventwindetails.cpp:136
msgid "Address &Book..."
msgstr "&Ksi��ka adresowa..."

#: eventwindetails.cpp:163
msgid "Attach..."
msgstr "Do��cz..."

#: eventwindetails.cpp:183
msgid "Save As..."
msgstr "Zapisz jako..."

#: eventwindetails.cpp:218
msgid "Priority:"
msgstr "Priorytet:"

#: eventwindetails.cpp:224
msgid "Low (1)"
msgstr "Niski (1)"

#: eventwindetails.cpp:225
msgid "Normal (2)"
msgstr "Normalny (2)"

#: eventwindetails.cpp:226
msgid "High (3)"
msgstr "Wysoki (3)"

#: eventwindetails.cpp:227
msgid "Maximum (4)"
msgstr "Maksymalny (4)"

#: eventwindetails.cpp:342
msgid "Unable to open address book."
msgstr "Nie mo�na otworzy� ksi��ki adresowej."

#: eventwindetails.cpp:362
msgid "Error getting entry from address book."
msgstr "B��d przy pobieraniu wpisu z ksi��ki adresowej."

#: eventwinrecur.cpp:30
msgid "Start:  "
msgstr "Start:  "

#: eventwinrecur.cpp:31
msgid "End:  "
msgstr "Koniec:  "

#: eventwinrecur.cpp:61
msgid "Recurrence Rule"
msgstr "Zasada powtarzalno�ci"

#: eventwinrecur.cpp:67
msgid "Daily"
msgstr "Codziennie"

#: eventwinrecur.cpp:68
msgid "Weekly"
msgstr "Co tydzie�"

#: eventwinrecur.cpp:69
msgid "Monthly"
msgstr "Co miesi�c"

#: eventwinrecur.cpp:70
msgid "Yearly"
msgstr "Co rok"

#: eventwinrecur.cpp:95
msgid "Enable Advanced Rule:"
msgstr "W��cz zaawansowan� zasad�:"

#: eventwinrecur.cpp:128
msgid "Recurrence Range"
msgstr "Zakres powtarzalno�ci"

#: eventwinrecur.cpp:132
msgid "Begin On:"
msgstr "Zacznij w:"

#: eventwinrecur.cpp:134
msgid "No Ending Date"
msgstr "Bez daty zako�czenia"

#: eventwinrecur.cpp:135
msgid "End after"
msgstr "Zako�cz po"

#: eventwinrecur.cpp:137
msgid "occurrence(s)"
msgstr "powt�rze�(nie)"

#: eventwinrecur.cpp:138
msgid "End by:"
msgstr "Zako�cz przed:"

#: eventwinrecur.cpp:181
msgid "Exceptions"
msgstr "Wyj�tki"

#: eventwinrecur.cpp:267 eventwinrecur.cpp:297
msgid "Recur every"
msgstr "Powt�rz co:"

#: eventwinrecur.cpp:273
msgid "day(s)"
msgstr "dni"

#: eventwinrecur.cpp:303
msgid "week(s) on:"
msgstr "tygodni:"

#: eventwinrecur.cpp:305 kagenda.cpp:106
msgid "Sun"
msgstr "N  "

#: eventwinrecur.cpp:306 kagenda.cpp:105
msgid "Mon"
msgstr "Pn "

#: eventwinrecur.cpp:307 kagenda.cpp:105
msgid "Tue"
msgstr "Wt "

#: eventwinrecur.cpp:308 kagenda.cpp:105
msgid "Wed"
msgstr "�r"

#: eventwinrecur.cpp:309 kagenda.cpp:106
msgid "Thu"
msgstr "Czw"

#: eventwinrecur.cpp:310 kagenda.cpp:106
msgid "Fri"
msgstr "Pt "

#: eventwinrecur.cpp:311 kagenda.cpp:106
msgid "Sat"
msgstr "So "

#: eventwinrecur.cpp:361 eventwinrecur.cpp:365
msgid "Recur on the"
msgstr "Powt�rz"

#: eventwinrecur.cpp:363
msgid "day"
msgstr "dzie�"

#: eventwinrecur.cpp:369 eventwinrecur.cpp:481
msgid "every"
msgstr "co"

#: eventwinrecur.cpp:371
msgid "month(s)"
msgstr "miesi�cy"

#: eventwinrecur.cpp:383 eventwinrecur.cpp:424
msgid "1st"
msgstr "1-go"

#: eventwinrecur.cpp:384 eventwinrecur.cpp:425
msgid "2nd"
msgstr "2-go"

#: eventwinrecur.cpp:385 eventwinrecur.cpp:426
msgid "3rd"
msgstr "3-go"

#: eventwinrecur.cpp:386 eventwinrecur.cpp:427
msgid "4th"
msgstr "4-go"

#: eventwinrecur.cpp:387 eventwinrecur.cpp:428
msgid "5th"
msgstr "5-go"

#: eventwinrecur.cpp:388
msgid "6th"
msgstr "6-go"

#: eventwinrecur.cpp:389
msgid "7th"
msgstr "7-go"

#: eventwinrecur.cpp:390
msgid "8th"
msgstr "8-go"

#: eventwinrecur.cpp:391
msgid "9th"
msgstr "9-go"

#: eventwinrecur.cpp:392
msgid "10th"
msgstr "10-go"

#: eventwinrecur.cpp:393
msgid "11th"
msgstr "11-go"

#: eventwinrecur.cpp:394
msgid "12th"
msgstr "12-go"

#: eventwinrecur.cpp:395
msgid "13th"
msgstr "13-go"

#: eventwinrecur.cpp:396
msgid "14th"
msgstr "14-go"

#: eventwinrecur.cpp:397
msgid "15th"
msgstr "15-go"

#: eventwinrecur.cpp:398
msgid "16th"
msgstr "16-go"

#: eventwinrecur.cpp:399
msgid "17th"
msgstr "17-go"

#: eventwinrecur.cpp:400
msgid "18th"
msgstr "18-go"

#: eventwinrecur.cpp:401
msgid "19th"
msgstr "19-go"

#: eventwinrecur.cpp:402
msgid "20th"
msgstr "20-go"

#: eventwinrecur.cpp:403
msgid "21st"
msgstr "21-go"

#: eventwinrecur.cpp:404
msgid "22nd"
msgstr "22-go"

#: eventwinrecur.cpp:405
msgid "23rd"
msgstr "23-go"

#: eventwinrecur.cpp:406
msgid "24th"
msgstr "24-go"

#: eventwinrecur.cpp:407
msgid "25th"
msgstr "25-go"

#: eventwinrecur.cpp:408
msgid "26th"
msgstr "26-go"

#: eventwinrecur.cpp:409
msgid "27th"
msgstr "27-go"

#: eventwinrecur.cpp:410
msgid "28th"
msgstr "28-go"

#: eventwinrecur.cpp:411
msgid "29th"
msgstr "29-go"

#: eventwinrecur.cpp:412
msgid "30th"
msgstr "30-go"

#: eventwinrecur.cpp:413
msgid "31st"
msgstr "31-go"

#: eventwinrecur.cpp:466
msgid "Recur in the month of"
msgstr "Powt�rz w miesi�cu"

#: eventwinrecur.cpp:467
msgid "Recur on this day"
msgstr "Powt�rz dnia"

#: calprinter.cpp:327 calprinter.cpp:429 calprinter.cpp:720
#: eventwinrecur.cpp:469 kdatenav.cpp:68 kdatenav.cpp:258
msgid "January"
msgstr "Stycze�"

#: calprinter.cpp:327 calprinter.cpp:429 calprinter.cpp:720
#: eventwinrecur.cpp:470 kdatenav.cpp:68 kdatenav.cpp:258
msgid "February"
msgstr "Luty"

#: calprinter.cpp:328 calprinter.cpp:430 calprinter.cpp:721
#: eventwinrecur.cpp:471 kdatenav.cpp:68 kdatenav.cpp:259
msgid "March"
msgstr "Marzec"

#: calprinter.cpp:328 calprinter.cpp:430 calprinter.cpp:721
#: eventwinrecur.cpp:472 kdatenav.cpp:69 kdatenav.cpp:259
msgid "April"
msgstr "Kwiecie�"

#: calprinter.cpp:329 calprinter.cpp:431 calprinter.cpp:722
#: eventwinrecur.cpp:473 kdatenav.cpp:69 kdatenav.cpp:260
msgid "May"
msgstr "Maj"

#: calprinter.cpp:329 calprinter.cpp:431 calprinter.cpp:722
#: eventwinrecur.cpp:474 kdatenav.cpp:69 kdatenav.cpp:260
msgid "June"
msgstr "Czerwiec"

#: calprinter.cpp:330 calprinter.cpp:432 calprinter.cpp:723
#: eventwinrecur.cpp:475 kdatenav.cpp:69 kdatenav.cpp:261
msgid "July"
msgstr "Lipiec"

#: calprinter.cpp:330 calprinter.cpp:432 calprinter.cpp:723
#: eventwinrecur.cpp:476 kdatenav.cpp:70 kdatenav.cpp:261
msgid "August"
msgstr "Sierpie�"

#: calprinter.cpp:331 calprinter.cpp:433 calprinter.cpp:724
#: eventwinrecur.cpp:477 kdatenav.cpp:70 kdatenav.cpp:262
msgid "September"
msgstr "Wrzesie�"

#: calprinter.cpp:331 calprinter.cpp:433 calprinter.cpp:724
#: eventwinrecur.cpp:478 kdatenav.cpp:70 kdatenav.cpp:262
msgid "October"
msgstr "Pa�dziernik"

#: calprinter.cpp:332 calprinter.cpp:434 calprinter.cpp:725
#: eventwinrecur.cpp:479 kdatenav.cpp:71 kdatenav.cpp:263
msgid "November"
msgstr "Listopad"

#: calprinter.cpp:332 calprinter.cpp:434 calprinter.cpp:725
#: eventwinrecur.cpp:480 kdatenav.cpp:71 kdatenav.cpp:263
msgid "December"
msgstr "Grudzie�"

#: eventwinrecur.cpp:484
msgid "year(s)"
msgstr "lat"

#: kagenda.cpp:212
msgid "All Day Event"
msgstr "Przez ca�y dzie�"

#: kagenda.cpp:829
msgid "New appointment"
msgstr "Nowe spotkanie"

#: kagenda.cpp:966 kagenda.cpp:974
msgid "am"
msgstr "am"

#: kagenda.cpp:970
msgid "pm"
msgstr "pm"

#: kdatenav.cpp:44
msgid "Previous Year"
msgstr "Poprzedni rok"

#: kdatenav.cpp:50
msgid "Previous Month"
msgstr "Poprzedni miesi�c"

#: kdatenav.cpp:56
msgid "Next Month"
msgstr "Nast�pny miesi�c"

#: kdatenav.cpp:62
msgid "Next Year"
msgstr "Nast�pny rok"

#: kmonthview.cpp:386
msgid "New Event"
msgstr "Nowe zdarzenie"

#: kpbutton.cpp:22 kpbutton.cpp:40 kpbutton.cpp:90
msgid "KPButton: pixmap is empty, perhaps some missing file"
msgstr "KPButton: pixmap-a jest pusta, mo�e brak pliku"

#: baselistview.cpp:28
msgid "Date"
msgstr "Data"

#: baselistview.cpp:29
msgid "Time"
msgstr "Czas"

#: baselistview.cpp:30 calprinter.cpp:365
msgid "Summary"
msgstr "Podsumowanie"

#: baselistview.cpp:77
msgid "started "
msgstr "rozpocz�te "

#: baselistview.cpp:80
msgid "ends "
msgstr "zako�czenie "

#: baselistview.cpp:85
#, c-format
msgid "repeats %d times"
msgstr "powt�rzenie %d razy"

#: baselistview.cpp:89
msgid "repeats forever"
msgstr "powtarzanie ci�g�e"

#: listview.cpp:14
msgid "Edit Event"
msgstr "Edycja zdarzenia"

#: listview.cpp:17
msgid "Delete Event  "
msgstr "Skasowanie zdarzenia "

#: listview.cpp:20
msgid "Show Dates"
msgstr "Poka� daty"

#: listview.cpp:22
msgid "Hide Dates"
msgstr "Ukryj daty"

#: main.cpp:29
msgid "No default calendar, and none was specified on the command line.\n"
msgstr "Nie ma domy�lnego kalendarza i �adnego nie podano w linii komend.\n"

#: main.cpp:33
msgid "Error reading from default calendar.\n"
msgstr "B��d odczytu z standartowego kalendarza.\n"

#: searchdialog.cpp:22
msgid "Search For:"
msgstr ""

#: searchdialog.cpp:32 topwidget.cpp:494
#, fuzzy
msgid "&Search"
msgstr "&Szukaj..."

#: searchdialog.cpp:81
msgid ""
"Invalid search expression, cannot perform\n"
"the search.  Please enter a search expression\n"
"using the wildcard characters '*' and '?'\n"
"where needed."
msgstr ""

#: topwidget.cpp:391
msgid "&Open"
msgstr ""

#: topwidget.cpp:394
msgid "Open &Recent"
msgstr "Otw�rz o&statni"

#: topwidget.cpp:410
#, fuzzy
msgid "Save &As"
msgstr "Zapisz &jako"

#: topwidget.cpp:415
#, fuzzy
msgid "&Import From Ical"
msgstr "&Import z Ical-a..."

#: topwidget.cpp:417
#, fuzzy
msgid "&Merge Calendar"
msgstr "&Po��czenie kalendarza..."

#: topwidget.cpp:420
#, fuzzy
msgid "Archive Old Entries"
msgstr "Archiwizuj stare dane..."

#: topwidget.cpp:427
#, fuzzy
msgid "Print Setup"
msgstr "Ustawienia drukarki..."

#: calprinter.cpp:844 topwidget.cpp:431
msgid "&Print"
msgstr "&Drukuj"

#: topwidget.cpp:433
#, fuzzy
msgid "Print Pre&view"
msgstr "Podgl�d &wydruku"

#: topwidget.cpp:455
msgid "&List"
msgstr "&Lista"

#: topwidget.cpp:459
msgid "&Day"
msgstr "&Dzie�"

#: topwidget.cpp:462
msgid "W&ork Week"
msgstr "Tydzie� &roboczy"

#: topwidget.cpp:465
msgid "&Week"
msgstr "&Tydzie�"

#: topwidget.cpp:468
msgid "&Month"
msgstr "&Miesi�c"

#: topwidget.cpp:471
#, fuzzy
msgid "&To-do list"
msgstr "Lista &Zada�"

#: topwidget.cpp:479
msgid "New &Appointment"
msgstr "&Nowe spotkanie"

#: topwidget.cpp:481
msgid "New E&vent"
msgstr "Nowe z&darzenie"

#: topwidget.cpp:483
msgid "&Edit Appointment"
msgstr "&Edycja spotkania"

#: topwidget.cpp:486
msgid "&Delete Appointment"
msgstr "&Usuwanie spotkania"

#: topwidget.cpp:488
#, fuzzy
msgid "Delete To-do"
msgstr "Usuwanie zadania"

#: topwidget.cpp:498
#, fuzzy
msgid "&Mail Appointment"
msgstr "Wyslij e-mail o spotkaniu"

#: topwidget.cpp:504
#, fuzzy
msgid "Go to &Today"
msgstr "Przejd� do dzisiaj"

#: topwidget.cpp:508
#, fuzzy
msgid "&Previous Day"
msgstr "Poprzedni rok"

#: topwidget.cpp:512
#, fuzzy
msgid "&Next Day"
msgstr "Nast�pny rok"

#: topwidget.cpp:516
msgid "Show &Tool Bar"
msgstr "Pokazuj &pasek narz�dzi"

#: topwidget.cpp:520
msgid "Show St&atus Bar"
msgstr "Pokazuj p&asek stanu"

#: topwidget.cpp:525
msgid "&Edit Options"
msgstr "&Edycja opcji..."

#: topwidget.cpp:533
msgid "&About"
msgstr "&O programie"

#: topwidget.cpp:535
msgid "Send &Bug Report"
msgstr "Prze�lij raport o &b��dzie"

#: topwidget.cpp:543
msgid "&Actions"
msgstr "&Akcje"

#: topwidget.cpp:562
msgid "Open A Calendar"
msgstr "Otw�rz kalendarz"

#: topwidget.cpp:568
msgid "Save This Calendar"
msgstr "Zapisz ten kalendarz"

#: topwidget.cpp:585
msgid "New Appointment"
msgstr "Nowe spotkanie"

#: topwidget.cpp:591
msgid "Delete Appointment"
msgstr "Skasuj spotkanie"

#: topwidget.cpp:597
msgid "Search For an Appointment"
msgstr "Odszukaj spotkanie"

#: topwidget.cpp:603
msgid "Mail Appointment"
msgstr "Wyslij e-mail o spotkaniu"

#: topwidget.cpp:622
msgid "Go to Today"
msgstr "Przejd� do dzisiaj"

#: topwidget.cpp:628
#, fuzzy
msgid "Previous Day"
msgstr "Poprzedni rok"

#: topwidget.cpp:634
#, fuzzy
msgid "Next Day"
msgstr "Nast�pny rok"

#: topwidget.cpp:650
msgid "List View"
msgstr "Widok listowany"

#: topwidget.cpp:655
msgid "Schedule View"
msgstr "Widok rozk�adu"

#: topwidget.cpp:662
msgid "Month View"
msgstr "Widok miesi�ca"

#: topwidget.cpp:668
#, fuzzy
msgid "To-do list view"
msgstr "Widok listy zada�"

#: topwidget.cpp:750
msgid "we don't handle updates for that view, yet.\n"
msgstr "aktualizacja tego widoku nie dzia�a, jeszcze.\n"

#: topwidget.cpp:842
msgid "we don't handle that view yet.\n"
msgstr "Ten widok jest jeszcze nie dzia�a.\n"

#: topwidget.cpp:960
#, fuzzy
msgid "You did not specify a valid file name."
msgstr "Nie podano prawid�owej nazwy pliku."

#: topwidget.cpp:968
msgid ""
"The file you specified is a directory,\n"
"and cannot be opened. Please try again,\n"
"this time selecting a valid calendar file."
msgstr ""

#: topwidget.cpp:995
msgid "KOrganizer Warning"
msgstr "Ostrze�enie KOrganizer-a"

#: topwidget.cpp:996
#, fuzzy
msgid ""
"This calendar has been modified.\n"
"Would you like to save it?"
msgstr ""
"Kalendarz kt�ry zamykasz zosta� zmodyfikowany.\n"
"Czy chcesz zapisa� zmiany?"

#: topwidget.cpp:998
msgid "&Yes"
msgstr ""

#: topwidget.cpp:998
msgid "&No"
msgstr ""

#: topwidget.cpp:1007 topwidget.cpp:1597
msgid "KOrganizer Confirmation"
msgstr "Potwierdzenie KOrganizer"

#: topwidget.cpp:1008
msgid "This item will be permanently deleted."
msgstr ""

#: topwidget.cpp:1111
msgid ""
"You have no ical file in your home directory.\n"
"Import cannot proceed.\n"
msgstr ""
"Nie masz �adnego pliku ical-a w domowym katalogu.\n"
"Import nie mo�e nast�pi�.\n"

#: topwidget.cpp:1124
msgid "KOrganizer Info"
msgstr "Informacja KOrganizer-a"

#: topwidget.cpp:1125
msgid ""
"KOrganizer succesfully imported and merged your\n"
".calendar file from ical into the currently\n"
"opened calendar.\n"
msgstr ""
"KOrganizer-owi uda�o si� zaimportowa� i po��czy�\n"
"plik .calendar z ical-a do aktualnie otwartego\n"
"kalendarza.\n"

#: topwidget.cpp:1130
msgid "ICal Import Successful With Warning"
msgstr "Import z ICal-a uda� si�, ale z ostrze�eniem"

#: topwidget.cpp:1131
msgid ""
"KOrganizer encountered some unknown fields while\n"
"parsing your .calendar ical file, and had to\n"
"discard them.  Please check to see that all\n"
"your relevant data was correctly imported.\n"
msgstr ""
"Korganizer napotka� jakie� nieznane pola przy\n"
"analizie pliku .calendar ical-a i musia� je\n"
"odrzuci�. Prosz� sprawdzi� czy wszystkie istotne\n"
"dane zosta�y zaimportowane.\n"

#: topwidget.cpp:1137
msgid ""
"KOrganizer encountered some error parsing your\n"
".calendar file from ical.  Import has failed.\n"
msgstr ""
"Wyst�pi� b��d przy analizie pliku .calendar z ical-a\n"
"przez KOrganzier-a. Import nie powi�d� si�.\n"

#: topwidget.cpp:1141
msgid ""
"KOrganizer doesn't think that your .calendar\n"
"file is a valid ical calendar. Import has failed.\n"
msgstr ""
"Wg KOrganizer-a ten plik .calendar nie\n"
"jest prawid�owym kalendarzem ical-a. Import nie powi�d� si�.\n"

#: topwidget.cpp:1305 topwidget.cpp:1332 topwidget.cpp:1683 topwidget.cpp:1693
msgid "KOrganizer error"
msgstr "B�ad KOrganizer-a"

#: topwidget.cpp:1306 topwidget.cpp:1333
msgid ""
"Unfortunately, we don't handle cut/paste for\n"
"that view yet.\n"
msgstr ""
"Niestety brak obs�ugi wycinania/wklejania dla\n"
"tego widoku jeszcze.\n"

#: topwidget.cpp:1549
msgid "don't handle deletes from that view, yet.\n"
msgstr "brak obs�ugi kasowania w tym widoku, jeszcze.\n"

#: topwidget.cpp:1598
#, fuzzy
msgid ""
"This event recurs over multiple dates.\n"
"Are you sure you want to delete the\n"
"selected event, or just this instance?\n"
msgstr ""
"To zdarzenie powtarza si� wielokrotnie.\n"
"Czy jeste� pewien, �e chcesz skasowa� to\n"
"zdarzenie, czy tylko to wyst�pienie?\n"

#: topwidget.cpp:1601
msgid "&All"
msgstr "&Wszystkie"

#: topwidget.cpp:1601
msgid "&This"
msgstr "&Tylko to"

#: topwidget.cpp:1616
msgid "no date selected, or invalid date\n"
msgstr "nie wybrano daty, lub data nieprawid�owa\n"

#: topwidget.cpp:1684
msgid "Can't generate mail from this view\n"
msgstr "Nie mo�na utworzy� wiadomo�ci z tego widoku\n"

#: topwidget.cpp:1694
msgid ""
"Can't generate mail:\n"
" No attendees defined!\n"
msgstr ""
"Nie mo�na utworzy� wiadomo�ci:\n"
" Nie zdefiniowano uczestnik�w!\n"

#: topwidget.cpp:1833
#, fuzzy
msgid "New Calendar"
msgstr "Otw�rz kalendarz"

#: eventwin.cpp:313 eventwin.cpp:319 topwidget.cpp:1839
msgid "modified"
msgstr ""

#: eventwin.cpp:325 topwidget.cpp:1844
#, fuzzy
msgid "KOrganizer"
msgstr "Organizator"

#: calprinter.cpp:47
msgid "Korganizer Configuration Options"
msgstr "Opcje konfiguracyjne KOrganizera"

#: calprinter.cpp:361 todowingeneral.cpp:60
msgid "Priority"
msgstr "Priorytet"

#: calprinter.cpp:369
msgid "Due"
msgstr "W"

#: calprinter.cpp:453
#, c-format
msgid "To-Do items: %s %.2d"
msgstr "Zadania: %s %.2d"

#: calprinter.cpp:791
msgid "Date Range"
msgstr "W okresie"

#: calprinter.cpp:811
msgid "View Type"
msgstr "Typ widoku"

#: calprinter.cpp:816
msgid "Day"
msgstr "Dzie�"

#: calprinter.cpp:821
msgid "Week"
msgstr "Tydzie�"

#: calprinter.cpp:825
msgid "Month"
msgstr "Miesi�c"

#: calprinter.cpp:829
msgid "To-Do"
msgstr "Zadanie"

#: calprinter.cpp:843
msgid "&Preview"
msgstr "&Podgl�d"

#: koarchivedlg.cpp:19
msgid "Archive / Delete Past Appointments - KOrganizer"
msgstr "Archiwizuj / Skasuj dawne spotkania - KOrganizer"

#: optionsdlg.cpp:37
msgid "Time & Date"
msgstr "Czas i Data"

#: optionsdlg.cpp:43
msgid "Colors"
msgstr "Kolory"

#: optionsdlg.cpp:46
msgid "Views"
msgstr "Widoki"

#: optionsdlg.cpp:52
msgid "Printing"
msgstr "Drukowanie"

#: optionsdlg.cpp:65
#, fuzzy
msgid "KOrganizer Configuration"
msgstr "Potwierdzenie KOrganizer"

#: optionsdlg.cpp:92
msgid "Your name:"
msgstr "Imi� i nazwisko:"

#: optionsdlg.cpp:96
msgid "Email address:"
msgstr "Adres e-mail:"

#: optionsdlg.cpp:100
msgid "Additional:"
msgstr "Dodatkowe:"

#: optionsdlg.cpp:104
msgid "Auto-save Calendar"
msgstr "Automatyczny zapis kalendarza"

#: optionsdlg.cpp:108
msgid "Confirm Appointment/To-Do Deletes"
msgstr "Potwierd� skasowanie spotkania/zadania"

#: optionsdlg.cpp:112
msgid "Holidays:"
msgstr "Dni wolne:"

#: optionsdlg.cpp:138
msgid "1 minute"
msgstr ""

#: optionsdlg.cpp:138
msgid "5 minutes"
msgstr ""

#: optionsdlg.cpp:139
msgid "10 minutes"
msgstr ""

#: optionsdlg.cpp:139
msgid "15 minutes"
msgstr ""

#: optionsdlg.cpp:140
msgid "30 minutes"
msgstr ""

#: optionsdlg.cpp:147
msgid "Time Format:"
msgstr "Format czasu:"

#: optionsdlg.cpp:148
msgid "24 hour"
msgstr ""

#: optionsdlg.cpp:149
msgid "AM / PM"
msgstr ""

#: optionsdlg.cpp:153
msgid "Date Format:"
msgstr "Format daty:"

#: optionsdlg.cpp:154
msgid "Day.Month.Year (31.01.2000)"
msgstr "Dzie�.Miesi�c.Rok (31.01.2000)"

#: optionsdlg.cpp:155
msgid "Month/Day/Year (01/31/2000)"
msgstr "Miesi�c/Dzie�/Rok (01/31/2000)"

#: optionsdlg.cpp:156
msgid "Month-Day-Year (01-31-2000)"
msgstr "Miesi�c-Dzie�-Rok (01-31-2000)"

#: optionsdlg.cpp:160
msgid "Time Zone:"
msgstr "Strefa czasowa:"

#: optionsdlg.cpp:167
msgid "Default Appointment Time:"
msgstr "Domy�lny czas spotkania"

#: optionsdlg.cpp:177
msgid "Default Alarm Time:"
msgstr "Domy�lny czas alarmu:"

#: optionsdlg.cpp:185
msgid "Week Starts on Monday"
msgstr "Tydzie� zaczyna si� w poniedzia�ek"

#: optionsdlg.cpp:202
msgid "Day Begins At:"
msgstr "Dzie� zaczyna si� o:"

#: optionsdlg.cpp:212
msgid "Hour size in schedule view"
msgstr ""

#: optionsdlg.cpp:216
msgid "Show events that recur daily in Date Navigator"
msgstr "Poka� wydarzenia powtarzaj�ce si� codziennie w Date Navigator"

#: optionsdlg.cpp:228
#, fuzzy
msgid "List view font"
msgstr "Widok listowany"

#: optionsdlg.cpp:234
#, fuzzy
msgid "Schedule view font"
msgstr "Widok rozk�adu"

#: optionsdlg.cpp:240
#, fuzzy
msgid "Month view font"
msgstr "Widok miesi�ca"

#: optionsdlg.cpp:245
msgid "12345"
msgstr ""

#: optionsdlg.cpp:245
#, fuzzy
msgid "Time bar font"
msgstr "Strefa czasowa:"

#: optionsdlg.cpp:250
msgid "Things to do"
msgstr "Do zrobienia"

#: optionsdlg.cpp:251
#, fuzzy
msgid "To-Do list font"
msgstr "Lista &Zada�"

#: optionsdlg.cpp:272
msgid "Use system default colors"
msgstr "U�yj domy�lnych kolor�w systemowych"

#: optionsdlg.cpp:277
#, fuzzy
msgid "Appointment & Checklist items"
msgstr "Czas spotkania"

#: optionsdlg.cpp:278
msgid "Background"
msgstr "T�o"

#: optionsdlg.cpp:281
msgid "Text"
msgstr "Tekst"

#: optionsdlg.cpp:284
msgid "Handle Selected"
msgstr "Uchwyt wybranego"

#: optionsdlg.cpp:287
msgid "Handle Unselected"
msgstr "Uchwyt pozosta�ych"

#: optionsdlg.cpp:290
msgid "Handle Active Apt."
msgstr "Uchwyt aktywnego spot."

#: optionsdlg.cpp:295
msgid "Sheet background"
msgstr "T�o arkusza"

#: optionsdlg.cpp:298
msgid "Calendar Background"
msgstr "T�o kalendarza"

#: optionsdlg.cpp:301
msgid "Calendar Date Text"
msgstr "Data w kalendarzu"

#: optionsdlg.cpp:304
msgid "Calendar Date Selected"
msgstr "Wybrana data w kalendarzu"

#: optionsdlg.cpp:343
msgid "Printer Name"
msgstr "Nazwa drukarki"

#: optionsdlg.cpp:373
msgid "Paper Size"
msgstr "Rozmiar papieru"

#: optionsdlg.cpp:375
msgid "A4"
msgstr "A4"

#: optionsdlg.cpp:376
msgid "B5"
msgstr "B5"

#: optionsdlg.cpp:377
msgid "Letter"
msgstr "Letter"

#: optionsdlg.cpp:378
msgid "Legal"
msgstr "Legal"

#: optionsdlg.cpp:379
msgid "Executive"
msgstr "Executive"

#: optionsdlg.cpp:383
msgid "Paper Orientation"
msgstr "Orientacja papieru"

#: optionsdlg.cpp:385
msgid "Portrait"
msgstr "Portret"

#: optionsdlg.cpp:387
msgid "Landscape"
msgstr "Pejza�"

#: optionsdlg.cpp:394
msgid "Preview Program"
msgstr "Program do podgl�du"

#: kpropdlg.cpp:124
msgid "Prev"
msgstr "Poprzedni"

#: kpropdlg.cpp:125
msgid "Next"
msgstr "Nast�pny"

#: aboutdlg.cpp:20
#, fuzzy
msgid "KOrganizer Virtual Postcard"
msgstr "B��d KOrganizer-a"

#: aboutdlg.cpp:24
msgid ""
"Please send a postcard to me, so I can see who is\n"
"using KOrganizer! Tell me how great the program is,\n"
"and how you just can't live without it.  Or, report\n"
"a bug which is stopping you from doing useful work.\n"
"The postcard will simply include anything you wish to\n"
"type in the comment area below.\n"
msgstr ""
"Prosz� wy�lij mi poczt�wk�, bym wiedzia� kto\n"
"u�ywa KOrganizer-a! Powiedz mi jak bardzo ten program ci\n"
"si� podoba i �e nie mo�esz bez niego �y�. Lub zg�o�\n"
"bug, kt�ry nie pozwala ci efektywnie pracowa�.\n"
"Ta poczt�wka b�dzie zawiera� to co chcesz i wpiszesz\n"
"w obszar komentarza poni�ej.\n"

#: aboutdlg.cpp:104
msgid "About KOrganizer"
msgstr "O Korganizer-ze"

#: aboutdlg.cpp:137
msgid "by Preston Brown and"
msgstr ""

#: aboutdlg.cpp:156
msgid "License Agreement:"
msgstr ""

#: aboutdlg.cpp:162
msgid ""
"\n"
"\n"
"This program is free software; you can redistribute it and/or modify\n"
"it under the terms of the GNU General Public License as published by\n"
"the Free Software Foundation; either version 2 of the License, or\n"
"(at your option) any later version.\n"
"\n"
"This program is distributed in the hope that it will be useful,\n"
"but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
"GNU General Public License for more details.\n"
"\n"
"You should have received a copy of the GNU General Public License\n"
"along with this program; if not, write to the Free Software\n"
"Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.\n"
msgstr ""
"\n"
"\n"
"This program is free software; you can redistribute it and/or modify\n"
"it under the terms of the GNU General Public License as published by\n"
"the Free Software Foundation; either version 2 of the License, or\n"
"(at your option) any later version.\n"
"\n"
"This program is distributed in the hope that it will be useful,\n"
"but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
"GNU General Public License for more details.\n"
"\n"
"You should have received a copy of the GNU General Public License\n"
"along with this program; if not, write to the Free Software\n"
"Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.\n"

#: aboutdlg.cpp:197
#, fuzzy
msgid "&Send Postcard"
msgstr "Wy�lij poczt�wk�"

#: aboutdlg.cpp:233
msgid "many more, thank you!"
msgstr "wiele innych, dzi�kuj�!"

#: aboutdlg.cpp:255
msgid "Could not load movie"
msgstr ""

#: kotodoview.cpp:27
msgid "To-Do Items"
msgstr "Zadania"

#: kotodoview.cpp:91 kotodoview.cpp:99
msgid "New To-Do"
msgstr "Nowe zadanie"

#: kotodoview.cpp:94
msgid "Purge Completed "
msgstr "Usu� zako�czone "

#: kotodoview.cpp:101
msgid "Edit To-Do"
msgstr "Edycja zadania"

#: kotodoview.cpp:104
msgid "Delete To-Do"
msgstr "Usu� zadanie"

#: kotodoview.cpp:106
#, fuzzy
msgid "Purge Completed"
msgstr "Usu� zako�czone "

#: kotodoview.cpp:108
#, fuzzy
msgid "Sort by Priority"
msgstr "Priorytet"

#: eventwin.cpp:91
msgid "Save and Close"
msgstr "Zapisz i zamknij"

#: eventwin.cpp:111
msgid "Previous Event"
msgstr "Poprzednie zdarzenie"

#: eventwin.cpp:117
msgid "Next Event"
msgstr "Nast�pne zdarzenie"

#: eventwin.cpp:128
msgid "Delete Event"
msgstr "Skasuj zdarzenie"

#: eventwin.cpp:286
msgid "New"
msgstr ""

#: eventwin.cpp:293
#, fuzzy
msgid "Todo"
msgstr "Zadanie"

#: eventwin.cpp:309
msgid "readonly"
msgstr ""

#: todowingeneral.cpp:41
msgid "% Completed"
msgstr "Procentowe zaawansowanie"

#: todowingeneral.cpp:48
#, c-format
msgid "0 %"
msgstr "0 %"

#: todowingeneral.cpp:49
#, c-format
msgid "25 %"
msgstr "25 %"

#: todowingeneral.cpp:50
#, c-format
msgid "50 %"
msgstr "50 %"

#: todowingeneral.cpp:51
#, c-format
msgid "75 %"
msgstr "75 %"

#: todowingeneral.cpp:67
msgid "1 (Highest)"
msgstr "1 (Najwy�szy)"

#: todowingeneral.cpp:68
msgid "2"
msgstr "2"

#: todowingeneral.cpp:69
msgid "3"
msgstr "3"

#: todowingeneral.cpp:70
msgid "4"
msgstr "4"

#: todowingeneral.cpp:71
msgid "5 (lowest)"
msgstr "5 (najni�szy)"

#: alarmdaemon.cpp:39 alarmdaemon.cpp:44
msgid "Can't load docking tray icon!"
msgstr ""

#: alarmdaemon.cpp:48
msgid "Alarms Enabled"
msgstr ""

#: alarmdaemon.cpp:51
#, fuzzy
msgid "Exit Applet"
msgstr "&Edycja spotkania"

#: alarmdaemon.cpp:54
#, fuzzy
msgid "KOrganizer Control Applet"
msgstr "Potwierdzenie KOrganizer"

#: alarmdaemon.cpp:156
#, fuzzy, c-format
msgid "KOrganizer Alarm: %s\n"
msgstr "Kategorie KOrganizer-a"

#: alarmdaemon.cpp:157
msgid ""
"The following events triggered alarms:\n"
"\n"
msgstr ""

#~ msgid "New Appointment - KOrganizer"
#~ msgstr "Nowe spotkanie - KOrganizer"

#~ msgid "Edit Todo - KOrganizer (Readonly)"
#~ msgstr "Edycja zadania - KOrganizer (Tylko do odczytu)"

#~ msgid "Edit Appointment - KOrganizer (Readonly)"
#~ msgstr "Edycja spotkania - KOrganizer(Tylko do odczytu)"

#~ msgid "Edit Todo - KOrganizer"
#~ msgstr "Edycja Zada�"

#~ msgid "Edit Appointment - KOrganizer"
#~ msgstr "Edycja spotkania - KOrganizer"

#~ msgid "&Mail Appointment..."
#~ msgstr "Wy�lij e-&mail o spotkaniu"

#~ msgid "Previous"
#~ msgstr "Poprzedni"

#~ msgid "Modified Calendar Warning"
#~ msgstr "Ostrze�enie o zmianie kalendarza"

#~ msgid ""
#~ "You are opening a new calendar, but the currentone has been modified.\n"
#~ "Are you sure you want todo this? All changes will be lost!\n"
#~ "\n"
#~ msgstr ""
#~ "Otwierasz nowy kalendarz, ale bie��cy zosta� zmieniony.\n"
#~ "Czy jeste� pewien, �e chcesz tego? Wszystkie zmiany zostan� stracone!\n"
#~ "\n"

#~ msgid "KOrganizer had a problem opening your file:\n"
#~ msgstr "KOrganizer mia� problem z otwarciem Twego pliku:\n"

#~ msgid ""
#~ "Please check that the directory and/or file exists,\n"
#~ "that you have permissions to read it, and try again."
#~ msgstr ""
#~ "Prosz� sprawdzi� czy ten plik i/lub plik istnieje,\n"
#~ "czy masz prawo do odczytu i spr�bowa� znowu."

#~ msgid "KOrganizer Modified Calendar Warning"
#~ msgstr "Ostrze�enie KOrganizer-a Zmodyfikowany Kalendarz"

#~ msgid ""
#~ "You are opening a new calendar, but the current one has been modified.\n"
#~ "Are you sure you want to do this? All changes will be lost!\n"
#~ "\n"
#~ msgstr ""
#~ "Otwierasz nowy kalendarz, ale bie��cy zosta� zmieniony.\n"
#~ "Czy jeste� pewien, �e chcesz tego? Wszystkie zmiany zostan� stracone!\n"
#~ "\n"

#~ msgid "KOrganizer had a problem saving your file:\n"
#~ msgstr "KOrganizer mia� problem z zapisem twego pliku:\n"

#~ msgid ""
#~ "Please check that the directory exists and you have\n"
#~ "permission to write to it, and try again."
#~ msgstr ""
#~ "Prosz� sprawdzi� czy ten plik i/lub plik istnieje,\n"
#~ "czy masz prawo do zapisu i spr�bowa� znowu."

#~ msgid "&Don't Save"
#~ msgstr "&Nie zapisuj"

#~ msgid ""
#~ "Are you sure you want to delete\n"
#~ "the selected to do item?\n"
#~ "\n"
#~ msgstr ""
#~ "Czy jeste� pewny, �e chcesz skasowa�\n"
#~ "wybrane zadanie do zrobienia?\n"
#~ "\n"

#~ msgid ""
#~ "Are you sure you want to delete\n"
#~ "the selected event?\n"
#~ "\n"
#~ msgstr ""
#~ "Czy jeste� pewny, �e chcesz skasowa�\n"
#~ "wybrane zdarzenie?\n"
#~ "\n"

#~ msgid "%s%s- KOrganizer"
#~ msgstr "%s%s- KOrganizer"

#~ msgid "New Calendar%s- KOrganizer"
#~ msgstr "Nowy kalendarz%- KOrganizer"

#~ msgid "%s - KOrganizer"
#~ msgstr "%s - KOrganizer"

#~ msgid "New Calendar - KOrganizer"
#~ msgstr "Nowy kalendarz - KOrganizer"

#~ msgid "Test"
#~ msgstr "Test"

#~ msgid "Category Dialog"
#~ msgstr "Okno kategorii"

#~ msgid "Attendee Name"
#~ msgstr "Imi� i nazwisko uczestnika"

#~ msgid "Low"
#~ msgstr "Niski"

#~ msgid "Resources..."
#~ msgstr "Zasoby..."

#~ msgid "Day/Month/Year"
#~ msgstr "Dzie�/Miesi�c/Rok"

#~ msgid "Year/Month/Day"
#~ msgstr "Rok/Miesi�c/Dzie�"

#~ msgid "Pri"
#~ msgstr "Pri"

#~ msgid "Todo Descrip."
#~ msgstr "Opis Zada�"

#~ msgid "Not implemented yet."
#~ msgstr "Jeszcze nie zaimplementowane"

#~ msgid "Not Implemented Yet"
#~ msgstr "Jeszcze nie zaimplementowane"

#~ msgid "Location:"
#~ msgstr "Miejsce"

#~ msgid "Transparency:"
#~ msgstr "Prze�roczysto��:"

#~ msgid "Day view"
#~ msgstr "Widok dnia"

#~ msgid "Work week view"
#~ msgstr "Widok dni roboczych"

#~ msgid "Week view"
#~ msgstr "Widok tygodniowy"

#~ msgid "List of dates"
#~ msgstr "Lista dat"

#~ msgid "Help &On"
#~ msgstr "Pomoc na &temat"

#~ msgid "Today"
#~ msgstr "Dzisiaj"

#~ msgid "Holidays"
#~ msgstr "Dni wolne:"

#~ msgid "KOrganizer v"
#~ msgstr "KOrganizer v"

#~ msgid "M"
#~ msgstr "P"

#~ msgid "T"
#~ msgstr "W"

#~ msgid "W"
#~ msgstr "�"

#~ msgid "F"
#~ msgstr "P"

#~ msgid "S"
#~ msgstr "S"
