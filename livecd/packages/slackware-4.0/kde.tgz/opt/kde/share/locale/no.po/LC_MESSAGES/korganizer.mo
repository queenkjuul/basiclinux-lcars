# Norwegian translations for KDE Organizer
# Copyright (C) 1998 Free Software Foundation, Inc.
# Hans Petter Bieker <zerium@webindex.no>, 1998.
#
msgid ""
msgstr ""
"Project-Id-Version: KORGANIZER\n"
"POT-Creation-Date: 1999-02-04 03:16+0100\n"
"PO-Revision-Date: Sat Nov 7 1998 02:06:58+0200\n"
"Last-Translator: Hans Petter Bieker <zerium@webindex.no>\n"
"Language-Team: no <LL@li.org>\n"
"MIME-Version: 1.0\n"
"Content-Type: text/plain; charset=ISO_8859-1\n"
"Content-Transfer-Encoding: 8bit\n"

#: calobject.cpp:370 calobject.cpp:383 eventwindetails.cpp:338
#: eventwindetails.cpp:358 topwidget.cpp:939 topwidget.cpp:996
#: topwidget.cpp:1044 topwidget.cpp:1106 topwidget.cpp:1123 topwidget.cpp:1149
#: topwidget.cpp:1153 topwidget.cpp:1201 topwidget.cpp:1261 topwidget.cpp:1366
msgid "KOrganizer Error"
msgstr "KOrganizer-feil"

#: calobject.cpp:371 calobject.cpp:384
msgid ""
"An error has occurred parsing the contents of the clipboard.\n"
"You can only paste a valid vCalendar into KOrganizer.\n"
msgstr ""
"Feil ved innliming fra klippebordet.\n"
"Bare gyldig vCalendar data kan limes inn i KOrganizer.\n"

#: calobject.cpp:422
msgid "found a VEvent with no DTSTART/DTEND! Skipping...\n"
msgstr "fant en VEvent uten DTSTART/DTEND\n"

#: catdlg.cpp:19
msgid "KOrganizer Categories"
msgstr "KOrganizer-kategorier"

#: catdlg.cpp:30
msgid "Available Categories"
msgstr "Tilgjenglige kategorier"

#: catdlg.cpp:36 optionsdlg.cpp:222 optionsdlg.cpp:228 optionsdlg.cpp:234
msgid "Appointment"
msgstr "Avtale"

#: catdlg.cpp:37
msgid "Business"
msgstr "Forretning"

#: catdlg.cpp:38
msgid "Meeting"
msgstr "M�te"

#: catdlg.cpp:39
msgid "Phone Call"
msgstr "Telefonsamtale"

#: catdlg.cpp:40
msgid "Education"
msgstr "Oppl�ring"

#: catdlg.cpp:41
msgid "Holiday"
msgstr "Fridag"

#: catdlg.cpp:42
msgid "Vacation"
msgstr "Ferie"

#: catdlg.cpp:43
msgid "Special Occasion"
msgstr "Spesiell hendelse"

#: catdlg.cpp:44 optionsdlg.cpp:34
msgid "Personal"
msgstr "Personlig"

#: catdlg.cpp:45
msgid "Travel"
msgstr "Reise"

#: catdlg.cpp:55
msgid "&Add >>"
msgstr "&Legg til >>"

#: catdlg.cpp:57
msgid "<< &Remove"
msgstr "<< &Fjern"

#: catdlg.cpp:66
msgid "Selected Categories"
msgstr "Velg kategorier"

#: editeventwin.cpp:49
msgid "New Appointment - KOrganizer"
msgstr "Ny avtale - KOrganizer"

#: editeventwin.cpp:72
msgid "Edit Todo - KOrganizer (Readonly)"
msgstr "Rediger gj�rem�l - KOrganizer (Skrivebeskyttet)"

#: editeventwin.cpp:74
msgid "Edit Appointment - KOrganizer (Readonly)"
msgstr "Rediger avtale - KOrganizer (Skrivebeskyttet)"

#: editeventwin.cpp:78
msgid "Edit Todo - KOrganizer"
msgstr "Rediger gj�rem�l - KOrganizer"

#: editeventwin.cpp:80
msgid "Edit Appointment - KOrganizer"
msgstr "Rediger avtale- KOrganizer"

#: editeventwin.cpp:117
msgid "General"
msgstr "Generelt"

#: editeventwin.cpp:118
msgid "Details"
msgstr "Detaljer"

#: editeventwin.cpp:121
msgid "Recurrence"
msgstr "Gjentakelser"

#: editeventwin.cpp:196
msgid "Save and Close"
msgstr "Lagre og Lukk"

#: editeventwin.cpp:215
msgid "Previous Event"
msgstr "Forrige hendelse"

#: editeventwin.cpp:221
msgid "Next Event"
msgstr "Neste hendelse"

#: editeventwin.cpp:231
msgid "Delete Event"
msgstr "Slett hendelse"

#: editeventwin.cpp:259 editeventwin.cpp:522
#, c-format
msgid "Owner: %s"
msgstr "Eier: %s"

#: editeventwin.cpp:1038
msgid "Duration: all day"
msgstr "Varighet: hele dagen"

#: editeventwin.cpp:1046
#, c-format
msgid "Duration: %i hour(s), %i minute(s)"
msgstr "Varighet: %i time(r), %i minutt(er)"

#: editeventwin.cpp:1048
#, c-format
msgid "Duration: %i hour(s)"
msgstr "Varighet: %i time(r)"

#: editeventwin.cpp:1050
#, c-format
msgid "Duration: %i minute(s)"
msgstr "Varighet: %i minutt(er)"

#: eventwidget.cpp:191
msgid "Toggle Alarm"
msgstr "Endre Alarm"

#: eventwindetails.cpp:118 eventwingeneral.cpp:55 eventwingeneral.cpp:70
msgid "Completed"
msgstr "Ferdig"

#: eventwingeneral.cpp:59
msgid "% Completed"
msgstr "% Ferdig"

#: eventwingeneral.cpp:66
#, c-format
msgid "0 %"
msgstr "0 %"

#: eventwingeneral.cpp:67
#, c-format
msgid "25 %"
msgstr "25 %"

#: eventwingeneral.cpp:68
#, c-format
msgid "50 %"
msgstr "50 %"

#: eventwingeneral.cpp:69
#, c-format
msgid "75 %"
msgstr "75 %"

#: calprinter.cpp:361 eventwingeneral.cpp:76
msgid "Priority"
msgstr "Prioritet"

#: eventwingeneral.cpp:83
msgid "1 (Highest)"
msgstr "1 (h�y)"

#: eventwingeneral.cpp:84
msgid "2"
msgstr "2"

#: eventwingeneral.cpp:85
msgid "3"
msgstr "3"

#: eventwingeneral.cpp:86
msgid "4"
msgstr "4"

#: eventwingeneral.cpp:87
msgid "5 (lowest)"
msgstr "5 (lav)"

#: eventwingeneral.cpp:94 eventwinrecur.cpp:28
msgid "Appointment Time"
msgstr "Avtaletidspunkt"

#: eventwingeneral.cpp:99
msgid "Start Time:"
msgstr "Starter:"

#: eventwingeneral.cpp:108
msgid "End Time:"
msgstr "Ferdig:"

#: eventwingeneral.cpp:124
msgid "No time associated"
msgstr "Klokkeslett ikke fastsatt"

#: eventwingeneral.cpp:135
msgid "Recurring event"
msgstr "Gjentagende"

#: eventwingeneral.cpp:143
msgid "Summary:"
msgstr "Beskrivelse:"

#: eventwingeneral.cpp:153
msgid "Show Time As:"
msgstr "Vis tid som:"

#: eventwingeneral.cpp:160
msgid "Busy"
msgstr "Opptatt"

#: eventwingeneral.cpp:161
msgid "Free"
msgstr "Ledig"

#: eventwingeneral.cpp:176
msgid "Owner:"
msgstr "Eier:"

#: eventwingeneral.cpp:182
msgid "Private"
msgstr "Privat"

#: eventwindetails.cpp:199 eventwingeneral.cpp:186
msgid "Categories..."
msgstr "Kategorier..."

#: eventwingeneral.cpp:207
msgid "Reminder:"
msgstr "Alarm:"

#: eventwindetails.cpp:39
msgid "Attendee Information"
msgstr "Kontakt(er)"

#: eventwindetails.cpp:46
msgid "Name"
msgstr "Navn"

#: eventwindetails.cpp:47
msgid "Email"
msgstr "Epost"

#: eventwindetails.cpp:48
msgid "Role"
msgstr "Rolle"

#: eventwindetails.cpp:49
msgid "Status"
msgstr "Status"

#: eventwindetails.cpp:50
msgid "RSVP"
msgstr "RSVP"

#: eventwindetails.cpp:65
msgid "Attendee Name:"
msgstr "Kontaktens navn"

#: eventwindetails.cpp:77
msgid "Email Address:"
msgstr "Epostadresse:"

#: eventwindetails.cpp:92
msgid "Role:"
msgstr "Rolle:"

#: eventwindetails.cpp:98
msgid "Attendee"
msgstr "Kontakt"

#: eventwindetails.cpp:99
msgid "Organizer"
msgstr "Organisator"

#: eventwindetails.cpp:100
msgid "Owner"
msgstr "Eier"

#: eventwindetails.cpp:101
msgid "Delegate"
msgstr "Leder"

#: eventwindetails.cpp:106
msgid "Status:"
msgstr "Status:"

#: eventwindetails.cpp:112
msgid "Needs Action"
msgstr "M� kontaktes"

#: eventwindetails.cpp:113
msgid "Accepted"
msgstr "Akseptert"

#: eventwindetails.cpp:114
msgid "Sent"
msgstr "Sendt"

#: eventwindetails.cpp:115
msgid "Tentative"
msgstr "Midlertidig"

#: eventwindetails.cpp:116
msgid "Confirmed"
msgstr "Bekreftet"

#: eventwindetails.cpp:117
msgid "Declined"
msgstr "Avsl�tt"

#: eventwindetails.cpp:119
msgid "Delegated"
msgstr "Delegert"

#: eventwindetails.cpp:126
msgid "Request Response"
msgstr "Foresp�r svar"

#: eventwindetails.cpp:132
msgid "&Add"
msgstr "&Legg til"

#: eventwindetails.cpp:136
msgid "Address &Book..."
msgstr "Adresse&bok..."

#: eventwindetails.cpp:163
msgid "Attach..."
msgstr "Vedlegg..."

#: eventwindetails.cpp:183
msgid "Save As..."
msgstr "Lagre som..."

#: eventwindetails.cpp:218
msgid "Priority:"
msgstr "Prioritet:"

#: eventwindetails.cpp:224
msgid "Low (1)"
msgstr "Lav (1)"

#: eventwindetails.cpp:225
msgid "Normal (2)"
msgstr "Normal (2)"

#: eventwindetails.cpp:226
msgid "High (3)"
msgstr "H�y (3)"

#: eventwindetails.cpp:227
msgid "Maximum (4)"
msgstr "Maksimum (4)"

#: eventwindetails.cpp:339
msgid "Unable to open address book."
msgstr "Kunne ikke �pne adressebok."

#: eventwindetails.cpp:359
msgid "Error getting entry from address book."
msgstr "Feil under henting av oppf�ring fra adressebok."

#: eventwinrecur.cpp:30
msgid "Start:  "
msgstr "Start:  "

#: eventwinrecur.cpp:31
msgid "End:  "
msgstr "Slutt:  "

#: eventwinrecur.cpp:61
msgid "Recurrence Rule"
msgstr "Gjentakelsesregel"

#: eventwinrecur.cpp:67
msgid "Daily"
msgstr "Daglig"

#: eventwinrecur.cpp:68
msgid "Weekly"
msgstr "Ukentlig"

#: eventwinrecur.cpp:69
msgid "Monthly"
msgstr "M�ndlig"

#: eventwinrecur.cpp:70
msgid "Yearly"
msgstr "�rlig"

#: eventwinrecur.cpp:95
msgid "Enable Advanced Rule:"
msgstr "Aktiviser avansert regel:"

#: eventwinrecur.cpp:128
msgid "Recurrence Range"
msgstr "Gjentakelsestidsrom"

#: eventwinrecur.cpp:132
msgid "Begin On:"
msgstr "Begynn:"

#: eventwinrecur.cpp:134
msgid "No Ending Date"
msgstr "Ingen sluttdato"

#: eventwinrecur.cpp:135
msgid "End after"
msgstr "Avslutt etter"

#: eventwinrecur.cpp:137
msgid "occurrence(s)"
msgstr "forekomst(er)"

#: eventwinrecur.cpp:138
msgid "End by:"
msgstr "Avslutt innen:"

#: eventwinrecur.cpp:181
msgid "Exceptions"
msgstr "Unntak"

#: eventwinrecur.cpp:267 eventwinrecur.cpp:297
msgid "Recur every"
msgstr "Gjenta hver"

#: eventwinrecur.cpp:273
msgid "day(s)"
msgstr "dag"

#: eventwinrecur.cpp:303
msgid "week(s) on:"
msgstr "uke p�:"

#: eventwinrecur.cpp:305 kagenda.cpp:106
msgid "Sun"
msgstr "S�n"

#: eventwinrecur.cpp:306 kagenda.cpp:105
msgid "Mon"
msgstr "Man"

#: eventwinrecur.cpp:307 kagenda.cpp:105
msgid "Tue"
msgstr "Tir"

#: eventwinrecur.cpp:308 kagenda.cpp:105
msgid "Wed"
msgstr "Ons"

#: eventwinrecur.cpp:309 kagenda.cpp:106
msgid "Thu"
msgstr "Tor"

#: eventwinrecur.cpp:310 kagenda.cpp:106
msgid "Fri"
msgstr "Fre"

#: eventwinrecur.cpp:311 kagenda.cpp:106
msgid "Sat"
msgstr "L�r"

#: eventwinrecur.cpp:361 eventwinrecur.cpp:365
msgid "Recur on the"
msgstr "Gjenta"

#: eventwinrecur.cpp:363
msgid "day"
msgstr "Dag"

#: eventwinrecur.cpp:369 eventwinrecur.cpp:481
msgid "every"
msgstr "hver"

#: eventwinrecur.cpp:371
msgid "month(s)"
msgstr "m�ned"

#: eventwinrecur.cpp:383 eventwinrecur.cpp:424
msgid "1st"
msgstr "1."

#: eventwinrecur.cpp:384 eventwinrecur.cpp:425
msgid "2nd"
msgstr "2."

#: eventwinrecur.cpp:385 eventwinrecur.cpp:426
msgid "3rd"
msgstr "3."

#: eventwinrecur.cpp:386 eventwinrecur.cpp:427
msgid "4th"
msgstr "4."

#: eventwinrecur.cpp:387 eventwinrecur.cpp:428
msgid "5th"
msgstr "5."

#: eventwinrecur.cpp:388
msgid "6th"
msgstr "6."

#: eventwinrecur.cpp:389
msgid "7th"
msgstr "7."

#: eventwinrecur.cpp:390
msgid "8th"
msgstr "8."

#: eventwinrecur.cpp:391
msgid "9th"
msgstr "9."

#: eventwinrecur.cpp:392
msgid "10th"
msgstr "10."

#: eventwinrecur.cpp:393
msgid "11th"
msgstr "11."

#: eventwinrecur.cpp:394
msgid "12th"
msgstr "12."

#: eventwinrecur.cpp:395
msgid "13th"
msgstr "13."

#: eventwinrecur.cpp:396
msgid "14th"
msgstr "14."

#: eventwinrecur.cpp:397
msgid "15th"
msgstr "15."

#: eventwinrecur.cpp:398
msgid "16th"
msgstr "16."

#: eventwinrecur.cpp:399
msgid "17th"
msgstr "17."

#: eventwinrecur.cpp:400
msgid "18th"
msgstr "18."

#: eventwinrecur.cpp:401
msgid "19th"
msgstr "19."

#: eventwinrecur.cpp:402
msgid "20th"
msgstr "20."

#: eventwinrecur.cpp:403
msgid "21st"
msgstr "21."

#: eventwinrecur.cpp:404
msgid "22nd"
msgstr "22."

#: eventwinrecur.cpp:405
msgid "23rd"
msgstr "23."

#: eventwinrecur.cpp:406
msgid "24th"
msgstr "24."

#: eventwinrecur.cpp:407
msgid "25th"
msgstr "25."

#: eventwinrecur.cpp:408
msgid "26th"
msgstr "26."

#: eventwinrecur.cpp:409
msgid "27th"
msgstr "27."

#: eventwinrecur.cpp:410
msgid "28th"
msgstr "28."

#: eventwinrecur.cpp:411
msgid "29th"
msgstr "29."

#: eventwinrecur.cpp:412
msgid "30th"
msgstr "30."

#: eventwinrecur.cpp:413
msgid "31st"
msgstr "31."

#: eventwinrecur.cpp:466
msgid "Recur in the month of"
msgstr "Gjenta i"

#: eventwinrecur.cpp:467
msgid "Recur on this day"
msgstr "Gjenta p� denne dagen"

#: calprinter.cpp:327 calprinter.cpp:429 calprinter.cpp:720
#: eventwinrecur.cpp:469 kdatenav.cpp:68 kdatenav.cpp:258
msgid "January"
msgstr "Januar"

#: calprinter.cpp:327 calprinter.cpp:429 calprinter.cpp:720
#: eventwinrecur.cpp:470 kdatenav.cpp:68 kdatenav.cpp:258
msgid "February"
msgstr "Februar"

#: calprinter.cpp:328 calprinter.cpp:430 calprinter.cpp:721
#: eventwinrecur.cpp:471 kdatenav.cpp:68 kdatenav.cpp:259
msgid "March"
msgstr "Mars"

#: calprinter.cpp:328 calprinter.cpp:430 calprinter.cpp:721
#: eventwinrecur.cpp:472 kdatenav.cpp:69 kdatenav.cpp:259
msgid "April"
msgstr "April"

#: calprinter.cpp:329 calprinter.cpp:431 calprinter.cpp:722
#: eventwinrecur.cpp:473 kdatenav.cpp:69 kdatenav.cpp:260
msgid "May"
msgstr "Mai"

#: calprinter.cpp:329 calprinter.cpp:431 calprinter.cpp:722
#: eventwinrecur.cpp:474 kdatenav.cpp:69 kdatenav.cpp:260
msgid "June"
msgstr "Juni"

#: calprinter.cpp:330 calprinter.cpp:432 calprinter.cpp:723
#: eventwinrecur.cpp:475 kdatenav.cpp:69 kdatenav.cpp:261
msgid "July"
msgstr "Juli"

#: calprinter.cpp:330 calprinter.cpp:432 calprinter.cpp:723
#: eventwinrecur.cpp:476 kdatenav.cpp:70 kdatenav.cpp:261
msgid "August"
msgstr "August"

#: calprinter.cpp:331 calprinter.cpp:433 calprinter.cpp:724
#: eventwinrecur.cpp:477 kdatenav.cpp:70 kdatenav.cpp:262
msgid "September"
msgstr "September"

#: calprinter.cpp:331 calprinter.cpp:433 calprinter.cpp:724
#: eventwinrecur.cpp:478 kdatenav.cpp:70 kdatenav.cpp:262
msgid "October"
msgstr "Oktober"

#: calprinter.cpp:332 calprinter.cpp:434 calprinter.cpp:725
#: eventwinrecur.cpp:479 kdatenav.cpp:71 kdatenav.cpp:263
msgid "November"
msgstr "November"

#: calprinter.cpp:332 calprinter.cpp:434 calprinter.cpp:725
#: eventwinrecur.cpp:480 kdatenav.cpp:71 kdatenav.cpp:263
msgid "December"
msgstr "Desember"

#: eventwinrecur.cpp:484
msgid "year(s)"
msgstr "�r"

#: kagenda.cpp:212
msgid "All Day Event"
msgstr "Hele dagen"

#: kagenda.cpp:801
msgid "New appointment"
msgstr "Ny Avtale"

#: kagenda.cpp:938 kagenda.cpp:946
msgid "am"
msgstr "am"

#: kagenda.cpp:942
msgid "pm"
msgstr "pm"

#: kdatenav.cpp:44
msgid "Previous Year"
msgstr "Forrige �r"

#: kdatenav.cpp:50
msgid "Previous Month"
msgstr "Forrige m�ned"

#: kdatenav.cpp:56
msgid "Next Month"
msgstr "Neste m�ned"

#: kdatenav.cpp:62
msgid "Next Year"
msgstr "Neste �r"

#: kmonthview.cpp:386
msgid "New Event"
msgstr "Ny begivenhet"

#: kpbutton.cpp:23 kpbutton.cpp:41 kpbutton.cpp:91
msgid "KPButton: pixmap is empty, perhaps some missing file"
msgstr "KPButton: bildet finnes ikke, kanskje en fil mangler"

#: baselistview.cpp:28
msgid "Date"
msgstr "Dato"

#: baselistview.cpp:29
msgid "Time"
msgstr "Tid"

#: baselistview.cpp:30 calprinter.cpp:365
msgid "Summary"
msgstr "Beskrivelse"

#: baselistview.cpp:77
msgid "started "
msgstr "startet "

#: baselistview.cpp:80
msgid "ends "
msgstr "avsluttet "

#: baselistview.cpp:85
#, c-format
msgid "repeats %d times"
msgstr "gjentar %. gang"

#: baselistview.cpp:89
msgid "repeats forever"
msgstr "gjentar evig"

#: listview.cpp:14
msgid "Edit Event"
msgstr "Endre begivenhet"

#: listview.cpp:17
msgid "Delete Event  "
msgstr "Slett Avtale"

#: listview.cpp:20
msgid "Show Dates"
msgstr "Vis dato"

#: listview.cpp:22
msgid "Hide Dates"
msgstr "Skjul Dato"

#: main.cpp:30
msgid "No default calendar, and none was specified on the command line.\n"
msgstr "Ingen standardkalendar og heller ingen valgt fra kommandolinjen.\n"

#: main.cpp:34
msgid "Error reading from default calendar.\n"
msgstr "Feil ved lesing fra standardkalendar.\n"

#: todoview.cpp:60 todoview.cpp:68
msgid "New Todo"
msgstr "Nytt gj�rem�l"

#: todoview.cpp:63 todoview.cpp:75
msgid "Purge Completed "
msgstr "Rydding Fullf�rt"

#: todoview.cpp:70
msgid "Edit Todo"
msgstr "Rediger gj�rem�l"

#: topwidget.cpp:383
msgid "Open &Recent"
msgstr "�pne &forrige"

#: topwidget.cpp:399
msgid "Save &As..."
msgstr "Lagre &som"

#: topwidget.cpp:404
msgid "&Import From Ical..."
msgstr "&Importer fra Ical..."

#: topwidget.cpp:406
msgid "&Merge Calendar..."
msgstr "&Kombiner Kalender..."

#: topwidget.cpp:409
msgid "Archive Old Entries..."
msgstr "Arkiver eldre data..."

#: topwidget.cpp:416
msgid "Print Setup..."
msgstr "Skriveroppsett.."

#: topwidget.cpp:422
msgid "Print Pre&view..."
msgstr "Forh�ndsvisning"

#: topwidget.cpp:444
msgid "&List"
msgstr "&Liste"

#: topwidget.cpp:447
msgid "&Day"
msgstr "&Dag:"

#: topwidget.cpp:450
msgid "W&ork Week"
msgstr "A&rbeidsuke"

#: topwidget.cpp:453
msgid "&Week"
msgstr "&Uke"

#: topwidget.cpp:456
msgid "&Month"
msgstr "&M�ned:"

#: topwidget.cpp:459
msgid "&Todo list"
msgstr "&Gj�rem�l"

#: topwidget.cpp:467
msgid "New &Appointment"
msgstr "Ny &Avtale"

#: topwidget.cpp:469
msgid "New E&vent"
msgstr "Ny &Begivenhet"

#: topwidget.cpp:471
msgid "&Edit Appointment"
msgstr "&Endre avtale"

#: topwidget.cpp:474
msgid "&Delete Appointment"
msgstr "&Slett avtale"

#: topwidget.cpp:476
msgid "Delete Todo"
msgstr "Slett gj�rem�l"

#: topwidget.cpp:481
msgid "&Search..."
msgstr "&S�k..."

#: topwidget.cpp:485
msgid "&Mail Appointment..."
msgstr "&Endre avtale..."

#: topwidget.cpp:489
msgid "Show &Tool Bar"
msgstr "Vis v&erkt�ylinje"

#: topwidget.cpp:493
msgid "Show St&atus Bar"
msgstr "Vis st&atuslinje"

#: topwidget.cpp:498
msgid "&Edit Options"
msgstr "Rediger &Innstillinger"

#: topwidget.cpp:506
msgid "&About"
msgstr "&Om"

#: topwidget.cpp:508
msgid "Send &Bug Report"
msgstr "Send &feilrapport"

#: topwidget.cpp:516
msgid "&Actions"
msgstr "&Avtaler"

#: topwidget.cpp:534
msgid "Open A Calendar"
msgstr "�pne en kalender"

#: topwidget.cpp:540
msgid "Save This Calendar"
msgstr "Lagre denne kalenderen"

#: topwidget.cpp:557
msgid "New Appointment"
msgstr "Ny avtale"

#: topwidget.cpp:562
msgid "Delete Appointment"
msgstr "Slett avtale"

#: topwidget.cpp:568
msgid "Search For an Appointment"
msgstr "S�k etter Avtale"

#: topwidget.cpp:574
msgid "Mail Appointment"
msgstr "Send avtale"

#: topwidget.cpp:581
msgid "Go to Today"
msgstr "G� til idag"

#: topwidget.cpp:589
msgid "Previous"
msgstr "Forrige"

#: kpropdlg.cpp:126 topwidget.cpp:595
msgid "Next"
msgstr "Neste"

#: topwidget.cpp:610
msgid "Schedule View"
msgstr "Vis plan"

#: topwidget.cpp:617
msgid "Month View"
msgstr "Vis m�ned"

#: topwidget.cpp:622
msgid "List View"
msgstr "Vis liste"

#: topwidget.cpp:628
msgid "Todo list view"
msgstr "Vis gj�rem�l"

#: topwidget.cpp:711
msgid "we don't handle updates for that view, yet.\n"
msgstr "Kan ikke oppdatere her forl�pig\n"

#: topwidget.cpp:803
msgid "we don't handle that view yet.\n"
msgstr "we don't handle that view yet.\n"

#: topwidget.cpp:897
msgid "Modified Calendar Warning"
msgstr "Modifisert kalender-varsel"

#: topwidget.cpp:898
msgid ""
"You are opening a new calendar, but the currentone has been modified.\n"
"Are you sure you want todo this? All changes will be lost!\n"
"\n"
msgstr ""
"Du �pner en ny kalender, men den gjeldene er endret.\n"
"Hvis du �pner en ny, vil alle endringer forsvinne!\n"

#: topwidget.cpp:934 topwidget.cpp:991 topwidget.cpp:1039 topwidget.cpp:1101
#: topwidget.cpp:1196
msgid "KOrganizer had a problem opening your file:\n"
msgstr "KOrganizer har problemer med � �pne filen din:\n"

#: topwidget.cpp:936 topwidget.cpp:993 topwidget.cpp:1041 topwidget.cpp:1103
#: topwidget.cpp:1198
msgid ""
"Please check that the directory and/or file exists,\n"
"that you have permissions to read it, and try again."
msgstr ""
"Vennligst sjekk at katalogen og/eller filen eksisterer,\n"
"at du har tilgang til � lese den, og pr�v igjen."

#: topwidget.cpp:1005
msgid "KOrganizer Modified Calendar Warning"
msgstr "KOrganizer Modified Calendar Warning"

#: topwidget.cpp:1006
msgid ""
"You are opening a new calendar, but the current one has been modified.\n"
"Are you sure you want to do this? All changes will be lost!\n"
"\n"
msgstr ""
"Du �pner en ny kalender, men den gjeldende har blitt endret.\n"
"Er du sikker p� at du vil gj�re dette? Alle endringer vil g� tapt!\n"

#: topwidget.cpp:1124
msgid ""
"You have no ical file in your home directory.\n"
"Import cannot proceed.\n"
msgstr ""
"Du har ingen ical-fil i ditt hjemmeomr�de.\n"
"\n"
"Import kan ikke kj�res.\n"

#: topwidget.cpp:1137
msgid "KOrganizer Info"
msgstr "KOrganizer-info"

#: topwidget.cpp:1138
msgid ""
"KOrganizer succesfully imported and merged your\n"
".calendar file from ical into the currently\n"
"opened calendar.\n"
msgstr ""
"KOrganizer lyktes med � importere og flette din\n"
".calendar-fil fra ical og inn i den kalenderen\n"
"som n� er �pnet.\n"

#: topwidget.cpp:1143
msgid "ICal Import Successful With Warning"
msgstr "ICal-import lyktes med advarsel"

#: topwidget.cpp:1144
msgid ""
"KOrganizer encountered some unknown fields while\n"
"parsing your .calendar ical file, and had to\n"
"discard them.  Please check to see that all\n"
"your relevant data was correctly imported.\n"
msgstr ""
"KOrganizer st�tet p� noen ukjente felter under\n"
"analysering av din .calendar-fil fra ical, og\n"
"m�tte derfor forkaste dem. Vennlist sjekk at\n"
"all relevant data ble korrekt importert.\n"

#: topwidget.cpp:1150
msgid ""
"KOrganizer encountered some error parsing your\n"
".calendar file from ical.  Import has failed.\n"
msgstr ""
"KOrganizer st�tet p� noen feil under analysering\n"
"av din .calendar-fil fra ical. Import mislyktes.\n"

#: topwidget.cpp:1154
msgid ""
"KOrganizer doesn't think that your .calendar\n"
"file is a valid ical calendar. Import has failed.\n"
msgstr ""
"KOrganizer tror ikke at din .calendar\n"
"-fil er en\n"
"gyldig ical-kalender. Import mislyktes.\n"

#: topwidget.cpp:1256 topwidget.cpp:1361
msgid "KOrganizer had a problem saving your file:\n"
msgstr "KOrganizer har problemer med � lagre filen din:\n"

#: topwidget.cpp:1258 topwidget.cpp:1363
msgid ""
"Please check that the directory exists and you have\n"
"permission to write to it, and try again."
msgstr ""
"Vennligst sjekk at katalogen eksisterer og at du har\n"
"tilgang til � skrive til den, og pr�v igjen."

#: topwidget.cpp:1276
msgid "KOrganizer Warning"
msgstr "KOrganizer-advarsel"

#: topwidget.cpp:1277
msgid ""
"The calendar you are closing has been modified.\n"
"Do you want to save your changes?"
msgstr ""
"Kalenderen du lukker har blitt endret.\n"
"Vil du lagre endringer?"

#: topwidget.cpp:1280
msgid "&Don't Save"
msgstr "&Ikke lagre"

#: topwidget.cpp:1424 topwidget.cpp:1451 topwidget.cpp:1800 topwidget.cpp:1810
msgid "KOrganizer error"
msgstr "KOrganizer-feil"

#: topwidget.cpp:1425 topwidget.cpp:1452
msgid ""
"Unfortunately, we don't handle cut/paste for\n"
"that view yet.\n"
msgstr ""
"Uheldigvis st�tter forel�big ikke denne\n"
"visningen klipp og lim.\n"

#: topwidget.cpp:1659
msgid "don't handle deletes from that view, yet.\n"
msgstr "st�tter forel�big ikke sletting fra denne visningen.\n"

#: topwidget.cpp:1684 topwidget.cpp:1711 topwidget.cpp:1747
msgid "KOrganizer Confirmation"
msgstr "KOrganizer-bekreftelse"

#: topwidget.cpp:1685
msgid ""
"Are you sure you want to delete\n"
"the selected to do item?\n"
"\n"
msgstr ""
"Er du sikker p� at du �nsker �\n"
"slette det valgte gj�rem�let?\n"
"\n"

#: topwidget.cpp:1712
msgid ""
"This event recurs over multiple dates.\n"
"Are you sure you want to delete the\n"
"selected event, or just this instance?\n"
"\n"
msgstr ""
"Denne hendelsen gjentar seg of flere datoer.\n"
"Er du sikker p� at du �nsker � slette valgte\n"
"heldelse, eller bare dette tilfellet?\n"

#: topwidget.cpp:1715
msgid "&All"
msgstr "&Alle"

#: topwidget.cpp:1716
msgid "&This"
msgstr "&Denne"

#: topwidget.cpp:1730
msgid "no date selected, or invalid date\n"
msgstr "ingen dato valgt, eller ugyldig dato\n"

#: topwidget.cpp:1748
msgid ""
"Are you sure you want to delete\n"
"the selected event?\n"
"\n"
msgstr ""
"Er du sikker p� at du �nsker �\n"
"slette den valgte hendelsen?\n"
"\n"

#: topwidget.cpp:1801
msgid "Can't generate mail from this view\n"
msgstr "Kan ikke generere epost fra denne visningen\n"

#: topwidget.cpp:1811
msgid ""
"Can't generate mail:\n"
" No attendees defined!\n"
msgstr ""
"Kan ikke generere epost:\n"
"Ingen kontakter definert!\n"

#: topwidget.cpp:1931
#, c-format
msgid "%s%s- KOrganizer"
msgstr "%s%s- KOrganizer"

#: topwidget.cpp:1936
#, c-format
msgid "New Calendar%s- KOrganizer"
msgstr "Ny kalender %s - KOrganizer"

#: topwidget.cpp:1948
#, c-format
msgid "%s - KOrganizer"
msgstr "%s - KOrganizer"

#: topwidget.cpp:1952
msgid "New Calendar - KOrganizer"
msgstr "Ny kalender - KOrganizer"

#: calprinter.cpp:47
msgid "Korganizer Configuration Options"
msgstr "KOrganizer-konfigurasjonsvalg"

#: calprinter.cpp:369
msgid "Due"
msgstr "Innen"

#: calprinter.cpp:453
#, c-format
msgid "To-Do items: %s %.2d"
msgstr "Gj�rem�l: %s %.2d"

#: calprinter.cpp:791
msgid "Date Range"
msgstr "Dato-omr�de"

#: calprinter.cpp:811
msgid "View Type"
msgstr "Type visning"

#: calprinter.cpp:816
msgid "Day"
msgstr "Dag"

#: calprinter.cpp:821
msgid "Week"
msgstr "Uke"

#: calprinter.cpp:825
msgid "Month"
msgstr "M�ned"

#: calprinter.cpp:829
msgid "To-Do"
msgstr "Gj�rem�l"

#: calprinter.cpp:843
msgid "&Preview"
msgstr "&Forrige"

#: calprinter.cpp:844
msgid "&Print"
msgstr "&Skriver ut"

#: koarchivedlg.cpp:19
msgid "Archive / Delete Past Appointments - KOrganizer"
msgstr "Arkiver / Slett gamle avtaler - KOrganizer"

#: optionsdlg.cpp:37
msgid "Time & Date"
msgstr "Tid og dato"

#: optionsdlg.cpp:43
msgid "Colors"
msgstr "Farger"

#: optionsdlg.cpp:46
msgid "Views"
msgstr "Visninger"

#: optionsdlg.cpp:52
msgid "Printing"
msgstr "Skriver ut"

#: optionsdlg.cpp:89
msgid "Your name:"
msgstr "Ditt navn:"

#: optionsdlg.cpp:93
msgid "Email address:"
msgstr "Epostadresse:"

#: optionsdlg.cpp:97
msgid "Additional:"
msgstr "Tillegg:"

#: optionsdlg.cpp:101
msgid "Auto-save Calendar"
msgstr "Autolagre kalender"

#: optionsdlg.cpp:105
msgid "Confirm Appointment/To-Do Deletes"
msgstr "Begreft sletting av avtalte/gj�rem�l"

#: optionsdlg.cpp:109
msgid "Holidays:"
msgstr "Helligdager:"

#: optionsdlg.cpp:143
msgid "Time Format:"
msgstr "Klokkeformat:"

#: optionsdlg.cpp:149
msgid "Date Format:"
msgstr "Datoformat:"

#: optionsdlg.cpp:150
msgid "Day.Month.Year (31.01.2000)"
msgstr "Dag.M�ned.�r (31.01.2000)"

#: optionsdlg.cpp:151
msgid "Month/Day/Year (01/31/2000)"
msgstr "M�ned/Dag/�r (01/31/2000)"

#: optionsdlg.cpp:152
msgid "Month-Day-Year (01-31-2000)"
msgstr "M�ned-Dag-�r (01-31-2000)"

#: optionsdlg.cpp:156
msgid "Time Zone:"
msgstr "Tidssone:"

#: optionsdlg.cpp:163
msgid "Default Appointment Time:"
msgstr "Standard avtaletid:"

#: optionsdlg.cpp:173
msgid "Default Alarm Time:"
msgstr "Standard alarmtid:"

#: optionsdlg.cpp:181
msgid "Week Starts on Monday"
msgstr "Uken starter p� mandag"

#: optionsdlg.cpp:198
msgid "Day Begins At:"
msgstr "Dag starter kl:"

#: optionsdlg.cpp:211
msgid "Show events that recur daily in Date Navigator"
msgstr "Vis hendelser som forekommer daglig i dato-navigatoren"

#: optionsdlg.cpp:245
msgid "Things to do"
msgstr "Ting som skal gj�res"

#: optionsdlg.cpp:267
msgid "Use system default colors"
msgstr "Bruk fargene fra systemstandarden"

#: optionsdlg.cpp:273
msgid "Background"
msgstr "Bakgrunn"

#: optionsdlg.cpp:276
msgid "Text"
msgstr "Tekst"

#: optionsdlg.cpp:279
msgid "Handle Selected"
msgstr "H�ndtere valgte"

#: optionsdlg.cpp:282
msgid "Handle Unselected"
msgstr "H�ndtere ikkevalgte"

#: optionsdlg.cpp:285
msgid "Handle Active Apt."
msgstr "H�ndtere gjeldende avtale"

#: optionsdlg.cpp:290
msgid "Sheet background"
msgstr "Ark-bakgrunn"

#: optionsdlg.cpp:293
msgid "Calendar Background"
msgstr "Bakgrunn i kalender"

#: optionsdlg.cpp:296
msgid "Calendar Date Text"
msgstr "Datotekst i kalender"

#: optionsdlg.cpp:299
msgid "Calendar Date Selected"
msgstr "Datovalg i kalender"

#: optionsdlg.cpp:332
msgid "Test"
msgstr "Test"

#: optionsdlg.cpp:348
msgid "Printer Name"
msgstr "Skrivernavn"

#: optionsdlg.cpp:378
msgid "Paper Size"
msgstr "Papirst�rrelse"

#: optionsdlg.cpp:380
msgid "A4"
msgstr "A4"

#: optionsdlg.cpp:381
msgid "B5"
msgstr "B5"

#: optionsdlg.cpp:382
msgid "Letter"
msgstr "Letter"

#: optionsdlg.cpp:383
msgid "Legal"
msgstr "Legal"

#: optionsdlg.cpp:384
msgid "Executive"
msgstr "Executive"

#: optionsdlg.cpp:388
msgid "Paper Orientation"
msgstr "Papirorientering"

#: optionsdlg.cpp:390
msgid "Portrait"
msgstr "St�ende"

#: optionsdlg.cpp:392
msgid "Landscape"
msgstr "Liggende"

#: optionsdlg.cpp:399
msgid "Preview Program"
msgstr "Forh�ndsvisningsprogram"

#: kpropdlg.cpp:125
msgid "Prev"
msgstr "Forrige"

#: aboutdlg.cpp:24
msgid ""
"Please send a postcard to me, so I can see who is\n"
"using KOrganizer! Tell me how great the program is,\n"
"and how you just can't live without it.  Or, report\n"
"a bug which is stopping you from doing useful work.\n"
"The postcard will simply include anything you wish to\n"
"type in the comment area below.\n"
msgstr ""
"Send et postkort til meg slik at jeg kan se hvem som\n"
"bruker KOrganizer! Fortell meg hvor flott programmet\n"
"er, og hvorfor du ikke kan leve uten det. Du kan ogs�\n"
"rapportere feil som hindrer deg � gj�re nyttig arbeid.\n"
"Postkortet vil enkelt og greit inneholde alt du �nsker\n"
"� skrive i kommentaromr�det under.\n"

#: aboutdlg.cpp:162
msgid ""
"\n"
"\n"
"This program is free software; you can redistribute it and/or modify\n"
"it under the terms of the GNU General Public License as published by\n"
"the Free Software Foundation; either version 2 of the License, or\n"
"(at your option) any later version.\n"
"\n"
"This program is distributed in the hope that it will be useful,\n"
"but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
"GNU General Public License for more details.\n"
"\n"
"You should have received a copy of the GNU General Public License\n"
"along with this program; if not, write to the Free Software\n"
"Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.\n"
msgstr ""
"\n"
"\n"
"Dette program er fri programvare; du kan distribuere det videre og/eller "
"endre\n"
"det under betingelsene i GNU-lisensen som er publisert av \n"
"Free Software Foundation; enten versjon 2 av lisensen, eller\n"
"(ditt valg) hvilken som helst senere versjon.\n"
"\n"
"Dette program er utgitt i det h�p at det vil v�re nyttig,\n"
"men UTEN NOEN GARANTI, til og med uten den underforst�tte garanti om\n"
"SALGBARHET eller EGNET FOR ET SPESIELT FORMEL.  Se \n"
"GNU-lisensen for flere detaljer.\n"
"\n"
"Du b�r ha mottatt en kopi av GNU-lisensen\n"
"sammen med dette program; hvis ikke, skriv til Free Software\n"
"Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.\n"

#: aboutdlg.cpp:197
msgid "Send Postcard"
msgstr "Send postkort"

#: aboutdlg.cpp:232
msgid "many more, thank you!"
msgstr "mange flere, takk til dere"

#: kotodoview.cpp:25
msgid "To-Do Items"
msgstr "Gj�rem�l"

#: kotodoview.cpp:99 kotodoview.cpp:107
msgid "New To-Do"
msgstr "Nytt gj�rem�l"

#: kotodoview.cpp:102 kotodoview.cpp:114
msgid "Purge Completed "
msgstr "Rydding Fullf�rt"

#: kotodoview.cpp:109
msgid "Edit To-Do"
msgstr "Rediger gj�rem�l"

#: kotodoview.cpp:112
msgid "Delete To-Do"
msgstr "Slett gj�rem�l"
