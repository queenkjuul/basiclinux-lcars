# Icelandic translation of korganizer.
# Copyright (C) 1998 Free Software Foundation, Inc.
# Thorarinn R. Einarsson <thori@mindspring.com>, 1999.
#
msgid ""
msgstr ""
"Project-Id-Version: korganizer\n"
"POT-Creation-Date: 1999-04-20 03:16+0200\n"
"PO-Revision-Date: 1999-02-15 01:09-0500\n"
"Last-Translator: Thorarinn R. Einarsson <thori@mindspring.com>\n"
"Language-Team: is <kde-isl@mmedia.is>\n"
"MIME-Version: 1.0\n"
"Content-Type: text/plain; charset=iso8859-1\n"
"Content-Transfer-Encoding:iso8859-1\n"

#: alarmdaemon.cpp:38 alarmdaemon.cpp:43 calobject.cpp:372 calobject.cpp:385
#: eventwindetails.cpp:341 eventwindetails.cpp:361 searchdialog.cpp:80
#: topwidget.cpp:959 topwidget.cpp:967 topwidget.cpp:1110 topwidget.cpp:1136
#: topwidget.cpp:1140
msgid "KOrganizer Error"
msgstr "KSkipuleggjarinn: Villa"

#: calobject.cpp:373 calobject.cpp:386
msgid ""
"An error has occurred parsing the contents of the clipboard.\n"
"You can only paste a valid vCalendar into KOrganizer.\n"
msgstr ""
"�a� var� villa vi� flutning � innihaldi klemmuspjaldsins.\n"
"�� getur bara flutt r�tt gert vCalendar inn � KSkipuleggjarann.\n"

#: calobject.cpp:434
#, fuzzy
msgid "found a VEvent with no DTSTART/DTEND! Skipping"
msgstr "fann VEvent �n DTSTART/DTEND!  Sleppi �essu...\n"

#: catdlg.cpp:19
msgid "KOrganizer Categories"
msgstr "Flokkar KSkipuleggjarans"

#: catdlg.cpp:30
msgid "Available Categories"
msgstr "Noth�fir flokkar"

#: catdlg.cpp:36 eventwin.cpp:297 optionsdlg.cpp:227 optionsdlg.cpp:233
#: optionsdlg.cpp:239
msgid "Appointment"
msgstr "Stefnum�t"

#: catdlg.cpp:37
msgid "Business"
msgstr "Vi�skipti"

#: catdlg.cpp:38
msgid "Meeting"
msgstr "Fundur"

#: catdlg.cpp:39
msgid "Phone Call"
msgstr "S�mtal"

#: catdlg.cpp:40
msgid "Education"
msgstr "Menntun"

#: catdlg.cpp:41
msgid "Holiday"
msgstr "Fr�dagur"

#: catdlg.cpp:42
msgid "Vacation"
msgstr "FR�"

#: catdlg.cpp:43
msgid "Special Occasion"
msgstr "S�rstakt tilefni"

#: catdlg.cpp:44 optionsdlg.cpp:34
msgid "Personal"
msgstr "Pers�nulegt"

#: catdlg.cpp:45
msgid "Travel"
msgstr "Fer�al�g"

#: catdlg.cpp:55
msgid "&Add >>"
msgstr "&B�ta vi� >>"

#: catdlg.cpp:57
msgid "<< &Remove"
msgstr "<< &Fjarl�gja"

#: catdlg.cpp:66
msgid "Selected Categories"
msgstr "Valdir flokkar"

#: catdlg.cpp:78
msgid "New Category:"
msgstr ""

#: editeventwin.cpp:116 todoeventwin.cpp:108
msgid "General"
msgstr "Almennt"

#: editeventwin.cpp:117 todoeventwin.cpp:109
msgid "Details"
msgstr "Sm�atri�i"

#: editeventwin.cpp:119
msgid "Recurrence"
msgstr "Endurteki�"

#: editeventwin.cpp:195 editeventwin.cpp:406 todoeventwin.cpp:162
#: todoeventwin.cpp:182
#, c-format
msgid "Owner: %s"
msgstr "Eigandi: %s"

#: editeventwin.cpp:810
msgid "Duration: all day"
msgstr "Lengd: allan dag"

#: editeventwin.cpp:818
#, c-format
msgid "Duration: %i hour(s), %i minute(s)"
msgstr "Lengd: %i klst, %i m�n."

#: editeventwin.cpp:820
#, c-format
msgid "Duration: %i hour(s)"
msgstr "Lengd: %i klst"

#: editeventwin.cpp:822
#, c-format
msgid "Duration: %i minute(s)"
msgstr "Lengd: %i m�n."

#: eventwidget.cpp:193
msgid "Toggle Alarm"
msgstr "V�xla vekjaraklukku"

#: eventwingeneral.cpp:42 eventwinrecur.cpp:28 wingeneral.cpp:34
msgid "Appointment Time"
msgstr "T�mi stefnum�ts"

#: eventwingeneral.cpp:47 wingeneral.cpp:39
msgid "Start Time:"
msgstr "Byrjar kl.:"

#: eventwingeneral.cpp:58 wingeneral.cpp:48
msgid "End Time:"
msgstr "Endar kl.:"

#: eventwingeneral.cpp:80 wingeneral.cpp:64
msgid "No time associated"
msgstr "Enginn t�mi valinn"

#: eventwingeneral.cpp:91 wingeneral.cpp:75
msgid "Recurring event"
msgstr "Endurtekinn atbur�ur"

#: eventwingeneral.cpp:99 todowingeneral.cpp:77
msgid "Summary:"
msgstr "Yfirlit:"

#: eventwingeneral.cpp:110
msgid "Show Time As:"
msgstr "S�na t�ma sem:"

#: eventwingeneral.cpp:117
msgid "Busy"
msgstr "Uppteki�"

#: eventwingeneral.cpp:118
msgid "Free"
msgstr "Opi�"

#: eventwingeneral.cpp:133 todowingeneral.cpp:96
msgid "Owner:"
msgstr "Eigandi:"

#: eventwingeneral.cpp:139 todowingeneral.cpp:102
msgid "Private"
msgstr "Einka"

#: eventwindetails.cpp:199 eventwingeneral.cpp:145 todowingeneral.cpp:108
msgid "Categories..."
msgstr "Flokkar..."

#: eventwingeneral.cpp:164
msgid "Reminder:"
msgstr "�minnir:"

#: eventwindetails.cpp:39
msgid "Attendee Information"
msgstr "Uppl. um ��tttakanda"

#: eventwindetails.cpp:46
msgid "Name"
msgstr "Nafn"

#: eventwindetails.cpp:47
msgid "Email"
msgstr "Netfang"

#: eventwindetails.cpp:48
msgid "Role"
msgstr "Hlutverk"

#: eventwindetails.cpp:49
msgid "Status"
msgstr "Sta�a"

#: eventwindetails.cpp:50
msgid "RSVP"
msgstr "Svar"

#: eventwindetails.cpp:65
msgid "Attendee Name:"
msgstr "Nafn ��tttakanda:"

#: eventwindetails.cpp:77
msgid "Email Address:"
msgstr "Netfang:"

#: eventwindetails.cpp:92
msgid "Role:"
msgstr "Hlutverk:"

#: eventwindetails.cpp:98
msgid "Attendee"
msgstr "��tttakandi"

#: eventwindetails.cpp:99
msgid "Organizer"
msgstr "Stj�rnandi"

#: eventwindetails.cpp:100
msgid "Owner"
msgstr "Eigandi"

#: eventwindetails.cpp:101
msgid "Delegate"
msgstr "��tttakandi"

#: eventwindetails.cpp:106
msgid "Status:"
msgstr "Sta�a:"

#: eventwindetails.cpp:112
msgid "Needs Action"
msgstr "�arfnast a�ger�a"

#: eventwindetails.cpp:113
msgid "Accepted"
msgstr "Sam�ykkt"

#: eventwindetails.cpp:114
msgid "Sent"
msgstr "Sent"

#: eventwindetails.cpp:115
msgid "Tentative"
msgstr "Br��abirg�a"

#: eventwindetails.cpp:116
msgid "Confirmed"
msgstr "Sta�fest"

#: eventwindetails.cpp:117
msgid "Declined"
msgstr "Hafna�"

#: eventwindetails.cpp:118 todowingeneral.cpp:35 todowingeneral.cpp:52
msgid "Completed"
msgstr "B�i� og gert!"

#: eventwindetails.cpp:119
msgid "Delegated"
msgstr "Afhent ��rum"

#: eventwindetails.cpp:126
msgid "Request Response"
msgstr "Fara fram � svar"

#: eventwindetails.cpp:132
msgid "&Add"
msgstr "&B�ta"

#: eventwindetails.cpp:136
msgid "Address &Book..."
msgstr "Heimilisfangab�k..."

#: eventwindetails.cpp:163
msgid "Attach..."
msgstr "Hengja vi�..."

#: eventwindetails.cpp:183
msgid "Save As..."
msgstr "Vista sem..."

#: eventwindetails.cpp:218
msgid "Priority:"
msgstr "Forgangur:"

#: eventwindetails.cpp:224
msgid "Low (1)"
msgstr "L�till (1)"

#: eventwindetails.cpp:225
msgid "Normal (2)"
msgstr "Venjulegur (2)"

#: eventwindetails.cpp:226
msgid "High (3)"
msgstr "Mikill (3)"

#: eventwindetails.cpp:227
msgid "Maximum (4)"
msgstr "H�marks (4)"

#: eventwindetails.cpp:342
msgid "Unable to open address book."
msgstr "Gat ekki opna� heimilisfangab�k."

#: eventwindetails.cpp:362
msgid "Error getting entry from address book."
msgstr "Villa vi� lestur heimilisfangab�kar."

#: eventwinrecur.cpp:30
msgid "Start:  "
msgstr "Byrja:  "

#: eventwinrecur.cpp:31
msgid "End:  "
msgstr "Enda:  "

#: eventwinrecur.cpp:61
msgid "Recurrence Rule"
msgstr "Endurtekningarregla"

#: eventwinrecur.cpp:67
msgid "Daily"
msgstr "Daglega"

#: eventwinrecur.cpp:68
msgid "Weekly"
msgstr "Vikulega"

#: eventwinrecur.cpp:69
msgid "Monthly"
msgstr "M�na�arlega"

#: eventwinrecur.cpp:70
msgid "Yearly"
msgstr "�rlega"

#: eventwinrecur.cpp:95
msgid "Enable Advanced Rule:"
msgstr "Virkja ��ri reglu:"

#: eventwinrecur.cpp:128
msgid "Recurrence Range"
msgstr "Endurtekningarspan"

#: eventwinrecur.cpp:132
msgid "Begin On:"
msgstr "Byrja �:"

#: eventwinrecur.cpp:134
msgid "No Ending Date"
msgstr "Enginn endadagur"

#: eventwinrecur.cpp:135
msgid "End after"
msgstr "Enda eftir"

#: eventwinrecur.cpp:137
msgid "occurrence(s)"
msgstr "tilvik"

#: eventwinrecur.cpp:138
msgid "End by:"
msgstr "Enda fyrir:"

#: eventwinrecur.cpp:181
msgid "Exceptions"
msgstr "Undantekningar"

#: eventwinrecur.cpp:267 eventwinrecur.cpp:297
msgid "Recur every"
msgstr "Endurtaka hvern/hverja"

#: eventwinrecur.cpp:273
msgid "day(s)"
msgstr "dag(a)"

#: eventwinrecur.cpp:303
msgid "week(s) on:"
msgstr "viku �:"

#: eventwinrecur.cpp:305 kagenda.cpp:106
msgid "Sun"
msgstr "Sun"

#: eventwinrecur.cpp:306 kagenda.cpp:105
msgid "Mon"
msgstr "M�n"

#: eventwinrecur.cpp:307 kagenda.cpp:105
msgid "Tue"
msgstr "�ri"

#: eventwinrecur.cpp:308 kagenda.cpp:105
msgid "Wed"
msgstr "Mi�"

#: eventwinrecur.cpp:309 kagenda.cpp:106
msgid "Thu"
msgstr "Fim"

#: eventwinrecur.cpp:310 kagenda.cpp:106
msgid "Fri"
msgstr "F�s"

#: eventwinrecur.cpp:311 kagenda.cpp:106
msgid "Sat"
msgstr "Lau"

#: eventwinrecur.cpp:361 eventwinrecur.cpp:365
msgid "Recur on the"
msgstr "Endurtaka �ann"

#: eventwinrecur.cpp:363
msgid "day"
msgstr "dag"

#: eventwinrecur.cpp:369 eventwinrecur.cpp:481
msgid "every"
msgstr "hvern/hverja"

#: eventwinrecur.cpp:371
msgid "month(s)"
msgstr "m�nu�(i)"

#: eventwinrecur.cpp:383 eventwinrecur.cpp:424
msgid "1st"
msgstr "1."

#: eventwinrecur.cpp:384 eventwinrecur.cpp:425
msgid "2nd"
msgstr "2."

#: eventwinrecur.cpp:385 eventwinrecur.cpp:426
msgid "3rd"
msgstr "3."

#: eventwinrecur.cpp:386 eventwinrecur.cpp:427
msgid "4th"
msgstr "4."

#: eventwinrecur.cpp:387 eventwinrecur.cpp:428
msgid "5th"
msgstr "5."

#: eventwinrecur.cpp:388
msgid "6th"
msgstr "6."

#: eventwinrecur.cpp:389
msgid "7th"
msgstr "7."

#: eventwinrecur.cpp:390
msgid "8th"
msgstr "8."

#: eventwinrecur.cpp:391
msgid "9th"
msgstr "9."

#: eventwinrecur.cpp:392
msgid "10th"
msgstr "10."

#: eventwinrecur.cpp:393
msgid "11th"
msgstr "11."

#: eventwinrecur.cpp:394
msgid "12th"
msgstr "12."

#: eventwinrecur.cpp:395
msgid "13th"
msgstr "13."

#: eventwinrecur.cpp:396
msgid "14th"
msgstr "14."

#: eventwinrecur.cpp:397
msgid "15th"
msgstr "15."

#: eventwinrecur.cpp:398
msgid "16th"
msgstr "16."

#: eventwinrecur.cpp:399
msgid "17th"
msgstr "17."

#: eventwinrecur.cpp:400
msgid "18th"
msgstr "18."

#: eventwinrecur.cpp:401
msgid "19th"
msgstr "19."

#: eventwinrecur.cpp:402
msgid "20th"
msgstr "20."

#: eventwinrecur.cpp:403
msgid "21st"
msgstr "21."

#: eventwinrecur.cpp:404
msgid "22nd"
msgstr "22."

#: eventwinrecur.cpp:405
msgid "23rd"
msgstr "23."

#: eventwinrecur.cpp:406
msgid "24th"
msgstr "24."

#: eventwinrecur.cpp:407
msgid "25th"
msgstr "25."

#: eventwinrecur.cpp:408
msgid "26th"
msgstr "26."

#: eventwinrecur.cpp:409
msgid "27th"
msgstr "27."

#: eventwinrecur.cpp:410
msgid "28th"
msgstr "28."

#: eventwinrecur.cpp:411
msgid "29th"
msgstr "29."

#: eventwinrecur.cpp:412
msgid "30th"
msgstr "30."

#: eventwinrecur.cpp:413
msgid "31st"
msgstr "31."

#: eventwinrecur.cpp:466
msgid "Recur in the month of"
msgstr "Endurtaka �"

#: eventwinrecur.cpp:467
msgid "Recur on this day"
msgstr "Endurtaka �"

#: calprinter.cpp:327 calprinter.cpp:429 calprinter.cpp:720
#: eventwinrecur.cpp:469 kdatenav.cpp:68 kdatenav.cpp:258
msgid "January"
msgstr "Jan�ar"

#: calprinter.cpp:327 calprinter.cpp:429 calprinter.cpp:720
#: eventwinrecur.cpp:470 kdatenav.cpp:68 kdatenav.cpp:258
msgid "February"
msgstr "Febr�ar"

#: calprinter.cpp:328 calprinter.cpp:430 calprinter.cpp:721
#: eventwinrecur.cpp:471 kdatenav.cpp:68 kdatenav.cpp:259
msgid "March"
msgstr "Mars"

#: calprinter.cpp:328 calprinter.cpp:430 calprinter.cpp:721
#: eventwinrecur.cpp:472 kdatenav.cpp:69 kdatenav.cpp:259
msgid "April"
msgstr "Apr�l"

#: calprinter.cpp:329 calprinter.cpp:431 calprinter.cpp:722
#: eventwinrecur.cpp:473 kdatenav.cpp:69 kdatenav.cpp:260
msgid "May"
msgstr "Ma�"

#: calprinter.cpp:329 calprinter.cpp:431 calprinter.cpp:722
#: eventwinrecur.cpp:474 kdatenav.cpp:69 kdatenav.cpp:260
msgid "June"
msgstr "J�n�"

#: calprinter.cpp:330 calprinter.cpp:432 calprinter.cpp:723
#: eventwinrecur.cpp:475 kdatenav.cpp:69 kdatenav.cpp:261
msgid "July"
msgstr "J�l�"

#: calprinter.cpp:330 calprinter.cpp:432 calprinter.cpp:723
#: eventwinrecur.cpp:476 kdatenav.cpp:70 kdatenav.cpp:261
msgid "August"
msgstr "�g�st"

#: calprinter.cpp:331 calprinter.cpp:433 calprinter.cpp:724
#: eventwinrecur.cpp:477 kdatenav.cpp:70 kdatenav.cpp:262
msgid "September"
msgstr "September"

#: calprinter.cpp:331 calprinter.cpp:433 calprinter.cpp:724
#: eventwinrecur.cpp:478 kdatenav.cpp:70 kdatenav.cpp:262
msgid "October"
msgstr "Okt�ber"

#: calprinter.cpp:332 calprinter.cpp:434 calprinter.cpp:725
#: eventwinrecur.cpp:479 kdatenav.cpp:71 kdatenav.cpp:263
msgid "November"
msgstr "N�vember"

#: calprinter.cpp:332 calprinter.cpp:434 calprinter.cpp:725
#: eventwinrecur.cpp:480 kdatenav.cpp:71 kdatenav.cpp:263
msgid "December"
msgstr "Desember"

#: eventwinrecur.cpp:484
msgid "year(s)"
msgstr "�r"

#: kagenda.cpp:212
msgid "All Day Event"
msgstr "Heilsdagsatbur�ur"

#: kagenda.cpp:829
msgid "New appointment"
msgstr "N�tt stefnum�t"

#: kagenda.cpp:966 kagenda.cpp:974
msgid "am"
msgstr "f.h."

#: kagenda.cpp:970
msgid "pm"
msgstr "e.h."

#: kdatenav.cpp:44
msgid "Previous Year"
msgstr "Fyrra �r"

#: kdatenav.cpp:50
msgid "Previous Month"
msgstr "Fyrri m�nu�ur"

#: kdatenav.cpp:56
msgid "Next Month"
msgstr "N�sti m�nu�ur"

#: kdatenav.cpp:62
msgid "Next Year"
msgstr "N�sta �r"

#: kmonthview.cpp:386
msgid "New Event"
msgstr "Nexti atbur�ur"

#: kpbutton.cpp:22 kpbutton.cpp:40 kpbutton.cpp:90
msgid "KPButton: pixmap is empty, perhaps some missing file"
msgstr "KPButton: Engin mynd.  �a� vantar skr�."

#: baselistview.cpp:28
msgid "Date"
msgstr "Dags"

#: baselistview.cpp:29
msgid "Time"
msgstr "T�mi"

#: baselistview.cpp:30 calprinter.cpp:365
msgid "Summary"
msgstr "Yfirlit"

#: baselistview.cpp:77
msgid "started "
msgstr "byrja�i"

#: baselistview.cpp:80
msgid "ends "
msgstr "endar"

#: baselistview.cpp:85
#, c-format
msgid "repeats %d times"
msgstr "endurtekur %d sinni/sinnum"

#: baselistview.cpp:89
msgid "repeats forever"
msgstr "endurtekur a� eil�fu"

#: listview.cpp:14
msgid "Edit Event"
msgstr "Breyta atbur�i"

#: listview.cpp:17
msgid "Delete Event  "
msgstr "�urrka �t atbur�"

#: listview.cpp:20
msgid "Show Dates"
msgstr "S�na dagana"

#: listview.cpp:22
msgid "Hide Dates"
msgstr "Fela dagana"

#: main.cpp:29
msgid "No default calendar, and none was specified on the command line.\n"
msgstr "Ekkert almanak vali� og ekkert gefi� upp � skipanal�nu.\n"

#: main.cpp:33
msgid "Error reading from default calendar.\n"
msgstr "Villa vi� lestur � sj�lfgefnu almanaki\n"

#: searchdialog.cpp:22
msgid "Search For:"
msgstr ""

#: searchdialog.cpp:32 topwidget.cpp:494
#, fuzzy
msgid "&Search"
msgstr "Leita..."

#: searchdialog.cpp:81
msgid ""
"Invalid search expression, cannot perform\n"
"the search.  Please enter a search expression\n"
"using the wildcard characters '*' and '?'\n"
"where needed."
msgstr ""

#: topwidget.cpp:391
msgid "&Open"
msgstr ""

#: topwidget.cpp:394
msgid "Open &Recent"
msgstr "Opna n�legt"

#: topwidget.cpp:410
#, fuzzy
msgid "Save &As"
msgstr "Vista sem..."

#: topwidget.cpp:415
#, fuzzy
msgid "&Import From Ical"
msgstr "Flytja inn fr� Ical..."

#: topwidget.cpp:417
#, fuzzy
msgid "&Merge Calendar"
msgstr "Setja saman alman�k..."

#: topwidget.cpp:420
#, fuzzy
msgid "Archive Old Entries"
msgstr "Safnvista eldri atbur�i..."

#: topwidget.cpp:427
#, fuzzy
msgid "Print Setup"
msgstr "Prentunaruppsetning..."

#: calprinter.cpp:844 topwidget.cpp:431
msgid "&Print"
msgstr "Prenta �t"

#: topwidget.cpp:433
#, fuzzy
msgid "Print Pre&view"
msgstr "Prentfors�n..."

#: topwidget.cpp:455
msgid "&List"
msgstr "S�na lista"

#: topwidget.cpp:459
msgid "&Day"
msgstr "Dagur"

#: topwidget.cpp:462
msgid "W&ork Week"
msgstr "Vinnuvika"

#: topwidget.cpp:465
msgid "&Week"
msgstr "Vika"

#: topwidget.cpp:468
msgid "&Month"
msgstr "M�nu�ur"

#: topwidget.cpp:471
#, fuzzy
msgid "&To-do list"
msgstr "Verkefnalisti"

#: topwidget.cpp:479
msgid "New &Appointment"
msgstr "N�tt stefnum�t"

#: topwidget.cpp:481
msgid "New E&vent"
msgstr "N�r atbur�ur"

#: topwidget.cpp:483
msgid "&Edit Appointment"
msgstr "Breyta stefnum�ti"

#: topwidget.cpp:486
msgid "&Delete Appointment"
msgstr "�urrka �t stefnum�t"

#: topwidget.cpp:488
#, fuzzy
msgid "Delete To-do"
msgstr "Ey�a verkefni"

#: topwidget.cpp:498
#, fuzzy
msgid "&Mail Appointment"
msgstr "Senda stefnum�t"

#: topwidget.cpp:504
#, fuzzy
msgid "Go to &Today"
msgstr "� dag"

#: topwidget.cpp:508
#, fuzzy
msgid "&Previous Day"
msgstr "Fyrra �r"

#: topwidget.cpp:512
#, fuzzy
msgid "&Next Day"
msgstr "N�sta �r"

#: topwidget.cpp:516
msgid "Show &Tool Bar"
msgstr "S�na &t�kjasl�"

#: topwidget.cpp:520
msgid "Show St&atus Bar"
msgstr "S�na st��usl�"

#: topwidget.cpp:525
msgid "&Edit Options"
msgstr "Breyta stillingum"

#: topwidget.cpp:533
msgid "&About"
msgstr "&Um"

#: topwidget.cpp:535
msgid "Send &Bug Report"
msgstr "Senda villusk�rslu"

#: topwidget.cpp:543
msgid "&Actions"
msgstr "A�ger�ir"

#: topwidget.cpp:562
msgid "Open A Calendar"
msgstr "Opna almanak"

#: topwidget.cpp:568
msgid "Save This Calendar"
msgstr "Vista �etta almanak"

#: topwidget.cpp:585
msgid "New Appointment"
msgstr "N�tt stefnum�t"

#: topwidget.cpp:591
msgid "Delete Appointment"
msgstr "Ey�a stefnum�ti"

#: topwidget.cpp:597
msgid "Search For an Appointment"
msgstr "Leita a� stefnum�ti"

#: topwidget.cpp:603
msgid "Mail Appointment"
msgstr "Senda stefnum�t"

#: topwidget.cpp:622
msgid "Go to Today"
msgstr "� dag"

#: topwidget.cpp:628
#, fuzzy
msgid "Previous Day"
msgstr "Fyrra �r"

#: topwidget.cpp:634
#, fuzzy
msgid "Next Day"
msgstr "N�sta �r"

#: topwidget.cpp:650
msgid "List View"
msgstr "Listas�n"

#: topwidget.cpp:655
msgid "Schedule View"
msgstr "Dagskr�rs�n"

#: topwidget.cpp:662
msgid "Month View"
msgstr "M�na�ars�n"

#: topwidget.cpp:668
#, fuzzy
msgid "To-do list view"
msgstr "Verkefnalistas�n"

#: topwidget.cpp:750
msgid "we don't handle updates for that view, yet.\n"
msgstr "Get ekki uppf�rt �essa s�n (enn��).\n"

#: topwidget.cpp:842
msgid "we don't handle that view yet.\n"
msgstr "Get ekki framkalla� svona s�n (enn).\n"

#: topwidget.cpp:960
msgid "You did not specify a valid file name."
msgstr ""

#: topwidget.cpp:968
msgid ""
"The file you specified is a directory,\n"
"and cannot be opened. Please try again,\n"
"this time selecting a valid calendar file."
msgstr ""

#: topwidget.cpp:995
msgid "KOrganizer Warning"
msgstr "KSkipuleggjarinn: A�v�run"

#: topwidget.cpp:996
#, fuzzy
msgid ""
"This calendar has been modified.\n"
"Would you like to save it?"
msgstr ""
"Almanakinu sem �� ert a� loka hefur veri� breytt.\n"
"Viltu vista breytingarnar?"

#: topwidget.cpp:998
msgid "&Yes"
msgstr ""

#: topwidget.cpp:998
msgid "&No"
msgstr ""

#: topwidget.cpp:1007 topwidget.cpp:1597
msgid "KOrganizer Confirmation"
msgstr "KSkipuleggjarinn: Sta�festing"

#: topwidget.cpp:1008
msgid "This item will be permanently deleted."
msgstr ""

#: topwidget.cpp:1111
msgid ""
"You have no ical file in your home directory.\n"
"Import cannot proceed.\n"
msgstr ""
"�ig vantar ical skr� � heimasv��i� �itt.\n"
"Innlestur fer �v� ekki fram.\n"

#: topwidget.cpp:1124
msgid "KOrganizer Info"
msgstr "KSkipuleggjarinn uppl."

#: topwidget.cpp:1125
msgid ""
"KOrganizer succesfully imported and merged your\n"
".calendar file from ical into the currently\n"
"opened calendar.\n"
msgstr ""
"KSkipuleggjaranum t�kst a� flytja inn og sameina\n"
".calendar skr� fr� ical vi� almanaki� sem\n"
"er n�na � notkun.\n"

#: topwidget.cpp:1130
msgid "ICal Import Successful With Warning"
msgstr "ICal innflutningur t�kst me� a�v�run"

#: topwidget.cpp:1131
msgid ""
"KOrganizer encountered some unknown fields while\n"
"parsing your .calendar ical file, and had to\n"
"discard them.  Please check to see that all\n"
"your relevant data was correctly imported.\n"
msgstr ""
"KSkipuleggjarinn fann einhver ��ekkt sv��i vi�\n"
"lestur � .calendar ical skr�nni og var� �v� a�\n"
"sleppa �eimsv��um.  Vinsamlega g��u �v� hvort �ll\n"
"g�gn hafi veri� flutt inn r�tt.\n"

#: topwidget.cpp:1137
msgid ""
"KOrganizer encountered some error parsing your\n"
".calendar file from ical.  Import has failed.\n"
msgstr ""
"KSkipuleggjarinn fann villur vi� lestur � .calendar\n"
"skr�nni fr� ical.  Innflutingur fer �v� ekki fram.\n"

#: topwidget.cpp:1141
msgid ""
"KOrganizer doesn't think that your .calendar\n"
"file is a valid ical calendar. Import has failed.\n"
msgstr ""
"KSkipuleggjarinn hefur komist a� raun um a� .calendar skr�in\n"
"��n er ekki noth�ft ical almanak og h�tti �v� vi� innflutning.\n"

#: topwidget.cpp:1305 topwidget.cpp:1332 topwidget.cpp:1683 topwidget.cpp:1693
msgid "KOrganizer error"
msgstr "KSkipuleggjarinn: Villa"

#: topwidget.cpp:1306 topwidget.cpp:1333
msgid ""
"Unfortunately, we don't handle cut/paste for\n"
"that view yet.\n"
msgstr ""
"�v� mi�ur �� er klippa/l�ma ekki noth�ft �\n"
"�essari s�n enn��.\n"

#: topwidget.cpp:1549
msgid "don't handle deletes from that view, yet.\n"
msgstr "ekki h�gt a� �urrka �t � �essari s�n, enn��.\n"

#: topwidget.cpp:1598
#, fuzzy
msgid ""
"This event recurs over multiple dates.\n"
"Are you sure you want to delete the\n"
"selected event, or just this instance?\n"
msgstr ""
"�essi atbur�ur gerist reglulega.\n"
"Hvort viltu �urrka �t �ll tilvik,\n"
"e�a bara �etta einstaka tilvik?\n"
"\n"

#: topwidget.cpp:1601
msgid "&All"
msgstr "�ll"

#: topwidget.cpp:1601
msgid "&This"
msgstr "Bara �etta"

# topwidget.cpp:
#: topwidget.cpp:1616
msgid "no date selected, or invalid date\n"
msgstr "engin e�a �noth�f dagsetning valin\n"

#: topwidget.cpp:1684
msgid "Can't generate mail from this view\n"
msgstr "Get ekki skrifa� p�st � �essari s�n\n"

#: topwidget.cpp:1694
msgid ""
"Can't generate mail:\n"
" No attendees defined!\n"
msgstr ""
"Get ekki skrifa� p�st:\n"
" Enginn ��tttakandi valinn!\n"

#: topwidget.cpp:1833
#, fuzzy
msgid "New Calendar"
msgstr "Opna almanak"

#: eventwin.cpp:313 eventwin.cpp:319 topwidget.cpp:1839
msgid "modified"
msgstr ""

#: eventwin.cpp:325 topwidget.cpp:1844
#, fuzzy
msgid "KOrganizer"
msgstr "Stj�rnandi"

#: calprinter.cpp:47
msgid "Korganizer Configuration Options"
msgstr "KSkipuleggjarinn:  Stillingar"

#: calprinter.cpp:361 todowingeneral.cpp:60
msgid "Priority"
msgstr "Forgangur"

#: calprinter.cpp:369
msgid "Due"
msgstr "S��ustu forv��"

#: calprinter.cpp:453
#, c-format
msgid "To-Do items: %s %.2d"
msgstr "Kl�ra atri�i: %s %.2d"

#: calprinter.cpp:791
msgid "Date Range"
msgstr "T�mabil"

#: calprinter.cpp:811
msgid "View Type"
msgstr "S�n"

#: calprinter.cpp:816
msgid "Day"
msgstr "Dagur"

#: calprinter.cpp:821
msgid "Week"
msgstr "Vika"

#: calprinter.cpp:825
msgid "Month"
msgstr "M�nu�ur"

#: calprinter.cpp:829
msgid "To-Do"
msgstr "Verkefni"

#: calprinter.cpp:843
msgid "&Preview"
msgstr "Fyrri"

#: koarchivedlg.cpp:19
msgid "Archive / Delete Past Appointments - KOrganizer"
msgstr "Safnvista/�urrka �t g�mul stefnum�t - KSkipuleggjarinn"

#: optionsdlg.cpp:37
msgid "Time & Date"
msgstr "T�mi og dags."

#: optionsdlg.cpp:43
msgid "Colors"
msgstr "Litir"

#: optionsdlg.cpp:46
msgid "Views"
msgstr "S�n"

#: optionsdlg.cpp:52
msgid "Printing"
msgstr "Prenta �t"

#: optionsdlg.cpp:65
#, fuzzy
msgid "KOrganizer Configuration"
msgstr "KSkipuleggjarinn: Sta�festing"

#: optionsdlg.cpp:92
msgid "Your name:"
msgstr "Nafni� �itt:"

#: optionsdlg.cpp:96
msgid "Email address:"
msgstr "Netfang:"

#: optionsdlg.cpp:100
msgid "Additional:"
msgstr "Anna�:"

#: optionsdlg.cpp:104
msgid "Auto-save Calendar"
msgstr "Vista almanaki� sj�lfkrafa"

#: optionsdlg.cpp:108
msgid "Confirm Appointment/To-Do Deletes"
msgstr "Sta�festa ey�ingu � stefnum�tum/verkefnum"

#: optionsdlg.cpp:112
msgid "Holidays:"
msgstr "Fr�dagar:"

#: optionsdlg.cpp:138
msgid "1 minute"
msgstr ""

#: optionsdlg.cpp:138
msgid "5 minutes"
msgstr ""

#: optionsdlg.cpp:139
msgid "10 minutes"
msgstr ""

#: optionsdlg.cpp:139
msgid "15 minutes"
msgstr ""

#: optionsdlg.cpp:140
msgid "30 minutes"
msgstr ""

#: optionsdlg.cpp:147
msgid "Time Format:"
msgstr "T�masni�:"

#: optionsdlg.cpp:148
msgid "24 hour"
msgstr ""

#: optionsdlg.cpp:149
msgid "AM / PM"
msgstr ""

#: optionsdlg.cpp:153
msgid "Date Format:"
msgstr "Dagsetningarsni�:"

#: optionsdlg.cpp:154
msgid "Day.Month.Year (31.01.2000)"
msgstr "Dagur.M�nu�ur.�r (31.01.2000)"

#: optionsdlg.cpp:155
msgid "Month/Day/Year (01/31/2000)"
msgstr "M�nu�ur/Dagur/�r (01/31/2000)"

#: optionsdlg.cpp:156
msgid "Month-Day-Year (01-31-2000)"
msgstr "M�nu�ur-Dagur-�r (01-31-2000)"

#: optionsdlg.cpp:160
msgid "Time Zone:"
msgstr "T�mabelti:"

#: optionsdlg.cpp:167
msgid "Default Appointment Time:"
msgstr "Sj�lfgefinn t�mi stefnum�ts:"

#: optionsdlg.cpp:177
msgid "Default Alarm Time:"
msgstr "Sj�lfgefinn vekjaraklukkut�mi:"

#: optionsdlg.cpp:185
msgid "Week Starts on Monday"
msgstr "Vikan byrjar � m�nud�gum"

#: optionsdlg.cpp:202
msgid "Day Begins At:"
msgstr "Dagurinn byrjar kl.:"

#: optionsdlg.cpp:212
msgid "Hour size in schedule view"
msgstr ""

#: optionsdlg.cpp:216
msgid "Show events that recur daily in Date Navigator"
msgstr "Sko�a daglega atbur�i � dagsskr�rsko�aranum"

#: optionsdlg.cpp:228
#, fuzzy
msgid "List view font"
msgstr "Listas�n"

#: optionsdlg.cpp:234
#, fuzzy
msgid "Schedule view font"
msgstr "Dagskr�rs�n"

#: optionsdlg.cpp:240
#, fuzzy
msgid "Month view font"
msgstr "M�na�ars�n"

#: optionsdlg.cpp:245
msgid "12345"
msgstr ""

#: optionsdlg.cpp:245
#, fuzzy
msgid "Time bar font"
msgstr "T�mabelti:"

#: optionsdlg.cpp:250
msgid "Things to do"
msgstr "�arf a� gera"

#: optionsdlg.cpp:251
#, fuzzy
msgid "To-Do list font"
msgstr "Verkefnalisti"

#: optionsdlg.cpp:272
msgid "Use system default colors"
msgstr "Nota sj�lfgefna kerfisliti"

#: optionsdlg.cpp:277
#, fuzzy
msgid "Appointment & Checklist items"
msgstr "T�mi stefnum�ts"

#: optionsdlg.cpp:278
msgid "Background"
msgstr "Bakgrunnur"

#: optionsdlg.cpp:281
msgid "Text"
msgstr "Letur"

#: optionsdlg.cpp:284
msgid "Handle Selected"
msgstr "Sj� um allt vali�"

#: optionsdlg.cpp:287
msgid "Handle Unselected"
msgstr "Sj� um allt �vali�"

#: optionsdlg.cpp:290
msgid "Handle Active Apt."
msgstr "Sj� um virk stefnum�t"

#: optionsdlg.cpp:295
msgid "Sheet background"
msgstr "Bla�s��ubakgrunnur"

#: optionsdlg.cpp:298
msgid "Calendar Background"
msgstr "Dagatalsbakgrunnur"

#: optionsdlg.cpp:301
msgid "Calendar Date Text"
msgstr "Dagsetningaletur"

#: optionsdlg.cpp:304
msgid "Calendar Date Selected"
msgstr "Valin dagsetning"

#: optionsdlg.cpp:343
msgid "Printer Name"
msgstr "Nafn prentara"

#: optionsdlg.cpp:373
msgid "Paper Size"
msgstr "Bla�s��ust�r�"

#: optionsdlg.cpp:375
msgid "A4"
msgstr "A4"

#: optionsdlg.cpp:376
msgid "B5"
msgstr "B5"

#: optionsdlg.cpp:377
msgid "Letter"
msgstr "21.59 x 27.94 cm (Letter)"

#: optionsdlg.cpp:378
msgid "Legal"
msgstr "21.59 x 35.56 cm (Legal)"

#: optionsdlg.cpp:379
msgid "Executive"
msgstr "18.415 x 26.67 cm (Exec)"

#: optionsdlg.cpp:383
msgid "Paper Orientation"
msgstr "Bla�s��usni�"

#: optionsdlg.cpp:385
msgid "Portrait"
msgstr "Skammsni�"

#: optionsdlg.cpp:387
msgid "Landscape"
msgstr "Langsni�"

#: optionsdlg.cpp:394
msgid "Preview Program"
msgstr "Fors�n"

#: kpropdlg.cpp:124
msgid "Prev"
msgstr "Fyrri"

#: kpropdlg.cpp:125
msgid "Next"
msgstr "N�sta"

#: aboutdlg.cpp:20
#, fuzzy
msgid "KOrganizer Virtual Postcard"
msgstr "KSkipuleggjarinn: Villa"

#: aboutdlg.cpp:24
msgid ""
"Please send a postcard to me, so I can see who is\n"
"using KOrganizer! Tell me how great the program is,\n"
"and how you just can't live without it.  Or, report\n"
"a bug which is stopping you from doing useful work.\n"
"The postcard will simply include anything you wish to\n"
"type in the comment area below.\n"
msgstr ""
"Vinsamlega sendu m�r p�stkort svo �g viti hver er a�\n"
"nota KSkipuleggjarinn!  Seg�u m�r hva� forriti� er fr�b�rt\n"
"og hvernig �� getur ekki lifa� �n �ess.  �� g�tir l�ka\n"
"sagt m�r fr� villunum � �v� sem hindra e�lilega notkun.\n"
"P�stkorti� m� innihalda allt sem ��r dettur � hug a�\n"
"skrifa � textasv��i� h�r fyrir ne�an.\n"

#: aboutdlg.cpp:104
#, fuzzy
msgid "About KOrganizer"
msgstr "Stj�rnandi"

#: aboutdlg.cpp:137
msgid "by Preston Brown and"
msgstr ""

#: aboutdlg.cpp:156
msgid "License Agreement:"
msgstr ""

#: aboutdlg.cpp:162
msgid ""
"\n"
"\n"
"This program is free software; you can redistribute it and/or modify\n"
"it under the terms of the GNU General Public License as published by\n"
"the Free Software Foundation; either version 2 of the License, or\n"
"(at your option) any later version.\n"
"\n"
"This program is distributed in the hope that it will be useful,\n"
"but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
"GNU General Public License for more details.\n"
"\n"
"You should have received a copy of the GNU General Public License\n"
"along with this program; if not, write to the Free Software\n"
"Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.\n"
msgstr ""
"\n"
"�slensk ���ing: ��rarinn R. Einarsson (thori@mindspring.com)\n"
"\n"
"�etta forrit er �keypis hugb�na�ur.  �� getur breytt �v� og/e�a dreift\n"
"�v� skv. skilm�lum GNU General Public License eins og �eir eru settir\n"
"fram af Free Software Foundation, anna�hvort �tg�fu 2 af �v� sk�rteini\n"
"e�a hva�a s��ari �tg�fu sem er (a� ��nu vali).\n"
"\n"
"�essu forriti er dreift � �eirri von a� �a� s� gagnlegt,\n"
"en �n NOKKURAR �BYRG�AR; sem ���ir �n �byrg�ar a� �a� gagnist\n"
"��r e�a ��num tilgangi.  Vinsamlega sko�a�u GNU General\n"
"Public License til a� lesa n�nar um �essi m�l.\n"
"\n"
"�� �ttir a� hafa fengi� afrit af GNU General Public License\n"
"me� �essu forriti; ef ekki, skrifa�u �� Free Software\n"
"Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.\n"

#: aboutdlg.cpp:197
#, fuzzy
msgid "&Send Postcard"
msgstr "Senda p�stkort"

#: aboutdlg.cpp:233
msgid "many more, thank you!"
msgstr "margir a�rir, takk fyrir!"

#: aboutdlg.cpp:255
msgid "Could not load movie"
msgstr ""

#: kotodoview.cpp:27
msgid "To-Do Items"
msgstr "Verkefni"

#: kotodoview.cpp:91 kotodoview.cpp:99
msgid "New To-Do"
msgstr "N�tt verkefni"

#: kotodoview.cpp:94
msgid "Purge Completed "
msgstr "B�in a� ey�a"

#: kotodoview.cpp:101
msgid "Edit To-Do"
msgstr "Breyta verkefni"

#: kotodoview.cpp:104
msgid "Delete To-Do"
msgstr "Ey�a verkefni"

#: kotodoview.cpp:106
#, fuzzy
msgid "Purge Completed"
msgstr "B�in a� ey�a"

#: kotodoview.cpp:108
#, fuzzy
msgid "Sort by Priority"
msgstr "Forgangur"

#: eventwin.cpp:91
msgid "Save and Close"
msgstr "Vista og loka"

#: eventwin.cpp:111
msgid "Previous Event"
msgstr "Fyrri atbur�ur"

#: eventwin.cpp:117
msgid "Next Event"
msgstr "N�sti atbur�ur"

#: eventwin.cpp:128
msgid "Delete Event"
msgstr "�urrka �t atbur�"

#: eventwin.cpp:286
msgid "New"
msgstr ""

#: eventwin.cpp:293
#, fuzzy
msgid "Todo"
msgstr "Verkefni"

#: eventwin.cpp:309
msgid "readonly"
msgstr ""

#: todowingeneral.cpp:41
msgid "% Completed"
msgstr "% b�i� og gert"

#: todowingeneral.cpp:48
#, c-format
msgid "0 %"
msgstr "0 %"

#: todowingeneral.cpp:49
#, c-format
msgid "25 %"
msgstr "25 %"

#: todowingeneral.cpp:50
#, c-format
msgid "50 %"
msgstr "50 %"

#: todowingeneral.cpp:51
#, c-format
msgid "75 %"
msgstr "75 %"

#: todowingeneral.cpp:67
msgid "1 (Highest)"
msgstr "1 (H��st)"

#: todowingeneral.cpp:68
msgid "2"
msgstr "2"

#: todowingeneral.cpp:69
msgid "3"
msgstr "3"

#: todowingeneral.cpp:70
msgid "4"
msgstr "4"

#: todowingeneral.cpp:71
msgid "5 (lowest)"
msgstr "5 (l�gst)"

#: alarmdaemon.cpp:39 alarmdaemon.cpp:44
msgid "Can't load docking tray icon!"
msgstr ""

#: alarmdaemon.cpp:48
msgid "Alarms Enabled"
msgstr ""

#: alarmdaemon.cpp:51
#, fuzzy
msgid "Exit Applet"
msgstr "Breyta stefnum�ti"

#: alarmdaemon.cpp:54
#, fuzzy
msgid "KOrganizer Control Applet"
msgstr "KSkipuleggjarinn: Sta�festing"

#: alarmdaemon.cpp:156
#, fuzzy, c-format
msgid "KOrganizer Alarm: %s\n"
msgstr "Flokkar KSkipuleggjarans"

#: alarmdaemon.cpp:157
msgid ""
"The following events triggered alarms:\n"
"\n"
msgstr ""

#~ msgid "New Appointment - KOrganizer"
#~ msgstr "N�tt stefnum�t - KSkipuleggjarinn"

#~ msgid "Edit Todo - KOrganizer (Readonly)"
#~ msgstr "Breyta verkefni - KSkipuleggjarinn (ritvari�)"

#~ msgid "Edit Appointment - KOrganizer (Readonly)"
#~ msgstr "Breyta stefnum�ti - KSkipuleggjarinn (ritvari�)"

#~ msgid "Edit Todo - KOrganizer"
#~ msgstr "Breyta verkefni - KSkipuleggjarinn"

#~ msgid "Edit Appointment - KOrganizer"
#~ msgstr "Breyta stefnum�ti - KSkipuleggjarinn"

#~ msgid "&Mail Appointment..."
#~ msgstr "&Senda stefnum�t..."

#~ msgid "Previous"
#~ msgstr "Fyrra"

#~ msgid "Modified Calendar Warning"
#~ msgstr "A�v�run: Breytt almanak"

#~ msgid ""
#~ "You are opening a new calendar, but the currentone has been modified.\n"
#~ "Are you sure you want todo this? All changes will be lost!\n"
#~ "\n"
#~ msgstr ""
#~ "�� ert a� opna n�tt almanak, en hinu hefur veri� breytt.\n"
#~ "Ertu viss um a� �� viljir gera �etta? Allar breytingar glatast!\n"
#~ "\n"

#~ msgid "KOrganizer had a problem opening your file:\n"
#~ msgstr "KSkipuleggjarinn lenti � vandr��um a� opna skr�:\n"

#~ msgid ""
#~ "Please check that the directory and/or file exists,\n"
#~ "that you have permissions to read it, and try again."
#~ msgstr ""
#~ "Athuga�u hvort mappan og/e�a skr�in s�u til,\n"
#~ "hvort �� hafir lesr�ttindi og reyndu svo aftur."

#~ msgid "KOrganizer Modified Calendar Warning"
#~ msgstr "KSkipuleggjarinn: A�v�run um breytt almanak"

#~ msgid ""
#~ "You are opening a new calendar, but the current one has been modified.\n"
#~ "Are you sure you want to do this? All changes will be lost!\n"
#~ "\n"
#~ msgstr ""
#~ "�� ert a� opna n�tt almanak, en hinu hefur veri� breytt.\n"
#~ "Ertu viss um a� �� viljir gera �etta? Allar breytingar glatast!\n"
#~ "\n"

#~ msgid "KOrganizer had a problem saving your file:\n"
#~ msgstr "KSkipuleggjarinn lendi � vandr��um a� vista:\n"

#~ msgid ""
#~ "Please check that the directory exists and you have\n"
#~ "permission to write to it, and try again."
#~ msgstr ""
#~ "Athuga�u hvort mappan s� �rugglega til og a� ��\n"
#~ "hafir skrifr�ttindi og reyndu s��an aftur."

#~ msgid "&Don't Save"
#~ msgstr "Ekki vista"

#~ msgid ""
#~ "Are you sure you want to delete\n"
#~ "the selected to do item?\n"
#~ "\n"
#~ msgstr ""
#~ "Ertu viss um a� �� viljir �urrka\n"
#~ "�t �etta verkefni?\n"
#~ "\n"

#~ msgid ""
#~ "Are you sure you want to delete\n"
#~ "the selected event?\n"
#~ "\n"
#~ msgstr ""
#~ "Ertu viss um a� �� viljir �urrka �t\n"
#~ "�ennan atbur�?\n"
#~ "\n"

#~ msgid "%s%s- KOrganizer"
#~ msgstr "%s%s- KSkipuleggjarinn"

#~ msgid "New Calendar%s- KOrganizer"
#~ msgstr "N�tt almanak%s- KSkipuleggjarinn"

#~ msgid "%s - KOrganizer"
#~ msgstr "%s - KSkipuleggjarinn"

#~ msgid "New Calendar - KOrganizer"
#~ msgstr "N�tt almanak - KSkipuleggjarinn"

#~ msgid "Test"
#~ msgstr "Tilraun"
