public class Hellorld {
	public static void main(String[] args) {
		System.out.println();
		System.out.println("hellorld");
		System.out.println();
		System.out.print("Java seems to be working, version: ");
		System.out.print(System.getProperty("java.version"));
		System.out.println();
	}
}